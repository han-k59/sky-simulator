#!/bin/bash

echo "Connecting telescope..."
response=$(curl -s -w "%{http_code}" -X PUT "http://127.0.0.1:11111/api/v1/telescope/0/connected?Connected=true")
http_code="${response: -3}"
if [[ "$http_code" != "200" ]]; then
    echo "Warning: Connection request returned HTTP $http_code"
    echo "Script may not work properly."
fi

# Wait a moment for telescope to initialize
echo "Waiting for telescope to initialize..."
sleep 2

# Check if telescope is actually connected before getting position
echo "Verifying telescope connection..."
for i in {1..5}; do
    connected_response=$(curl -s "http://127.0.0.1:11111/api/v1/telescope/0/connected")
    if [[ -n "$connected_response" ]] && echo "$connected_response" | grep -q '"Value":true'; then
        echo "Telescope connected successfully!"
        break
    elif [[ $i -eq 5 ]]; then
        echo "Warning: Telescope connection could not be verified"
        echo "Continuing anyway..."
        break
    else
        echo "Waiting for connection... (attempt $i/5)"
        sleep 1
    fi
done

echo
echo "Getting current telescope position..."
# Get current RA with timeout and error handling
ra_response=$(timeout 5 curl -s "http://127.0.0.1:11111/api/v1/telescope/0/rightascension" 2>/dev/null)
if [[ -n "$ra_response" ]] && echo "$ra_response" | grep -q '"Value"'; then
    current_ra=$(echo "$ra_response" | grep -o '"Value":[^,}]*' | cut -d: -f2 | tr -d '"' | tr -d ' ')
    echo "Current RA: $current_ra hours"
else
    echo "Current RA: Unable to retrieve (telescope may still be initializing)"
fi

# Get current Dec with timeout and error handling
dec_response=$(timeout 5 curl -s "http://127.0.0.1:11111/api/v1/telescope/0/declination" 2>/dev/null)
if [[ -n "$dec_response" ]] && echo "$dec_response" | grep -q '"Value"'; then
    current_dec=$(echo "$dec_response" | grep -o '"Value":[^,}]*' | cut -d: -f2 | tr -d '"' | tr -d ' ')
    echo "Current Dec: $current_dec degrees"
else
    echo "Current Dec: Unable to retrieve (telescope may still be initializing)"
fi
echo
echo "---------------------------------------------"
echo

while true; do
    read -p "Enter Right Ascension (decimal hours, or Q to quit): " RA
    [[ "$RA" == "Q" || "$RA" == "q" ]] && echo "Goodbye!" && exit 0
    
    read -p "Enter Declination (decimal degrees): " DEC
    
    echo "Slewing to RA=$RA Dec=$DEC..."
    response=$(curl -s -w "%{http_code}" -X PUT "http://127.0.0.1:11111/api/v1/telescope/0/slewtocoordinates?RightAscension=$RA&Declination=$DEC")
    http_code="${response: -3}"
    if [[ "$http_code" != "200" ]]; then
        echo "Warning: Slew request returned HTTP $http_code"
    fi
    echo
    
    echo "Waiting for slew to complete..."
    while true; do
        response=$(curl -s "http://127.0.0.1:11111/api/v1/telescope/0/slewing")
        if [[ -z "$response" ]]; then
            echo "Error: No response from telescope API"
            break
        fi
        
        # Extract boolean value and remove quotes
        SLEWING=$(echo "$response" | grep -o '"Value":[^,}]*' | cut -d: -f2 | tr -d '"' | tr -d ' ')
        
        if [[ "$SLEWING" == "false" ]]; then
            echo "Slew completed!"
            break
        fi
        echo -n "."
        sleep 2
    done
    echo
    
    echo "Target RA: $RA"
    echo "Target Dec: $DEC"
    
    # Get current RA
    ra_response=$(curl -s "http://127.0.0.1:11111/api/v1/telescope/0/rightascension")
    if [[ -n "$ra_response" ]]; then
        current_ra=$(echo "$ra_response" | grep -o '"Value":[^,}]*' | cut -d: -f2 | tr -d '"' | tr -d ' ')
        echo "Current RA: $current_ra"
    else
        echo "Current RA: Unable to retrieve"
    fi
    
    # Get current Dec
    dec_response=$(curl -s "http://127.0.0.1:11111/api/v1/telescope/0/declination")
    if [[ -n "$dec_response" ]]; then
        current_dec=$(echo "$dec_response" | grep -o '"Value":[^,}]*' | cut -d: -f2 | tr -d '"' | tr -d ' ')
        echo "Current Dec: $current_dec"
    else
        echo "Current Dec: Unable to retrieve"
    fi
    
    echo
    echo "---------------------------------------------"
done
