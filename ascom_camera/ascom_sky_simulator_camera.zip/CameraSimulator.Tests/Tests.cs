﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ASCOM.Sky_Simulator;
using NUnit.Framework;

namespace CameraSimulator.Tests
{
    [TestFixture]
    public class Tests
    {
        [Test]
        public void TestMakeCamera()
        {
            var camera = new Camera();
            camera.Connected = true;

            camera.StartExposure(1, true);
            while (! camera.ImageReady)
                Thread.Sleep(10);

            var data = camera.ImageArray;

            camera.Connected = false;
            camera.Dispose();
            
        }


        [Test]
        public void TestStopExposure()
        {
            var camera = new Camera();
            camera.Connected = true;
            TestContext.WriteLine($"{camera.NumX}, {camera.NumY}");

            camera.StartExposure(5, true);


            Thread.Sleep(1000);
            camera.StopExposure();

            var data = camera.ImageArray;

            camera.Connected = false;
            camera.Dispose();

        }

        [Test]
        public void TestBoxMuller()
        {
            List<double> data = new List<double>();
            for (int i = 0; i < 100000; i++)
            {
                data.Add(BoxMuller(50,7));
            }

            var mean = data.Average();
            var meanofSquares = data.Select(x => x * x).Average();

            var variance = meanofSquares - mean * mean;
            var sd = Math.Sqrt(variance);

            TestContext.WriteLine($"{mean}, {sd}");
            TestContext.WriteLine(data.Min());
        }

        private Random R = new Random();

        private double BoxMuller(double m, double s)
        {
            double xa;
            double w;
            do
            {
                xa = 2.0 * R.NextDouble() - 1.0;
                var xb = 2.0 * R.NextDouble() - 1.0;
                w = xa * xa + xb * xb;
            } while (w >= 1.0);

            w = Math.Sqrt((-2.0 * Math.Log(w)) / w);
            var ya = xa * w;
            return (m + ya * s);
        }
    }
}

