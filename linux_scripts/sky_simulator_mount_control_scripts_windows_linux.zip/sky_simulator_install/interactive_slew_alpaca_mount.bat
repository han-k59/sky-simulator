@echo off
setlocal enabledelayedexpansion

:connect
echo Connecting telescope...
curl -s -X PUT "http://127.0.0.1:11111/api/v1/telescope/0/connected?Connected=true"
echo.

:loop
set /p RA=Enter Right Ascension (decimal hours, or Q to quit): 
if /I "%RA%"=="Q" goto end
set /p DEC=Enter Declination (decimal degrees): 

echo Slewing to RA=%RA% Dec=%DEC%...
curl -s -X PUT "http://127.0.0.1:11111/api/v1/telescope/0/slewtocoordinates?RightAscension=%RA%&Declination=%DEC%"
echo.

echo Waiting for slew to complete...
:slewing
curl -s "http://127.0.0.1:11111/api/v1/telescope/0/slewing" > slewing_result.json
for /f "tokens=2 delims=:" %%A in ('findstr "Value" slewing_result.json') do (
  set "SLEW=%%A"
  set "SLEW=!SLEW:,=!"
  set "SLEW=!SLEW: =!"
)
if "!SLEW!"=="true" (
  timeout /t 2 >nul
  goto slewing
)

echo Slew complete.

echo.
echo Target RA: %RA%
echo Target Dec: %DEC%
echo Current RA:
curl -s "http://127.0.0.1:11111/api/v1/telescope/0/rightascension"
echo.
echo Current Dec:
curl -s "http://127.0.0.1:11111/api/v1/telescope/0/declination"
echo.

goto loop

:end
echo Goodbye!
endlocal
