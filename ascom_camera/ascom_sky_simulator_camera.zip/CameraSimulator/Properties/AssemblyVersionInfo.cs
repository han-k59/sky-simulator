﻿using System.Reflection;
using System.Runtime.CompilerServices;


[assembly: AssemblyFileVersion("6.5.5")]	    // Win32 File Version (not used by .NET)

