unit gaia_to_290unit;

//{$MODE Delphi}

{written for HNSKY and ASTAP by Han K, 2015, update 2020, updated 2023}
interface

uses
  LCLIntf, LCLType, {LMessages, Messages,} SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls,
  strutils, math,
  {$ifdef mswindows}
  windows {for shutdown}
  {$else} {unix}
   unix {for fpsystem}
  {$endif}
  ;

type

  { TMain_form }

  TMain_form = class(TForm)
    abbreviation1: TEdit;
    bp_magnitude1: TRadioButton;
    filter_star_density1: TCheckBox;
    actual_density1: TLabel;
    gaia_missing_stars1: TEdit;
    Label1: TLabel;
    Label14: TLabel;
    Label6: TLabel;
    compact_status1: TLabel;
    start_sorting_source1: TButton;
    convert_to_1476_1: TButton;
    epoch1: TEdit;
    GroupBox7: TGroupBox;
    Label22: TLabel;
    Label23: TLabel;
    Label4: TLabel;
    Label7: TLabel;
    Label_epoch: TLabel;
    stars_sorted_magn1: TLabel;
    label_filesort2: TLabel;
    sort_on_magnitude1: TButton;
    convert_to_smaller_record1: TButton;
    countstars1: TButton;
    gaia_path2: TEdit;
    GroupBox1: TGroupBox;
    GroupBox4: TGroupBox;
    GroupBox5: TGroupBox;
    GroupBox6: TGroupBox;
    Label11: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    active_file1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label5: TLabel;
    stars_done2: TLabel;
    Label8: TLabel;
    label_filesort1: TLabel;
    powerdown_enabled: TCheckBox;
    status1: TStaticText;
    step1_magnitude1: TEdit;
    edit_density1: TEdit;
    step1_maxmagnitude1: TUpDown;
    density1: TUpDown;
    epochupdown1: TUpDown;
    thefile1: TLabel;
    v_magnitude2: TRadioButton;
    V_magnitude_and_BR1: TRadioButton;
    procedure bp_magnitude1Change(Sender: TObject);
    procedure filter_star_density1Change(Sender: TObject);
    procedure start_sorting_source1Click(Sender: TObject);
    procedure convert_to_290_1Click(Sender: TObject);
    procedure sort_on_magnitude1Click(Sender: TObject);
    procedure countstars1Click(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormCreate(Sender: TObject);
    procedure convert_to_smaller_record1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;


var
  Main_form: TMain_form;
  maximum,mag_active                      :  double;
  file_counter                            : integer;
  filen_out                               : string; {file namer to write}
implementation

{$R *.lfm}
uses   unit_290;

const
dr3files : array[0..3385] of string=(
('GaiaSource_000000-003111.csv'),
('GaiaSource_003112-005263.csv'),
('GaiaSource_005264-006601.csv'),
('GaiaSource_006602-007952.csv'),
('GaiaSource_007953-010234.csv'),
('GaiaSource_010235-012597.csv'),
('GaiaSource_012598-014045.csv'),
('GaiaSource_014046-015369.csv'),
('GaiaSource_015370-016240.csv'),
('GaiaSource_016241-017018.csv'),
('GaiaSource_017019-017658.csv'),
('GaiaSource_017659-018028.csv'),
('GaiaSource_018029-018472.csv'),
('GaiaSource_018473-019161.csv'),
('GaiaSource_019162-019657.csv'),
('GaiaSource_019658-020091.csv'),
('GaiaSource_020092-020493.csv'),
('GaiaSource_020494-020747.csv'),
('GaiaSource_020748-020984.csv'),
('GaiaSource_020985-021233.csv'),
('GaiaSource_021234-021441.csv'),
('GaiaSource_021442-021665.csv'),
('GaiaSource_021666-021919.csv'),
('GaiaSource_021920-022158.csv'),
('GaiaSource_022159-022410.csv'),
('GaiaSource_022411-022698.csv'),
('GaiaSource_022699-022881.csv'),
('GaiaSource_022882-023058.csv'),
('GaiaSource_023059-023264.csv'),
('GaiaSource_023265-023450.csv'),
('GaiaSource_023451-023649.csv'),
('GaiaSource_023650-023910.csv'),
('GaiaSource_023911-024205.csv'),
('GaiaSource_024206-024526.csv'),
('GaiaSource_024527-025166.csv'),
('GaiaSource_025167-025691.csv'),
('GaiaSource_025692-026057.csv'),
('GaiaSource_026058-026390.csv'),
('GaiaSource_026391-026648.csv'),
('GaiaSource_026649-027106.csv'),
('GaiaSource_027107-027517.csv'),
('GaiaSource_027518-027832.csv'),
('GaiaSource_027833-028076.csv'),
('GaiaSource_028077-028338.csv'),
('GaiaSource_028339-028592.csv'),
('GaiaSource_028593-028826.csv'),
('GaiaSource_028827-029041.csv'),
('GaiaSource_029042-029261.csv'),
('GaiaSource_029262-029488.csv'),
('GaiaSource_029489-029738.csv'),
('GaiaSource_029739-030063.csv'),
('GaiaSource_030064-030435.csv'),
('GaiaSource_030436-030827.csv'),
('GaiaSource_030828-031045.csv'),
('GaiaSource_031046-031276.csv'),
('GaiaSource_031277-031482.csv'),
('GaiaSource_031483-031740.csv'),
('GaiaSource_031741-032189.csv'),
('GaiaSource_032190-032704.csv'),
('GaiaSource_032705-034569.csv'),
('GaiaSource_034570-036209.csv'),
('GaiaSource_036210-037375.csv'),
('GaiaSource_037376-038233.csv'),
('GaiaSource_038234-038797.csv'),
('GaiaSource_038798-039524.csv'),
('GaiaSource_039525-040135.csv'),
('GaiaSource_040136-040554.csv'),
('GaiaSource_040555-040907.csv'),
('GaiaSource_040908-041937.csv'),
('GaiaSource_041938-042766.csv'),
('GaiaSource_042767-043485.csv'),
('GaiaSource_043486-044091.csv'),
('GaiaSource_044092-044563.csv'),
('GaiaSource_044564-044916.csv'),
('GaiaSource_044917-045326.csv'),
('GaiaSource_045327-045787.csv'),
('GaiaSource_045788-046133.csv'),
('GaiaSource_046134-046433.csv'),
('GaiaSource_046434-046664.csv'),
('GaiaSource_046665-046893.csv'),
('GaiaSource_046894-047060.csv'),
('GaiaSource_047061-047323.csv'),
('GaiaSource_047324-047557.csv'),
('GaiaSource_047558-047770.csv'),
('GaiaSource_047771-047944.csv'),
('GaiaSource_047945-048099.csv'),
('GaiaSource_048100-048267.csv'),
('GaiaSource_048268-048417.csv'),
('GaiaSource_048418-048542.csv'),
('GaiaSource_048543-048681.csv'),
('GaiaSource_048682-048814.csv'),
('GaiaSource_048815-048922.csv'),
('GaiaSource_048923-049038.csv'),
('GaiaSource_049039-049162.csv'),
('GaiaSource_049163-049527.csv'),
('GaiaSource_049528-049851.csv'),
('GaiaSource_049852-050130.csv'),
('GaiaSource_050131-050376.csv'),
('GaiaSource_050377-050654.csv'),
('GaiaSource_050655-050902.csv'),
('GaiaSource_050903-051194.csv'),
('GaiaSource_051195-051461.csv'),
('GaiaSource_051462-051672.csv'),
('GaiaSource_051673-051878.csv'),
('GaiaSource_051879-052055.csv'),
('GaiaSource_052056-052208.csv'),
('GaiaSource_052209-052434.csv'),
('GaiaSource_052435-052636.csv'),
('GaiaSource_052637-052821.csv'),
('GaiaSource_052822-052987.csv'),
('GaiaSource_052988-053152.csv'),
('GaiaSource_053153-053326.csv'),
('GaiaSource_053327-053509.csv'),
('GaiaSource_053510-053785.csv'),
('GaiaSource_053786-053992.csv'),
('GaiaSource_053993-054357.csv'),
('GaiaSource_054358-054882.csv'),
('GaiaSource_054883-055358.csv'),
('GaiaSource_055359-055654.csv'),
('GaiaSource_055655-055982.csv'),
('GaiaSource_055983-056374.csv'),
('GaiaSource_056375-056973.csv'),
('GaiaSource_056974-057430.csv'),
('GaiaSource_057431-057578.csv'),
('GaiaSource_057579-057731.csv'),
('GaiaSource_057732-057872.csv'),
('GaiaSource_057873-057993.csv'),
('GaiaSource_057994-058131.csv'),
('GaiaSource_058132-058261.csv'),
('GaiaSource_058262-058417.csv'),
('GaiaSource_058418-058547.csv'),
('GaiaSource_058548-058704.csv'),
('GaiaSource_058705-058908.csv'),
('GaiaSource_058909-059070.csv'),
('GaiaSource_059071-059307.csv'),
('GaiaSource_059308-059485.csv'),
('GaiaSource_059486-059612.csv'),
('GaiaSource_059613-059764.csv'),
('GaiaSource_059765-059930.csv'),
('GaiaSource_059931-060160.csv'),
('GaiaSource_060161-060361.csv'),
('GaiaSource_060362-060555.csv'),
('GaiaSource_060556-060768.csv'),
('GaiaSource_060769-061006.csv'),
('GaiaSource_061007-061279.csv'),
('GaiaSource_061280-061679.csv'),
('GaiaSource_061680-062087.csv'),
('GaiaSource_062088-062587.csv'),
('GaiaSource_062588-063327.csv'),
('GaiaSource_063328-063878.csv'),
('GaiaSource_063879-064444.csv'),
('GaiaSource_064445-065281.csv'),
('GaiaSource_065282-066955.csv'),
('GaiaSource_066956-068628.csv'),
('GaiaSource_068629-071195.csv'),
('GaiaSource_071196-073887.csv'),
('GaiaSource_073888-075228.csv'),
('GaiaSource_075229-076419.csv'),
('GaiaSource_076420-077686.csv'),
('GaiaSource_077687-080127.csv'),
('GaiaSource_080128-082787.csv'),
('GaiaSource_082788-086703.csv'),
('GaiaSource_086704-090620.csv'),
('GaiaSource_090621-093880.csv'),
('GaiaSource_093881-097402.csv'),
('GaiaSource_097403-098884.csv'),
('GaiaSource_098885-099873.csv'),
('GaiaSource_099874-100751.csv'),
('GaiaSource_100752-101392.csv'),
('GaiaSource_101393-102417.csv'),
('GaiaSource_102418-104416.csv'),
('GaiaSource_104417-106070.csv'),
('GaiaSource_106071-106913.csv'),
('GaiaSource_106914-107444.csv'),
('GaiaSource_107445-108275.csv'),
('GaiaSource_108276-108847.csv'),
('GaiaSource_108848-109292.csv'),
('GaiaSource_109293-109810.csv'),
('GaiaSource_109811-110424.csv'),
('GaiaSource_110425-111409.csv'),
('GaiaSource_111410-112700.csv'),
('GaiaSource_112701-113459.csv'),
('GaiaSource_113460-114328.csv'),
('GaiaSource_114329-116223.csv'),
('GaiaSource_116224-118619.csv'),
('GaiaSource_118620-121499.csv'),
('GaiaSource_121500-123646.csv'),
('GaiaSource_123647-125199.csv'),
('GaiaSource_125200-126263.csv'),
('GaiaSource_126264-127785.csv'),
('GaiaSource_127786-129587.csv'),
('GaiaSource_129588-131010.csv'),
('GaiaSource_131011-132722.csv'),
('GaiaSource_132723-134879.csv'),
('GaiaSource_134880-136450.csv'),
('GaiaSource_136451-138123.csv'),
('GaiaSource_138124-140299.csv'),
('GaiaSource_140300-143213.csv'),
('GaiaSource_143214-145582.csv'),
('GaiaSource_145583-147785.csv'),
('GaiaSource_147786-148932.csv'),
('GaiaSource_148933-150327.csv'),
('GaiaSource_150328-151647.csv'),
('GaiaSource_151648-152645.csv'),
('GaiaSource_152646-153560.csv'),
('GaiaSource_153561-154811.csv'),
('GaiaSource_154812-156142.csv'),
('GaiaSource_156143-158209.csv'),
('GaiaSource_158210-160279.csv'),
('GaiaSource_160280-161702.csv'),
('GaiaSource_161703-163359.csv'),
('GaiaSource_163360-165788.csv'),
('GaiaSource_165789-169159.csv'),
('GaiaSource_169160-172467.csv'),
('GaiaSource_172468-176297.csv'),
('GaiaSource_176298-179861.csv'),
('GaiaSource_179862-182643.csv'),
('GaiaSource_182644-185173.csv'),
('GaiaSource_185174-186938.csv'),
('GaiaSource_186939-188926.csv'),
('GaiaSource_188927-191879.csv'),
('GaiaSource_191880-194042.csv'),
('GaiaSource_194043-195959.csv'),
('GaiaSource_195960-196976.csv'),
('GaiaSource_196977-197459.csv'),
('GaiaSource_197460-198140.csv'),
('GaiaSource_198141-198695.csv'),
('GaiaSource_198696-199005.csv'),
('GaiaSource_199006-199284.csv'),
('GaiaSource_199285-199493.csv'),
('GaiaSource_199494-199774.csv'),
('GaiaSource_199775-200211.csv'),
('GaiaSource_200212-200517.csv'),
('GaiaSource_200518-201151.csv'),
('GaiaSource_201152-202030.csv'),
('GaiaSource_202031-202882.csv'),
('GaiaSource_202883-203400.csv'),
('GaiaSource_203401-203842.csv'),
('GaiaSource_203843-204437.csv'),
('GaiaSource_204438-204827.csv'),
('GaiaSource_204828-204960.csv'),
('GaiaSource_204961-205073.csv'),
('GaiaSource_205074-205233.csv'),
('GaiaSource_205234-205346.csv'),
('GaiaSource_205347-205424.csv'),
('GaiaSource_205425-205483.csv'),
('GaiaSource_205484-205542.csv'),
('GaiaSource_205543-205624.csv'),
('GaiaSource_205625-205724.csv'),
('GaiaSource_205725-205802.csv'),
('GaiaSource_205803-205976.csv'),
('GaiaSource_205977-206183.csv'),
('GaiaSource_206184-206374.csv'),
('GaiaSource_206375-206497.csv'),
('GaiaSource_206498-206604.csv'),
('GaiaSource_206605-206756.csv'),
('GaiaSource_206757-206857.csv'),
('GaiaSource_206858-206892.csv'),
('GaiaSource_206893-206931.csv'),
('GaiaSource_206932-206974.csv'),
('GaiaSource_206975-207000.csv'),
('GaiaSource_207001-207023.csv'),
('GaiaSource_207024-207049.csv'),
('GaiaSource_207050-207079.csv'),
('GaiaSource_207080-207108.csv'),
('GaiaSource_207109-207165.csv'),
('GaiaSource_207166-207227.csv'),
('GaiaSource_207228-207268.csv'),
('GaiaSource_207269-207305.csv'),
('GaiaSource_207306-207349.csv'),
('GaiaSource_207350-207375.csv'),
('GaiaSource_207376-207396.csv'),
('GaiaSource_207397-207417.csv'),
('GaiaSource_207418-207440.csv'),
('GaiaSource_207441-207465.csv'),
('GaiaSource_207466-207491.csv'),
('GaiaSource_207492-207524.csv'),
('GaiaSource_207525-207556.csv'),
('GaiaSource_207557-207587.csv'),
('GaiaSource_207588-207629.csv'),
('GaiaSource_207630-207656.csv'),
('GaiaSource_207657-207681.csv'),
('GaiaSource_207682-207715.csv'),
('GaiaSource_207716-207749.csv'),
('GaiaSource_207750-207782.csv'),
('GaiaSource_207783-207819.csv'),
('GaiaSource_207820-207852.csv'),
('GaiaSource_207853-207918.csv'),
('GaiaSource_207919-208001.csv'),
('GaiaSource_208002-208052.csv'),
('GaiaSource_208053-208113.csv'),
('GaiaSource_208114-208201.csv'),
('GaiaSource_208202-208290.csv'),
('GaiaSource_208291-208363.csv'),
('GaiaSource_208364-208417.csv'),
('GaiaSource_208418-208472.csv'),
('GaiaSource_208473-208536.csv'),
('GaiaSource_208537-208596.csv'),
('GaiaSource_208597-208655.csv'),
('GaiaSource_208656-208716.csv'),
('GaiaSource_208717-208781.csv'),
('GaiaSource_208782-208874.csv'),
('GaiaSource_208875-209103.csv'),
('GaiaSource_209104-209404.csv'),
('GaiaSource_209405-209585.csv'),
('GaiaSource_209586-209771.csv'),
('GaiaSource_209772-209960.csv'),
('GaiaSource_209961-210286.csv'),
('GaiaSource_210287-210550.csv'),
('GaiaSource_210551-210734.csv'),
('GaiaSource_210735-210922.csv'),
('GaiaSource_210923-211039.csv'),
('GaiaSource_211040-211134.csv'),
('GaiaSource_211135-211238.csv'),
('GaiaSource_211239-211349.csv'),
('GaiaSource_211350-211449.csv'),
('GaiaSource_211450-211521.csv'),
('GaiaSource_211522-211601.csv'),
('GaiaSource_211602-211665.csv'),
('GaiaSource_211666-211731.csv'),
('GaiaSource_211732-211821.csv'),
('GaiaSource_211822-211890.csv'),
('GaiaSource_211891-211964.csv'),
('GaiaSource_211965-212090.csv'),
('GaiaSource_212091-212187.csv'),
('GaiaSource_212188-212305.csv'),
('GaiaSource_212306-212413.csv'),
('GaiaSource_212414-212504.csv'),
('GaiaSource_212505-212577.csv'),
('GaiaSource_212578-212643.csv'),
('GaiaSource_212644-212708.csv'),
('GaiaSource_212709-212786.csv'),
('GaiaSource_212787-212867.csv'),
('GaiaSource_212868-212939.csv'),
('GaiaSource_212940-213477.csv'),
('GaiaSource_213478-214410.csv'),
('GaiaSource_214411-215205.csv'),
('GaiaSource_215206-215772.csv'),
('GaiaSource_215773-216289.csv'),
('GaiaSource_216290-216807.csv'),
('GaiaSource_216808-217375.csv'),
('GaiaSource_217376-218124.csv'),
('GaiaSource_218125-218806.csv'),
('GaiaSource_218807-219318.csv'),
('GaiaSource_219319-219781.csv'),
('GaiaSource_219782-220140.csv'),
('GaiaSource_220141-220543.csv'),
('GaiaSource_220544-220854.csv'),
('GaiaSource_220855-221109.csv'),
('GaiaSource_221110-221396.csv'),
('GaiaSource_221397-221705.csv'),
('GaiaSource_221706-221911.csv'),
('GaiaSource_221912-222128.csv'),
('GaiaSource_222129-222387.csv'),
('GaiaSource_222388-222666.csv'),
('GaiaSource_222667-222892.csv'),
('GaiaSource_222893-223087.csv'),
('GaiaSource_223088-223243.csv'),
('GaiaSource_223244-223373.csv'),
('GaiaSource_223374-223482.csv'),
('GaiaSource_223483-223623.csv'),
('GaiaSource_223624-223735.csv'),
('GaiaSource_223736-223828.csv'),
('GaiaSource_223829-223925.csv'),
('GaiaSource_223926-223996.csv'),
('GaiaSource_223997-224078.csv'),
('GaiaSource_224079-224153.csv'),
('GaiaSource_224154-224222.csv'),
('GaiaSource_224223-224339.csv'),
('GaiaSource_224340-224445.csv'),
('GaiaSource_224446-224553.csv'),
('GaiaSource_224554-224662.csv'),
('GaiaSource_224663-224754.csv'),
('GaiaSource_224755-224837.csv'),
('GaiaSource_224838-224922.csv'),
('GaiaSource_224923-224990.csv'),
('GaiaSource_224991-225064.csv'),
('GaiaSource_225065-225139.csv'),
('GaiaSource_225140-225226.csv'),
('GaiaSource_225227-225374.csv'),
('GaiaSource_225375-225621.csv'),
('GaiaSource_225622-225827.csv'),
('GaiaSource_225828-225982.csv'),
('GaiaSource_225983-226130.csv'),
('GaiaSource_226131-226268.csv'),
('GaiaSource_226269-226461.csv'),
('GaiaSource_226462-226644.csv'),
('GaiaSource_226645-226808.csv'),
('GaiaSource_226809-226954.csv'),
('GaiaSource_226955-227087.csv'),
('GaiaSource_227088-227232.csv'),
('GaiaSource_227233-227367.csv'),
('GaiaSource_227368-227471.csv'),
('GaiaSource_227472-227559.csv'),
('GaiaSource_227560-227663.csv'),
('GaiaSource_227664-227769.csv'),
('GaiaSource_227770-227863.csv'),
('GaiaSource_227864-227939.csv'),
('GaiaSource_227940-228009.csv'),
('GaiaSource_228010-228083.csv'),
('GaiaSource_228084-228169.csv'),
('GaiaSource_228170-228250.csv'),
('GaiaSource_228251-228349.csv'),
('GaiaSource_228350-228485.csv'),
('GaiaSource_228486-228619.csv'),
('GaiaSource_228620-228780.csv'),
('GaiaSource_228781-228891.csv'),
('GaiaSource_228892-229034.csv'),
('GaiaSource_229035-229177.csv'),
('GaiaSource_229178-229302.csv'),
('GaiaSource_229303-229390.csv'),
('GaiaSource_229391-229430.csv'),
('GaiaSource_229431-229489.csv'),
('GaiaSource_229490-229523.csv'),
('GaiaSource_229524-229555.csv'),
('GaiaSource_229556-229589.csv'),
('GaiaSource_229590-229614.csv'),
('GaiaSource_229615-229654.csv'),
('GaiaSource_229655-229698.csv'),
('GaiaSource_229699-229743.csv'),
('GaiaSource_229744-229773.csv'),
('GaiaSource_229774-229797.csv'),
('GaiaSource_229798-229821.csv'),
('GaiaSource_229822-229856.csv'),
('GaiaSource_229857-229881.csv'),
('GaiaSource_229882-229915.csv'),
('GaiaSource_229916-229957.csv'),
('GaiaSource_229958-229983.csv'),
('GaiaSource_229984-230015.csv'),
('GaiaSource_230016-230070.csv'),
('GaiaSource_230071-230114.csv'),
('GaiaSource_230115-230153.csv'),
('GaiaSource_230154-230176.csv'),
('GaiaSource_230177-230205.csv'),
('GaiaSource_230206-230226.csv'),
('GaiaSource_230227-230249.csv'),
('GaiaSource_230250-230271.csv'),
('GaiaSource_230272-230308.csv'),
('GaiaSource_230309-230346.csv'),
('GaiaSource_230347-230376.csv'),
('GaiaSource_230377-230425.csv'),
('GaiaSource_230426-230485.csv'),
('GaiaSource_230486-230535.csv'),
('GaiaSource_230536-230572.csv'),
('GaiaSource_230573-230597.csv'),
('GaiaSource_230598-230627.csv'),
('GaiaSource_230628-230652.csv'),
('GaiaSource_230653-230713.csv'),
('GaiaSource_230714-230773.csv'),
('GaiaSource_230774-230814.csv'),
('GaiaSource_230815-230841.csv'),
('GaiaSource_230842-230886.csv'),
('GaiaSource_230887-230918.csv'),
('GaiaSource_230919-230937.csv'),
('GaiaSource_230938-230956.csv'),
('GaiaSource_230957-230977.csv'),
('GaiaSource_230978-231001.csv'),
('GaiaSource_231002-231022.csv'),
('GaiaSource_231023-231046.csv'),
('GaiaSource_231047-231071.csv'),
('GaiaSource_231072-231104.csv'),
('GaiaSource_231105-231128.csv'),
('GaiaSource_231129-231156.csv'),
('GaiaSource_231157-231184.csv'),
('GaiaSource_231185-231210.csv'),
('GaiaSource_231211-231239.csv'),
('GaiaSource_231240-231271.csv'),
('GaiaSource_231272-231299.csv'),
('GaiaSource_231300-231327.csv'),
('GaiaSource_231328-231356.csv'),
('GaiaSource_231357-231389.csv'),
('GaiaSource_231390-231421.csv'),
('GaiaSource_231422-231490.csv'),
('GaiaSource_231491-231557.csv'),
('GaiaSource_231558-231656.csv'),
('GaiaSource_231657-231723.csv'),
('GaiaSource_231724-231777.csv'),
('GaiaSource_231778-231849.csv'),
('GaiaSource_231850-231941.csv'),
('GaiaSource_231942-232081.csv'),
('GaiaSource_232082-232239.csv'),
('GaiaSource_232240-232374.csv'),
('GaiaSource_232375-232469.csv'),
('GaiaSource_232470-232518.csv'),
('GaiaSource_232519-232563.csv'),
('GaiaSource_232564-232637.csv'),
('GaiaSource_232638-232706.csv'),
('GaiaSource_232707-232744.csv'),
('GaiaSource_232745-232785.csv'),
('GaiaSource_232786-232828.csv'),
('GaiaSource_232829-232893.csv'),
('GaiaSource_232894-232960.csv'),
('GaiaSource_232961-233067.csv'),
('GaiaSource_233068-233208.csv'),
('GaiaSource_233209-233310.csv'),
('GaiaSource_233311-233439.csv'),
('GaiaSource_233440-233536.csv'),
('GaiaSource_233537-233621.csv'),
('GaiaSource_233622-233685.csv'),
('GaiaSource_233686-233763.csv'),
('GaiaSource_233764-233870.csv'),
('GaiaSource_233871-233990.csv'),
('GaiaSource_233991-234036.csv'),
('GaiaSource_234037-234088.csv'),
('GaiaSource_234089-234136.csv'),
('GaiaSource_234137-234167.csv'),
('GaiaSource_234168-234201.csv'),
('GaiaSource_234202-234231.csv'),
('GaiaSource_234232-234281.csv'),
('GaiaSource_234282-234353.csv'),
('GaiaSource_234354-234404.csv'),
('GaiaSource_234405-234462.csv'),
('GaiaSource_234463-234557.csv'),
('GaiaSource_234558-234761.csv'),
('GaiaSource_234762-234910.csv'),
('GaiaSource_234911-235142.csv'),
('GaiaSource_235143-235362.csv'),
('GaiaSource_235363-235470.csv'),
('GaiaSource_235471-235539.csv'),
('GaiaSource_235540-235578.csv'),
('GaiaSource_235579-235616.csv'),
('GaiaSource_235617-235665.csv'),
('GaiaSource_235666-235729.csv'),
('GaiaSource_235730-235789.csv'),
('GaiaSource_235790-235835.csv'),
('GaiaSource_235836-235897.csv'),
('GaiaSource_235898-235967.csv'),
('GaiaSource_235968-236056.csv'),
('GaiaSource_236057-236161.csv'),
('GaiaSource_236162-236297.csv'),
('GaiaSource_236298-236416.csv'),
('GaiaSource_236417-236571.csv'),
('GaiaSource_236572-236697.csv'),
('GaiaSource_236698-236806.csv'),
('GaiaSource_236807-236905.csv'),
('GaiaSource_236906-237015.csv'),
('GaiaSource_237016-237137.csv'),
('GaiaSource_237138-237296.csv'),
('GaiaSource_237297-237433.csv'),
('GaiaSource_237434-237632.csv'),
('GaiaSource_237633-237872.csv'),
('GaiaSource_237873-238118.csv'),
('GaiaSource_238119-238460.csv'),
('GaiaSource_238461-238723.csv'),
('GaiaSource_238724-238940.csv'),
('GaiaSource_238941-239195.csv'),
('GaiaSource_239196-239551.csv'),
('GaiaSource_239552-240020.csv'),
('GaiaSource_240021-240665.csv'),
('GaiaSource_240666-241246.csv'),
('GaiaSource_241247-241760.csv'),
('GaiaSource_241761-241998.csv'),
('GaiaSource_241999-242292.csv'),
('GaiaSource_242293-242704.csv'),
('GaiaSource_242705-242977.csv'),
('GaiaSource_242978-243318.csv'),
('GaiaSource_243319-243830.csv'),
('GaiaSource_243831-244594.csv'),
('GaiaSource_244595-245391.csv'),
('GaiaSource_245392-245829.csv'),
('GaiaSource_245830-245886.csv'),
('GaiaSource_245887-245969.csv'),
('GaiaSource_245970-246030.csv'),
('GaiaSource_246031-246093.csv'),
('GaiaSource_246094-246173.csv'),
('GaiaSource_246174-246265.csv'),
('GaiaSource_246266-246342.csv'),
('GaiaSource_246343-246433.csv'),
('GaiaSource_246434-246546.csv'),
('GaiaSource_246547-246712.csv'),
('GaiaSource_246713-246843.csv'),
('GaiaSource_246844-246939.csv'),
('GaiaSource_246940-247052.csv'),
('GaiaSource_247053-247138.csv'),
('GaiaSource_247139-247232.csv'),
('GaiaSource_247233-247376.csv'),
('GaiaSource_247377-247496.csv'),
('GaiaSource_247497-247595.csv'),
('GaiaSource_247596-247690.csv'),
('GaiaSource_247691-247808.csv'),
('GaiaSource_247809-247921.csv'),
('GaiaSource_247922-248023.csv'),
('GaiaSource_248024-248140.csv'),
('GaiaSource_248141-248260.csv'),
('GaiaSource_248261-248409.csv'),
('GaiaSource_248410-248615.csv'),
('GaiaSource_248616-248843.csv'),
('GaiaSource_248844-248985.csv'),
('GaiaSource_248986-249150.csv'),
('GaiaSource_249151-249315.csv'),
('GaiaSource_249316-249570.csv'),
('GaiaSource_249571-249860.csv'),
('GaiaSource_249861-249951.csv'),
('GaiaSource_249952-250048.csv'),
('GaiaSource_250049-250171.csv'),
('GaiaSource_250172-250299.csv'),
('GaiaSource_250300-250414.csv'),
('GaiaSource_250415-250504.csv'),
('GaiaSource_250505-250614.csv'),
('GaiaSource_250615-250751.csv'),
('GaiaSource_250752-250918.csv'),
('GaiaSource_250919-251079.csv'),
('GaiaSource_251080-251247.csv'),
('GaiaSource_251248-251438.csv'),
('GaiaSource_251439-251654.csv'),
('GaiaSource_251655-251873.csv'),
('GaiaSource_251874-252017.csv'),
('GaiaSource_252018-252204.csv'),
('GaiaSource_252205-252406.csv'),
('GaiaSource_252407-252718.csv'),
('GaiaSource_252719-253015.csv'),
('GaiaSource_253016-253253.csv'),
('GaiaSource_253254-253549.csv'),
('GaiaSource_253550-253946.csv'),
('GaiaSource_253947-254266.csv'),
('GaiaSource_254267-254684.csv'),
('GaiaSource_254685-255145.csv'),
('GaiaSource_255146-255619.csv'),
('GaiaSource_255620-256329.csv'),
('GaiaSource_256330-257285.csv'),
('GaiaSource_257286-258178.csv'),
('GaiaSource_258179-258805.csv'),
('GaiaSource_258806-259423.csv'),
('GaiaSource_259424-260097.csv'),
('GaiaSource_260098-261095.csv'),
('GaiaSource_261096-262133.csv'),
('GaiaSource_262134-265343.csv'),
('GaiaSource_265344-268719.csv'),
('GaiaSource_268720-271830.csv'),
('GaiaSource_271831-274602.csv'),
('GaiaSource_274603-277912.csv'),
('GaiaSource_277913-281529.csv'),
('GaiaSource_281530-285121.csv'),
('GaiaSource_285122-288626.csv'),
('GaiaSource_288627-292004.csv'),
('GaiaSource_292005-295159.csv'),
('GaiaSource_295160-297430.csv'),
('GaiaSource_297431-299572.csv'),
('GaiaSource_299573-302248.csv'),
('GaiaSource_302249-303999.csv'),
('GaiaSource_304000-305414.csv'),
('GaiaSource_305415-306306.csv'),
('GaiaSource_306307-307590.csv'),
('GaiaSource_307591-309467.csv'),
('GaiaSource_309468-310877.csv'),
('GaiaSource_310878-313367.csv'),
('GaiaSource_313368-315968.csv'),
('GaiaSource_315969-318482.csv'),
('GaiaSource_318483-320528.csv'),
('GaiaSource_320529-322281.csv'),
('GaiaSource_322282-323754.csv'),
('GaiaSource_323755-325433.csv'),
('GaiaSource_325434-326719.csv'),
('GaiaSource_326720-327760.csv'),
('GaiaSource_327761-328727.csv'),
('GaiaSource_328728-329262.csv'),
('GaiaSource_329263-329984.csv'),
('GaiaSource_329985-331030.csv'),
('GaiaSource_331031-331736.csv'),
('GaiaSource_331737-332053.csv'),
('GaiaSource_332054-332244.csv'),
('GaiaSource_332245-332549.csv'),
('GaiaSource_332550-332784.csv'),
('GaiaSource_332785-332914.csv'),
('GaiaSource_332915-333054.csv'),
('GaiaSource_333055-333167.csv'),
('GaiaSource_333168-333325.csv'),
('GaiaSource_333326-333491.csv'),
('GaiaSource_333492-333648.csv'),
('GaiaSource_333649-333789.csv'),
('GaiaSource_333790-334119.csv'),
('GaiaSource_334120-334488.csv'),
('GaiaSource_334489-334876.csv'),
('GaiaSource_334877-335112.csv'),
('GaiaSource_335113-335279.csv'),
('GaiaSource_335280-335500.csv'),
('GaiaSource_335501-335732.csv'),
('GaiaSource_335733-336328.csv'),
('GaiaSource_336329-337476.csv'),
('GaiaSource_337477-338947.csv'),
('GaiaSource_338948-340106.csv'),
('GaiaSource_340107-340703.csv'),
('GaiaSource_340704-341200.csv'),
('GaiaSource_341201-341491.csv'),
('GaiaSource_341492-341904.csv'),
('GaiaSource_341905-342641.csv'),
('GaiaSource_342642-343376.csv'),
('GaiaSource_343377-343894.csv'),
('GaiaSource_343895-344169.csv'),
('GaiaSource_344170-344328.csv'),
('GaiaSource_344329-344484.csv'),
('GaiaSource_344485-344636.csv'),
('GaiaSource_344637-344768.csv'),
('GaiaSource_344769-344904.csv'),
('GaiaSource_344905-345055.csv'),
('GaiaSource_345056-345271.csv'),
('GaiaSource_345272-345589.csv'),
('GaiaSource_345590-345805.csv'),
('GaiaSource_345806-346109.csv'),
('GaiaSource_346110-346273.csv'),
('GaiaSource_346274-346449.csv'),
('GaiaSource_346450-346603.csv'),
('GaiaSource_346604-346789.csv'),
('GaiaSource_346790-346962.csv'),
('GaiaSource_346963-347122.csv'),
('GaiaSource_347123-347301.csv'),
('GaiaSource_347302-347543.csv'),
('GaiaSource_347544-347757.csv'),
('GaiaSource_347758-347937.csv'),
('GaiaSource_347938-348215.csv'),
('GaiaSource_348216-348780.csv'),
('GaiaSource_348781-349438.csv'),
('GaiaSource_349439-350312.csv'),
('GaiaSource_350313-350776.csv'),
('GaiaSource_350777-351214.csv'),
('GaiaSource_351215-352026.csv'),
('GaiaSource_352027-352381.csv'),
('GaiaSource_352382-352553.csv'),
('GaiaSource_352554-352745.csv'),
('GaiaSource_352746-352945.csv'),
('GaiaSource_352946-353142.csv'),
('GaiaSource_353143-353319.csv'),
('GaiaSource_353320-353484.csv'),
('GaiaSource_353485-353689.csv'),
('GaiaSource_353690-353884.csv'),
('GaiaSource_353885-354063.csv'),
('GaiaSource_354064-354271.csv'),
('GaiaSource_354272-354513.csv'),
('GaiaSource_354514-354732.csv'),
('GaiaSource_354733-355017.csv'),
('GaiaSource_355018-355271.csv'),
('GaiaSource_355272-355472.csv'),
('GaiaSource_355473-355681.csv'),
('GaiaSource_355682-355916.csv'),
('GaiaSource_355917-356140.csv'),
('GaiaSource_356141-356343.csv'),
('GaiaSource_356344-356711.csv'),
('GaiaSource_356712-357062.csv'),
('GaiaSource_357063-357507.csv'),
('GaiaSource_357508-358174.csv'),
('GaiaSource_358175-358573.csv'),
('GaiaSource_358574-358905.csv'),
('GaiaSource_358906-359128.csv'),
('GaiaSource_359129-359433.csv'),
('GaiaSource_359434-360011.csv'),
('GaiaSource_360012-360924.csv'),
('GaiaSource_360925-362746.csv'),
('GaiaSource_362747-364664.csv'),
('GaiaSource_364665-365697.csv'),
('GaiaSource_365698-366387.csv'),
('GaiaSource_366388-367348.csv'),
('GaiaSource_367349-368119.csv'),
('GaiaSource_368120-369507.csv'),
('GaiaSource_369508-372122.csv'),
('GaiaSource_372123-373830.csv'),
('GaiaSource_373831-374689.csv'),
('GaiaSource_374690-376185.csv'),
('GaiaSource_376186-377043.csv'),
('GaiaSource_377044-377320.csv'),
('GaiaSource_377321-377721.csv'),
('GaiaSource_377722-377964.csv'),
('GaiaSource_377965-378154.csv'),
('GaiaSource_378155-378388.csv'),
('GaiaSource_378389-378603.csv'),
('GaiaSource_378604-378818.csv'),
('GaiaSource_378819-379202.csv'),
('GaiaSource_379203-379639.csv'),
('GaiaSource_379640-379982.csv'),
('GaiaSource_379983-380228.csv'),
('GaiaSource_380229-380497.csv'),
('GaiaSource_380498-380760.csv'),
('GaiaSource_380761-381019.csv'),
('GaiaSource_381020-381249.csv'),
('GaiaSource_381250-381508.csv'),
('GaiaSource_381509-381729.csv'),
('GaiaSource_381730-382004.csv'),
('GaiaSource_382005-382489.csv'),
('GaiaSource_382490-382890.csv'),
('GaiaSource_382891-383160.csv'),
('GaiaSource_383161-383394.csv'),
('GaiaSource_383395-383669.csv'),
('GaiaSource_383670-383945.csv'),
('GaiaSource_383946-384257.csv'),
('GaiaSource_384258-384632.csv'),
('GaiaSource_384633-384965.csv'),
('GaiaSource_384966-385514.csv'),
('GaiaSource_385515-386055.csv'),
('GaiaSource_386056-386353.csv'),
('GaiaSource_386354-386630.csv'),
('GaiaSource_386631-386952.csv'),
('GaiaSource_386953-387478.csv'),
('GaiaSource_387479-388085.csv'),
('GaiaSource_388086-388492.csv'),
('GaiaSource_388493-388906.csv'),
('GaiaSource_388907-389234.csv'),
('GaiaSource_389235-389475.csv'),
('GaiaSource_389476-389705.csv'),
('GaiaSource_389706-389956.csv'),
('GaiaSource_389957-390171.csv'),
('GaiaSource_390172-390461.csv'),
('GaiaSource_390462-390794.csv'),
('GaiaSource_390795-391119.csv'),
('GaiaSource_391120-391425.csv'),
('GaiaSource_391426-391647.csv'),
('GaiaSource_391648-391896.csv'),
('GaiaSource_391897-392136.csv'),
('GaiaSource_392137-392372.csv'),
('GaiaSource_392373-392688.csv'),
('GaiaSource_392689-392957.csv'),
('GaiaSource_392958-393300.csv'),
('GaiaSource_393301-393942.csv'),
('GaiaSource_393943-394782.csv'),
('GaiaSource_394783-395711.csv'),
('GaiaSource_395712-396808.csv'),
('GaiaSource_396809-398019.csv'),
('GaiaSource_398020-399463.csv'),
('GaiaSource_399464-401059.csv'),
('GaiaSource_401060-402397.csv'),
('GaiaSource_402398-403911.csv'),
('GaiaSource_403912-405723.csv'),
('GaiaSource_405724-407724.csv'),
('GaiaSource_407725-409897.csv'),
('GaiaSource_409898-411611.csv'),
('GaiaSource_411612-413663.csv'),
('GaiaSource_413664-415451.csv'),
('GaiaSource_415452-417656.csv'),
('GaiaSource_417657-419980.csv'),
('GaiaSource_419981-422586.csv'),
('GaiaSource_422587-425371.csv'),
('GaiaSource_425372-427563.csv'),
('GaiaSource_427564-429762.csv'),
('GaiaSource_429763-432522.csv'),
('GaiaSource_432523-435127.csv'),
('GaiaSource_435128-437342.csv'),
('GaiaSource_437343-440355.csv'),
('GaiaSource_440356-443548.csv'),
('GaiaSource_443549-446880.csv'),
('GaiaSource_446881-450181.csv'),
('GaiaSource_450182-453970.csv'),
('GaiaSource_453971-458057.csv'),
('GaiaSource_458058-458769.csv'),
('GaiaSource_458770-458787.csv'),
('GaiaSource_458788-458803.csv'),
('GaiaSource_458804-458820.csv'),
('GaiaSource_458821-458839.csv'),
('GaiaSource_458840-458855.csv'),
('GaiaSource_458856-458869.csv'),
('GaiaSource_458870-458882.csv'),
('GaiaSource_458883-458896.csv'),
('GaiaSource_458897-458909.csv'),
('GaiaSource_458910-458921.csv'),
('GaiaSource_458922-458933.csv'),
('GaiaSource_458934-458945.csv'),
('GaiaSource_458946-458957.csv'),
('GaiaSource_458958-458969.csv'),
('GaiaSource_458970-458980.csv'),
('GaiaSource_458981-458991.csv'),
('GaiaSource_458992-459002.csv'),
('GaiaSource_459003-459018.csv'),
('GaiaSource_459019-459037.csv'),
('GaiaSource_459038-459052.csv'),
('GaiaSource_459053-459066.csv'),
('GaiaSource_459067-459083.csv'),
('GaiaSource_459084-459103.csv'),
('GaiaSource_459104-459119.csv'),
('GaiaSource_459120-459135.csv'),
('GaiaSource_459136-459147.csv'),
('GaiaSource_459148-459159.csv'),
('GaiaSource_459160-459170.csv'),
('GaiaSource_459171-459181.csv'),
('GaiaSource_459182-459192.csv'),
('GaiaSource_459193-459204.csv'),
('GaiaSource_459205-459216.csv'),
('GaiaSource_459217-459229.csv'),
('GaiaSource_459230-459241.csv'),
('GaiaSource_459242-459252.csv'),
('GaiaSource_459253-459263.csv'),
('GaiaSource_459264-459275.csv'),
('GaiaSource_459276-459287.csv'),
('GaiaSource_459288-459299.csv'),
('GaiaSource_459300-459311.csv'),
('GaiaSource_459312-459323.csv'),
('GaiaSource_459324-459334.csv'),
('GaiaSource_459335-459345.csv'),
('GaiaSource_459346-459356.csv'),
('GaiaSource_459357-459366.csv'),
('GaiaSource_459367-459376.csv'),
('GaiaSource_459377-459387.csv'),
('GaiaSource_459388-459401.csv'),
('GaiaSource_459402-459414.csv'),
('GaiaSource_459415-459427.csv'),
('GaiaSource_459428-459440.csv'),
('GaiaSource_459441-459452.csv'),
('GaiaSource_459453-459463.csv'),
('GaiaSource_459464-459474.csv'),
('GaiaSource_459475-459486.csv'),
('GaiaSource_459487-459497.csv'),
('GaiaSource_459498-459509.csv'),
('GaiaSource_459510-459521.csv'),
('GaiaSource_459522-459531.csv'),
('GaiaSource_459532-459542.csv'),
('GaiaSource_459543-459553.csv'),
('GaiaSource_459554-459563.csv'),
('GaiaSource_459564-459574.csv'),
('GaiaSource_459575-459585.csv'),
('GaiaSource_459586-459596.csv'),
('GaiaSource_459597-459607.csv'),
('GaiaSource_459608-459618.csv'),
('GaiaSource_459619-459629.csv'),
('GaiaSource_459630-459640.csv'),
('GaiaSource_459641-459651.csv'),
('GaiaSource_459652-459663.csv'),
('GaiaSource_459664-459674.csv'),
('GaiaSource_459675-459686.csv'),
('GaiaSource_459687-459698.csv'),
('GaiaSource_459699-459709.csv'),
('GaiaSource_459710-459720.csv'),
('GaiaSource_459721-459732.csv'),
('GaiaSource_459733-459744.csv'),
('GaiaSource_459745-459755.csv'),
('GaiaSource_459756-459766.csv'),
('GaiaSource_459767-459779.csv'),
('GaiaSource_459780-459800.csv'),
('GaiaSource_459801-459817.csv'),
('GaiaSource_459818-459833.csv'),
('GaiaSource_459834-459853.csv'),
('GaiaSource_459854-459874.csv'),
('GaiaSource_459875-459892.csv'),
('GaiaSource_459893-459908.csv'),
('GaiaSource_459909-459921.csv'),
('GaiaSource_459922-459934.csv'),
('GaiaSource_459935-459946.csv'),
('GaiaSource_459947-459958.csv'),
('GaiaSource_459959-459971.csv'),
('GaiaSource_459972-459986.csv'),
('GaiaSource_459987-460000.csv'),
('GaiaSource_460001-460012.csv'),
('GaiaSource_460013-460024.csv'),
('GaiaSource_460025-460041.csv'),
('GaiaSource_460042-460064.csv'),
('GaiaSource_460065-460082.csv'),
('GaiaSource_460083-460104.csv'),
('GaiaSource_460105-460129.csv'),
('GaiaSource_460130-460150.csv'),
('GaiaSource_460151-460168.csv'),
('GaiaSource_460169-460183.csv'),
('GaiaSource_460184-460197.csv'),
('GaiaSource_460198-460210.csv'),
('GaiaSource_460211-460223.csv'),
('GaiaSource_460224-460241.csv'),
('GaiaSource_460242-460258.csv'),
('GaiaSource_460259-460272.csv'),
('GaiaSource_460273-460287.csv'),
('GaiaSource_460288-460298.csv'),
('GaiaSource_460299-460309.csv'),
('GaiaSource_460310-460320.csv'),
('GaiaSource_460321-460331.csv'),
('GaiaSource_460332-460342.csv'),
('GaiaSource_460343-460353.csv'),
('GaiaSource_460354-460364.csv'),
('GaiaSource_460365-460375.csv'),
('GaiaSource_460376-460386.csv'),
('GaiaSource_460387-460397.csv'),
('GaiaSource_460398-460408.csv'),
('GaiaSource_460409-460419.csv'),
('GaiaSource_460420-460430.csv'),
('GaiaSource_460431-460441.csv'),
('GaiaSource_460442-460452.csv'),
('GaiaSource_460453-460463.csv'),
('GaiaSource_460464-460474.csv'),
('GaiaSource_460475-460484.csv'),
('GaiaSource_460485-460495.csv'),
('GaiaSource_460496-460506.csv'),
('GaiaSource_460507-460517.csv'),
('GaiaSource_460518-460527.csv'),
('GaiaSource_460528-460538.csv'),
('GaiaSource_460539-460549.csv'),
('GaiaSource_460550-460560.csv'),
('GaiaSource_460561-460571.csv'),
('GaiaSource_460572-460582.csv'),
('GaiaSource_460583-460593.csv'),
('GaiaSource_460594-460604.csv'),
('GaiaSource_460605-460616.csv'),
('GaiaSource_460617-460629.csv'),
('GaiaSource_460630-460641.csv'),
('GaiaSource_460642-460652.csv'),
('GaiaSource_460653-460664.csv'),
('GaiaSource_460665-460675.csv'),
('GaiaSource_460676-460686.csv'),
('GaiaSource_460687-460697.csv'),
('GaiaSource_460698-460708.csv'),
('GaiaSource_460709-460719.csv'),
('GaiaSource_460720-460730.csv'),
('GaiaSource_460731-460740.csv'),
('GaiaSource_460741-460751.csv'),
('GaiaSource_460752-460762.csv'),
('GaiaSource_460763-460773.csv'),
('GaiaSource_460774-460784.csv'),
('GaiaSource_460785-460795.csv'),
('GaiaSource_460796-460809.csv'),
('GaiaSource_460810-460823.csv'),
('GaiaSource_460824-460841.csv'),
('GaiaSource_460842-460864.csv'),
('GaiaSource_460865-460879.csv'),
('GaiaSource_460880-460899.csv'),
('GaiaSource_460900-460941.csv'),
('GaiaSource_460942-460995.csv'),
('GaiaSource_460996-461057.csv'),
('GaiaSource_461058-461084.csv'),
('GaiaSource_461085-461111.csv'),
('GaiaSource_461112-461127.csv'),
('GaiaSource_461128-461139.csv'),
('GaiaSource_461140-461150.csv'),
('GaiaSource_461151-461161.csv'),
('GaiaSource_461162-461172.csv'),
('GaiaSource_461173-461183.csv'),
('GaiaSource_461184-461253.csv'),
('GaiaSource_461254-461275.csv'),
('GaiaSource_461276-461325.csv'),
('GaiaSource_461326-461348.csv'),
('GaiaSource_461349-461373.csv'),
('GaiaSource_461374-461389.csv'),
('GaiaSource_461390-461403.csv'),
('GaiaSource_461404-461416.csv'),
('GaiaSource_461417-461429.csv'),
('GaiaSource_461430-461447.csv'),
('GaiaSource_461448-461462.csv'),
('GaiaSource_461463-461475.csv'),
('GaiaSource_461476-461487.csv'),
('GaiaSource_461488-461499.csv'),
('GaiaSource_461500-461512.csv'),
('GaiaSource_461513-461524.csv'),
('GaiaSource_461525-461537.csv'),
('GaiaSource_461538-461553.csv'),
('GaiaSource_461554-461567.csv'),
('GaiaSource_461568-461582.csv'),
('GaiaSource_461583-461601.csv'),
('GaiaSource_461602-461616.csv'),
('GaiaSource_461617-461632.csv'),
('GaiaSource_461633-461658.csv'),
('GaiaSource_461659-461672.csv'),
('GaiaSource_461673-461687.csv'),
('GaiaSource_461688-461701.csv'),
('GaiaSource_461702-461715.csv'),
('GaiaSource_461716-461730.csv'),
('GaiaSource_461731-461755.csv'),
('GaiaSource_461756-461775.csv'),
('GaiaSource_461776-461792.csv'),
('GaiaSource_461793-461823.csv'),
('GaiaSource_461824-461834.csv'),
('GaiaSource_461835-461844.csv'),
('GaiaSource_461845-461855.csv'),
('GaiaSource_461856-461866.csv'),
('GaiaSource_461867-461877.csv'),
('GaiaSource_461878-461888.csv'),
('GaiaSource_461889-461899.csv'),
('GaiaSource_461900-461910.csv'),
('GaiaSource_461911-461921.csv'),
('GaiaSource_461922-461932.csv'),
('GaiaSource_461933-461943.csv'),
('GaiaSource_461944-461955.csv'),
('GaiaSource_461956-461972.csv'),
('GaiaSource_461973-462015.csv'),
('GaiaSource_462016-462031.csv'),
('GaiaSource_462032-462055.csv'),
('GaiaSource_462056-462083.csv'),
('GaiaSource_462084-462094.csv'),
('GaiaSource_462095-462105.csv'),
('GaiaSource_462106-462116.csv'),
('GaiaSource_462117-462127.csv'),
('GaiaSource_462128-462139.csv'),
('GaiaSource_462140-462151.csv'),
('GaiaSource_462152-462162.csv'),
('GaiaSource_462163-462172.csv'),
('GaiaSource_462173-462184.csv'),
('GaiaSource_462185-462197.csv'),
('GaiaSource_462198-462208.csv'),
('GaiaSource_462209-462224.csv'),
('GaiaSource_462225-462254.csv'),
('GaiaSource_462255-462285.csv'),
('GaiaSource_462286-462299.csv'),
('GaiaSource_462300-462321.csv'),
('GaiaSource_462322-462347.csv'),
('GaiaSource_462348-462377.csv'),
('GaiaSource_462378-462401.csv'),
('GaiaSource_462402-462443.csv'),
('GaiaSource_462444-462467.csv'),
('GaiaSource_462468-462482.csv'),
('GaiaSource_462483-462496.csv'),
('GaiaSource_462497-462509.csv'),
('GaiaSource_462510-462521.csv'),
('GaiaSource_462522-462534.csv'),
('GaiaSource_462535-462547.csv'),
('GaiaSource_462548-462560.csv'),
('GaiaSource_462561-462571.csv'),
('GaiaSource_462572-462583.csv'),
('GaiaSource_462584-462612.csv'),
('GaiaSource_462613-462653.csv'),
('GaiaSource_462654-462702.csv'),
('GaiaSource_462703-462731.csv'),
('GaiaSource_462732-462754.csv'),
('GaiaSource_462755-462768.csv'),
('GaiaSource_462769-462784.csv'),
('GaiaSource_462785-462817.csv'),
('GaiaSource_462818-462831.csv'),
('GaiaSource_462832-462858.csv'),
('GaiaSource_462859-462887.csv'),
('GaiaSource_462888-462913.csv'),
('GaiaSource_462914-462954.csv'),
('GaiaSource_462955-462984.csv'),
('GaiaSource_462985-463007.csv'),
('GaiaSource_463008-463024.csv'),
('GaiaSource_463025-463048.csv'),
('GaiaSource_463049-463078.csv'),
('GaiaSource_463079-463105.csv'),
('GaiaSource_463106-463160.csv'),
('GaiaSource_463161-463223.csv'),
('GaiaSource_463224-463267.csv'),
('GaiaSource_463268-463307.csv'),
('GaiaSource_463308-463352.csv'),
('GaiaSource_463353-463371.csv'),
('GaiaSource_463372-463390.csv'),
('GaiaSource_463391-463403.csv'),
('GaiaSource_463404-463417.csv'),
('GaiaSource_463418-463434.csv'),
('GaiaSource_463435-463455.csv'),
('GaiaSource_463456-463471.csv'),
('GaiaSource_463472-463488.csv'),
('GaiaSource_463489-463500.csv'),
('GaiaSource_463501-463512.csv'),
('GaiaSource_463513-463524.csv'),
('GaiaSource_463525-463535.csv'),
('GaiaSource_463536-463548.csv'),
('GaiaSource_463549-463561.csv'),
('GaiaSource_463562-463575.csv'),
('GaiaSource_463576-463589.csv'),
('GaiaSource_463590-463602.csv'),
('GaiaSource_463603-463615.csv'),
('GaiaSource_463616-463646.csv'),
('GaiaSource_463647-463668.csv'),
('GaiaSource_463669-463701.csv'),
('GaiaSource_463702-463734.csv'),
('GaiaSource_463735-463755.csv'),
('GaiaSource_463756-463776.csv'),
('GaiaSource_463777-463791.csv'),
('GaiaSource_463792-463810.csv'),
('GaiaSource_463811-463839.csv'),
('GaiaSource_463840-463862.csv'),
('GaiaSource_463863-463919.csv'),
('GaiaSource_463920-464003.csv'),
('GaiaSource_464004-464058.csv'),
('GaiaSource_464059-464123.csv'),
('GaiaSource_464124-464225.csv'),
('GaiaSource_464226-464311.csv'),
('GaiaSource_464312-464390.csv'),
('GaiaSource_464391-464430.csv'),
('GaiaSource_464431-464477.csv'),
('GaiaSource_464478-464519.csv'),
('GaiaSource_464520-464548.csv'),
('GaiaSource_464549-464574.csv'),
('GaiaSource_464575-464611.csv'),
('GaiaSource_464612-464647.csv'),
('GaiaSource_464648-464704.csv'),
('GaiaSource_464705-464770.csv'),
('GaiaSource_464771-464814.csv'),
('GaiaSource_464815-464863.csv'),
('GaiaSource_464864-464898.csv'),
('GaiaSource_464899-464909.csv'),
('GaiaSource_464910-464920.csv'),
('GaiaSource_464921-464931.csv'),
('GaiaSource_464932-464942.csv'),
('GaiaSource_464943-464954.csv'),
('GaiaSource_464955-464966.csv'),
('GaiaSource_464967-464977.csv'),
('GaiaSource_464978-464989.csv'),
('GaiaSource_464990-465001.csv'),
('GaiaSource_465002-465013.csv'),
('GaiaSource_465014-465026.csv'),
('GaiaSource_465027-465038.csv'),
('GaiaSource_465039-465051.csv'),
('GaiaSource_465052-465064.csv'),
('GaiaSource_465065-465081.csv'),
('GaiaSource_465082-465096.csv'),
('GaiaSource_465097-465111.csv'),
('GaiaSource_465112-465136.csv'),
('GaiaSource_465137-465152.csv'),
('GaiaSource_465153-465165.csv'),
('GaiaSource_465166-465180.csv'),
('GaiaSource_465181-465194.csv'),
('GaiaSource_465195-465208.csv'),
('GaiaSource_465209-465224.csv'),
('GaiaSource_465225-465243.csv'),
('GaiaSource_465244-465260.csv'),
('GaiaSource_465261-465278.csv'),
('GaiaSource_465279-465294.csv'),
('GaiaSource_465295-465308.csv'),
('GaiaSource_465309-465323.csv'),
('GaiaSource_465324-465336.csv'),
('GaiaSource_465337-465350.csv'),
('GaiaSource_465351-465366.csv'),
('GaiaSource_465367-465381.csv'),
('GaiaSource_465382-465396.csv'),
('GaiaSource_465397-465414.csv'),
('GaiaSource_465415-465444.csv'),
('GaiaSource_465445-465494.csv'),
('GaiaSource_465495-465527.csv'),
('GaiaSource_465528-465573.csv'),
('GaiaSource_465574-465614.csv'),
('GaiaSource_465615-465669.csv'),
('GaiaSource_465670-465687.csv'),
('GaiaSource_465688-465702.csv'),
('GaiaSource_465703-465718.csv'),
('GaiaSource_465719-465736.csv'),
('GaiaSource_465737-465750.csv'),
('GaiaSource_465751-465767.csv'),
('GaiaSource_465768-465790.csv'),
('GaiaSource_465791-465853.csv'),
('GaiaSource_465854-465894.csv'),
('GaiaSource_465895-465933.csv'),
('GaiaSource_465934-465956.csv'),
('GaiaSource_465957-465976.csv'),
('GaiaSource_465977-466001.csv'),
('GaiaSource_466002-466027.csv'),
('GaiaSource_466028-466051.csv'),
('GaiaSource_466052-466068.csv'),
('GaiaSource_466069-466085.csv'),
('GaiaSource_466086-466100.csv'),
('GaiaSource_466101-466119.csv'),
('GaiaSource_466120-466141.csv'),
('GaiaSource_466142-466158.csv'),
('GaiaSource_466159-466179.csv'),
('GaiaSource_466180-466214.csv'),
('GaiaSource_466215-466248.csv'),
('GaiaSource_466249-466288.csv'),
('GaiaSource_466289-466318.csv'),
('GaiaSource_466319-466344.csv'),
('GaiaSource_466345-466369.csv'),
('GaiaSource_466370-466401.csv'),
('GaiaSource_466402-466429.csv'),
('GaiaSource_466430-466444.csv'),
('GaiaSource_466445-466463.csv'),
('GaiaSource_466464-466483.csv'),
('GaiaSource_466484-466497.csv'),
('GaiaSource_466498-466513.csv'),
('GaiaSource_466514-466531.csv'),
('GaiaSource_466532-466546.csv'),
('GaiaSource_466547-466565.csv'),
('GaiaSource_466566-466579.csv'),
('GaiaSource_466580-466596.csv'),
('GaiaSource_466597-466624.csv'),
('GaiaSource_466625-466637.csv'),
('GaiaSource_466638-466653.csv'),
('GaiaSource_466654-466671.csv'),
('GaiaSource_466672-466690.csv'),
('GaiaSource_466691-466716.csv'),
('GaiaSource_466717-466737.csv'),
('GaiaSource_466738-466761.csv'),
('GaiaSource_466762-466787.csv'),
('GaiaSource_466788-466810.csv'),
('GaiaSource_466811-466829.csv'),
('GaiaSource_466830-466850.csv'),
('GaiaSource_466851-466870.csv'),
('GaiaSource_466871-466889.csv'),
('GaiaSource_466890-466905.csv'),
('GaiaSource_466906-466920.csv'),
('GaiaSource_466921-466936.csv'),
('GaiaSource_466937-466949.csv'),
('GaiaSource_466950-466960.csv'),
('GaiaSource_466961-466971.csv'),
('GaiaSource_466972-466982.csv'),
('GaiaSource_466983-466994.csv'),
('GaiaSource_466995-467008.csv'),
('GaiaSource_467009-467023.csv'),
('GaiaSource_467024-467042.csv'),
('GaiaSource_467043-467066.csv'),
('GaiaSource_467067-467079.csv'),
('GaiaSource_467080-467100.csv'),
('GaiaSource_467101-467117.csv'),
('GaiaSource_467118-467132.csv'),
('GaiaSource_467133-467151.csv'),
('GaiaSource_467152-467167.csv'),
('GaiaSource_467168-467184.csv'),
('GaiaSource_467185-467207.csv'),
('GaiaSource_467208-467232.csv'),
('GaiaSource_467233-467243.csv'),
('GaiaSource_467244-467255.csv'),
('GaiaSource_467256-467279.csv'),
('GaiaSource_467280-467304.csv'),
('GaiaSource_467305-467324.csv'),
('GaiaSource_467325-467340.csv'),
('GaiaSource_467341-467354.csv'),
('GaiaSource_467355-467377.csv'),
('GaiaSource_467378-467400.csv'),
('GaiaSource_467401-467423.csv'),
('GaiaSource_467424-467439.csv'),
('GaiaSource_467440-467463.csv'),
('GaiaSource_467464-467482.csv'),
('GaiaSource_467483-467504.csv'),
('GaiaSource_467505-467527.csv'),
('GaiaSource_467528-467552.csv'),
('GaiaSource_467553-467577.csv'),
('GaiaSource_467578-467605.csv'),
('GaiaSource_467606-467643.csv'),
('GaiaSource_467644-467673.csv'),
('GaiaSource_467674-467715.csv'),
('GaiaSource_467716-467737.csv'),
('GaiaSource_467738-467760.csv'),
('GaiaSource_467761-467785.csv'),
('GaiaSource_467786-467812.csv'),
('GaiaSource_467813-467840.csv'),
('GaiaSource_467841-467878.csv'),
('GaiaSource_467879-467917.csv'),
('GaiaSource_467918-467946.csv'),
('GaiaSource_467947-467972.csv'),
('GaiaSource_467973-467986.csv'),
('GaiaSource_467987-467999.csv'),
('GaiaSource_468000-468013.csv'),
('GaiaSource_468014-468026.csv'),
('GaiaSource_468027-468039.csv'),
('GaiaSource_468040-468052.csv'),
('GaiaSource_468053-468065.csv'),
('GaiaSource_468066-468077.csv'),
('GaiaSource_468078-468089.csv'),
('GaiaSource_468090-468105.csv'),
('GaiaSource_468106-468119.csv'),
('GaiaSource_468120-468135.csv'),
('GaiaSource_468136-468153.csv'),
('GaiaSource_468154-468167.csv'),
('GaiaSource_468168-468178.csv'),
('GaiaSource_468179-468190.csv'),
('GaiaSource_468191-468203.csv'),
('GaiaSource_468204-468218.csv'),
('GaiaSource_468219-468233.csv'),
('GaiaSource_468234-468247.csv'),
('GaiaSource_468248-468263.csv'),
('GaiaSource_468264-468280.csv'),
('GaiaSource_468281-468295.csv'),
('GaiaSource_468296-468315.csv'),
('GaiaSource_468316-468332.csv'),
('GaiaSource_468333-468350.csv'),
('GaiaSource_468351-468363.csv'),
('GaiaSource_468364-468376.csv'),
('GaiaSource_468377-468392.csv'),
('GaiaSource_468393-468406.csv'),
('GaiaSource_468407-468419.csv'),
('GaiaSource_468420-468433.csv'),
('GaiaSource_468434-468446.csv'),
('GaiaSource_468447-468459.csv'),
('GaiaSource_468460-468471.csv'),
('GaiaSource_468472-468489.csv'),
('GaiaSource_468490-468511.csv'),
('GaiaSource_468512-468531.csv'),
('GaiaSource_468532-468556.csv'),
('GaiaSource_468557-468574.csv'),
('GaiaSource_468575-468595.csv'),
('GaiaSource_468596-468614.csv'),
('GaiaSource_468615-468642.csv'),
('GaiaSource_468643-468672.csv'),
('GaiaSource_468673-468695.csv'),
('GaiaSource_468696-468717.csv'),
('GaiaSource_468718-468737.csv'),
('GaiaSource_468738-468749.csv'),
('GaiaSource_468750-468761.csv'),
('GaiaSource_468762-468774.csv'),
('GaiaSource_468775-468788.csv'),
('GaiaSource_468789-468802.csv'),
('GaiaSource_468803-468816.csv'),
('GaiaSource_468817-468832.csv'),
('GaiaSource_468833-468848.csv'),
('GaiaSource_468849-468864.csv'),
('GaiaSource_468865-468882.csv'),
('GaiaSource_468883-468901.csv'),
('GaiaSource_468902-468924.csv'),
('GaiaSource_468925-468943.csv'),
('GaiaSource_468944-468963.csv'),
('GaiaSource_468964-468988.csv'),
('GaiaSource_468989-469053.csv'),
('GaiaSource_469054-469108.csv'),
('GaiaSource_469109-469199.csv'),
('GaiaSource_469200-469267.csv'),
('GaiaSource_469268-469314.csv'),
('GaiaSource_469315-469353.csv'),
('GaiaSource_469354-469410.csv'),
('GaiaSource_469411-469481.csv'),
('GaiaSource_469482-469598.csv'),
('GaiaSource_469599-469777.csv'),
('GaiaSource_469778-469896.csv'),
('GaiaSource_469897-470028.csv'),
('GaiaSource_470029-470065.csv'),
('GaiaSource_470066-470099.csv'),
('GaiaSource_470100-470135.csv'),
('GaiaSource_470136-470197.csv'),
('GaiaSource_470198-470263.csv'),
('GaiaSource_470264-470299.csv'),
('GaiaSource_470300-470339.csv'),
('GaiaSource_470340-470374.csv'),
('GaiaSource_470375-470430.csv'),
('GaiaSource_470431-470500.csv'),
('GaiaSource_470501-470598.csv'),
('GaiaSource_470599-470759.csv'),
('GaiaSource_470760-470873.csv'),
('GaiaSource_470874-471029.csv'),
('GaiaSource_471030-471072.csv'),
('GaiaSource_471073-471091.csv'),
('GaiaSource_471092-471110.csv'),
('GaiaSource_471111-471142.csv'),
('GaiaSource_471143-471165.csv'),
('GaiaSource_471166-471179.csv'),
('GaiaSource_471180-471196.csv'),
('GaiaSource_471197-471212.csv'),
('GaiaSource_471213-471227.csv'),
('GaiaSource_471228-471243.csv'),
('GaiaSource_471244-471261.csv'),
('GaiaSource_471262-471276.csv'),
('GaiaSource_471277-471302.csv'),
('GaiaSource_471303-471334.csv'),
('GaiaSource_471335-471359.csv'),
('GaiaSource_471360-471425.csv'),
('GaiaSource_471426-471461.csv'),
('GaiaSource_471462-471526.csv'),
('GaiaSource_471527-471560.csv'),
('GaiaSource_471561-471575.csv'),
('GaiaSource_471576-471593.csv'),
('GaiaSource_471594-471612.csv'),
('GaiaSource_471613-471633.csv'),
('GaiaSource_471634-471659.csv'),
('GaiaSource_471660-471682.csv'),
('GaiaSource_471683-471703.csv'),
('GaiaSource_471704-471728.csv'),
('GaiaSource_471729-471754.csv'),
('GaiaSource_471755-471783.csv'),
('GaiaSource_471784-471816.csv'),
('GaiaSource_471817-471852.csv'),
('GaiaSource_471853-471901.csv'),
('GaiaSource_471902-471940.csv'),
('GaiaSource_471941-471985.csv'),
('GaiaSource_471986-472029.csv'),
('GaiaSource_472030-472088.csv'),
('GaiaSource_472089-472142.csv'),
('GaiaSource_472143-472187.csv'),
('GaiaSource_472188-472228.csv'),
('GaiaSource_472229-472286.csv'),
('GaiaSource_472287-472328.csv'),
('GaiaSource_472329-472368.csv'),
('GaiaSource_472369-472398.csv'),
('GaiaSource_472399-472420.csv'),
('GaiaSource_472421-472454.csv'),
('GaiaSource_472455-472500.csv'),
('GaiaSource_472501-472555.csv'),
('GaiaSource_472556-472624.csv'),
('GaiaSource_472625-472665.csv'),
('GaiaSource_472666-472713.csv'),
('GaiaSource_472714-472767.csv'),
('GaiaSource_472768-472833.csv'),
('GaiaSource_472834-472886.csv'),
('GaiaSource_472887-472938.csv'),
('GaiaSource_472939-472982.csv'),
('GaiaSource_472983-473030.csv'),
('GaiaSource_473031-473060.csv'),
('GaiaSource_473061-473097.csv'),
('GaiaSource_473098-473135.csv'),
('GaiaSource_473136-473180.csv'),
('GaiaSource_473181-473241.csv'),
('GaiaSource_473242-473318.csv'),
('GaiaSource_473319-473402.csv'),
('GaiaSource_473403-473477.csv'),
('GaiaSource_473478-473570.csv'),
('GaiaSource_473571-473680.csv'),
('GaiaSource_473681-473855.csv'),
('GaiaSource_473856-473992.csv'),
('GaiaSource_473993-474137.csv'),
('GaiaSource_474138-474211.csv'),
('GaiaSource_474212-474294.csv'),
('GaiaSource_474295-474383.csv'),
('GaiaSource_474384-474437.csv'),
('GaiaSource_474438-474494.csv'),
('GaiaSource_474495-474648.csv'),
('GaiaSource_474649-474770.csv'),
('GaiaSource_474771-474914.csv'),
('GaiaSource_474915-475046.csv'),
('GaiaSource_475047-475149.csv'),
('GaiaSource_475150-475287.csv'),
('GaiaSource_475288-475414.csv'),
('GaiaSource_475415-475588.csv'),
('GaiaSource_475589-475701.csv'),
('GaiaSource_475702-475789.csv'),
('GaiaSource_475790-475852.csv'),
('GaiaSource_475853-475943.csv'),
('GaiaSource_475944-476062.csv'),
('GaiaSource_476063-476160.csv'),
('GaiaSource_476161-476367.csv'),
('GaiaSource_476368-476605.csv'),
('GaiaSource_476606-476789.csv'),
('GaiaSource_476790-476927.csv'),
('GaiaSource_476928-477103.csv'),
('GaiaSource_477104-477208.csv'),
('GaiaSource_477209-477258.csv'),
('GaiaSource_477259-477316.csv'),
('GaiaSource_477317-477352.csv'),
('GaiaSource_477353-477394.csv'),
('GaiaSource_477395-477443.csv'),
('GaiaSource_477444-477512.csv'),
('GaiaSource_477513-477586.csv'),
('GaiaSource_477587-477640.csv'),
('GaiaSource_477641-477699.csv'),
('GaiaSource_477700-477728.csv'),
('GaiaSource_477729-477749.csv'),
('GaiaSource_477750-477777.csv'),
('GaiaSource_477778-477806.csv'),
('GaiaSource_477807-477829.csv'),
('GaiaSource_477830-477846.csv'),
('GaiaSource_477847-477862.csv'),
('GaiaSource_477863-477878.csv'),
('GaiaSource_477879-477895.csv'),
('GaiaSource_477896-477915.csv'),
('GaiaSource_477916-477932.csv'),
('GaiaSource_477933-477949.csv'),
('GaiaSource_477950-477986.csv'),
('GaiaSource_477987-478021.csv'),
('GaiaSource_478022-478073.csv'),
('GaiaSource_478074-478102.csv'),
('GaiaSource_478103-478125.csv'),
('GaiaSource_478126-478152.csv'),
('GaiaSource_478153-478189.csv'),
('GaiaSource_478190-478261.csv'),
('GaiaSource_478262-478364.csv'),
('GaiaSource_478365-478449.csv'),
('GaiaSource_478450-478577.csv'),
('GaiaSource_478578-478691.csv'),
('GaiaSource_478692-478765.csv'),
('GaiaSource_478766-478841.csv'),
('GaiaSource_478842-478895.csv'),
('GaiaSource_478896-478951.csv'),
('GaiaSource_478952-479028.csv'),
('GaiaSource_479029-479113.csv'),
('GaiaSource_479114-479173.csv'),
('GaiaSource_479174-479237.csv'),
('GaiaSource_479238-479533.csv'),
('GaiaSource_479534-479834.csv'),
('GaiaSource_479835-480076.csv'),
('GaiaSource_480077-480386.csv'),
('GaiaSource_480387-480809.csv'),
('GaiaSource_480810-481133.csv'),
('GaiaSource_481134-481378.csv'),
('GaiaSource_481379-481511.csv'),
('GaiaSource_481512-481686.csv'),
('GaiaSource_481687-481820.csv'),
('GaiaSource_481821-481916.csv'),
('GaiaSource_481917-481993.csv'),
('GaiaSource_481994-482089.csv'),
('GaiaSource_482090-482202.csv'),
('GaiaSource_482203-482293.csv'),
('GaiaSource_482294-482495.csv'),
('GaiaSource_482496-482734.csv'),
('GaiaSource_482735-482907.csv'),
('GaiaSource_482908-483027.csv'),
('GaiaSource_483028-483188.csv'),
('GaiaSource_483189-483328.csv'),
('GaiaSource_483329-483343.csv'),
('GaiaSource_483344-483358.csv'),
('GaiaSource_483359-483373.csv'),
('GaiaSource_483374-483386.csv'),
('GaiaSource_483387-483399.csv'),
('GaiaSource_483400-483413.csv'),
('GaiaSource_483414-483427.csv'),
('GaiaSource_483428-483439.csv'),
('GaiaSource_483440-483452.csv'),
('GaiaSource_483453-483476.csv'),
('GaiaSource_483477-483508.csv'),
('GaiaSource_483509-483528.csv'),
('GaiaSource_483529-483541.csv'),
('GaiaSource_483542-483556.csv'),
('GaiaSource_483557-483572.csv'),
('GaiaSource_483573-483587.csv'),
('GaiaSource_483588-483604.csv'),
('GaiaSource_483605-483621.csv'),
('GaiaSource_483622-483637.csv'),
('GaiaSource_483638-483659.csv'),
('GaiaSource_483660-483689.csv'),
('GaiaSource_483690-483714.csv'),
('GaiaSource_483715-483731.csv'),
('GaiaSource_483732-483751.csv'),
('GaiaSource_483752-483775.csv'),
('GaiaSource_483776-483798.csv'),
('GaiaSource_483799-483825.csv'),
('GaiaSource_483826-483871.csv'),
('GaiaSource_483872-483910.csv'),
('GaiaSource_483911-483941.csv'),
('GaiaSource_483942-483969.csv'),
('GaiaSource_483970-484035.csv'),
('GaiaSource_484036-484084.csv'),
('GaiaSource_484085-484136.csv'),
('GaiaSource_484137-484190.csv'),
('GaiaSource_484191-484237.csv'),
('GaiaSource_484238-484263.csv'),
('GaiaSource_484264-484316.csv'),
('GaiaSource_484317-484367.csv'),
('GaiaSource_484368-484407.csv'),
('GaiaSource_484408-484449.csv'),
('GaiaSource_484450-484482.csv'),
('GaiaSource_484483-484508.csv'),
('GaiaSource_484509-484532.csv'),
('GaiaSource_484533-484555.csv'),
('GaiaSource_484556-484583.csv'),
('GaiaSource_484584-484605.csv'),
('GaiaSource_484606-484647.csv'),
('GaiaSource_484648-484684.csv'),
('GaiaSource_484685-484728.csv'),
('GaiaSource_484729-484763.csv'),
('GaiaSource_484764-484789.csv'),
('GaiaSource_484790-484820.csv'),
('GaiaSource_484821-484853.csv'),
('GaiaSource_484854-484878.csv'),
('GaiaSource_484879-484894.csv'),
('GaiaSource_484895-484912.csv'),
('GaiaSource_484913-484926.csv'),
('GaiaSource_484927-484946.csv'),
('GaiaSource_484947-484966.csv'),
('GaiaSource_484967-485001.csv'),
('GaiaSource_485002-485031.csv'),
('GaiaSource_485032-485128.csv'),
('GaiaSource_485129-485154.csv'),
('GaiaSource_485155-485187.csv'),
('GaiaSource_485188-485212.csv'),
('GaiaSource_485213-485235.csv'),
('GaiaSource_485236-485276.csv'),
('GaiaSource_485277-485321.csv'),
('GaiaSource_485322-485340.csv'),
('GaiaSource_485341-485363.csv'),
('GaiaSource_485364-485445.csv'),
('GaiaSource_485446-485579.csv'),
('GaiaSource_485580-485695.csv'),
('GaiaSource_485696-485819.csv'),
('GaiaSource_485820-485941.csv'),
('GaiaSource_485942-486016.csv'),
('GaiaSource_486017-486096.csv'),
('GaiaSource_486097-486187.csv'),
('GaiaSource_486188-486260.csv'),
('GaiaSource_486261-486327.csv'),
('GaiaSource_486328-486387.csv'),
('GaiaSource_486388-486466.csv'),
('GaiaSource_486467-486576.csv'),
('GaiaSource_486577-486640.csv'),
('GaiaSource_486641-486782.csv'),
('GaiaSource_486783-486917.csv'),
('GaiaSource_486918-486974.csv'),
('GaiaSource_486975-487015.csv'),
('GaiaSource_487016-487065.csv'),
('GaiaSource_487066-487124.csv'),
('GaiaSource_487125-487173.csv'),
('GaiaSource_487174-487224.csv'),
('GaiaSource_487225-487306.csv'),
('GaiaSource_487307-487347.csv'),
('GaiaSource_487348-487395.csv'),
('GaiaSource_487396-487441.csv'),
('GaiaSource_487442-487498.csv'),
('GaiaSource_487499-487553.csv'),
('GaiaSource_487554-487592.csv'),
('GaiaSource_487593-487628.csv'),
('GaiaSource_487629-487668.csv'),
('GaiaSource_487669-487726.csv'),
('GaiaSource_487727-487794.csv'),
('GaiaSource_487795-487846.csv'),
('GaiaSource_487847-487891.csv'),
('GaiaSource_487892-487939.csv'),
('GaiaSource_487940-487971.csv'),
('GaiaSource_487972-488001.csv'),
('GaiaSource_488002-488039.csv'),
('GaiaSource_488040-488078.csv'),
('GaiaSource_488079-488115.csv'),
('GaiaSource_488116-488156.csv'),
('GaiaSource_488157-488187.csv'),
('GaiaSource_488188-488222.csv'),
('GaiaSource_488223-488254.csv'),
('GaiaSource_488255-488291.csv'),
('GaiaSource_488292-488323.csv'),
('GaiaSource_488324-488351.csv'),
('GaiaSource_488352-488377.csv'),
('GaiaSource_488378-488399.csv'),
('GaiaSource_488400-488425.csv'),
('GaiaSource_488426-488465.csv'),
('GaiaSource_488466-488553.csv'),
('GaiaSource_488554-488627.csv'),
('GaiaSource_488628-488697.csv'),
('GaiaSource_488698-488803.csv'),
('GaiaSource_488804-488892.csv'),
('GaiaSource_488893-488971.csv'),
('GaiaSource_488972-489019.csv'),
('GaiaSource_489020-489073.csv'),
('GaiaSource_489074-489112.csv'),
('GaiaSource_489113-489145.csv'),
('GaiaSource_489146-489186.csv'),
('GaiaSource_489187-489228.csv'),
('GaiaSource_489229-489295.csv'),
('GaiaSource_489296-489356.csv'),
('GaiaSource_489357-489397.csv'),
('GaiaSource_489398-489444.csv'),
('GaiaSource_489445-489508.csv'),
('GaiaSource_489509-489563.csv'),
('GaiaSource_489564-489649.csv'),
('GaiaSource_489650-489743.csv'),
('GaiaSource_489744-489773.csv'),
('GaiaSource_489774-489804.csv'),
('GaiaSource_489805-489836.csv'),
('GaiaSource_489837-489905.csv'),
('GaiaSource_489906-490001.csv'),
('GaiaSource_490002-490067.csv'),
('GaiaSource_490068-490103.csv'),
('GaiaSource_490104-490136.csv'),
('GaiaSource_490137-490166.csv'),
('GaiaSource_490167-490196.csv'),
('GaiaSource_490197-490223.csv'),
('GaiaSource_490224-490251.csv'),
('GaiaSource_490252-490283.csv'),
('GaiaSource_490284-490315.csv'),
('GaiaSource_490316-490349.csv'),
('GaiaSource_490350-490376.csv'),
('GaiaSource_490377-490402.csv'),
('GaiaSource_490403-490436.csv'),
('GaiaSource_490437-490457.csv'),
('GaiaSource_490458-490482.csv'),
('GaiaSource_490483-490502.csv'),
('GaiaSource_490503-490526.csv'),
('GaiaSource_490527-490554.csv'),
('GaiaSource_490555-490578.csv'),
('GaiaSource_490579-490601.csv'),
('GaiaSource_490602-490622.csv'),
('GaiaSource_490623-490667.csv'),
('GaiaSource_490668-490704.csv'),
('GaiaSource_490705-490738.csv'),
('GaiaSource_490739-490773.csv'),
('GaiaSource_490774-490800.csv'),
('GaiaSource_490801-490830.csv'),
('GaiaSource_490831-490861.csv'),
('GaiaSource_490862-490888.csv'),
('GaiaSource_490889-490918.csv'),
('GaiaSource_490919-490952.csv'),
('GaiaSource_490953-490977.csv'),
('GaiaSource_490978-491001.csv'),
('GaiaSource_491002-491054.csv'),
('GaiaSource_491055-491115.csv'),
('GaiaSource_491116-491154.csv'),
('GaiaSource_491155-491176.csv'),
('GaiaSource_491177-491201.csv'),
('GaiaSource_491202-491234.csv'),
('GaiaSource_491235-491268.csv'),
('GaiaSource_491269-491331.csv'),
('GaiaSource_491332-491357.csv'),
('GaiaSource_491358-491403.csv'),
('GaiaSource_491404-491479.csv'),
('GaiaSource_491480-491562.csv'),
('GaiaSource_491563-491829.csv'),
('GaiaSource_491830-492139.csv'),
('GaiaSource_492140-492522.csv'),
('GaiaSource_492523-492774.csv'),
('GaiaSource_492775-493031.csv'),
('GaiaSource_493032-493383.csv'),
('GaiaSource_493384-493804.csv'),
('GaiaSource_493805-494390.csv'),
('GaiaSource_494391-494919.csv'),
('GaiaSource_494920-495475.csv'),
('GaiaSource_495476-495797.csv'),
('GaiaSource_495798-496031.csv'),
('GaiaSource_496032-496317.csv'),
('GaiaSource_496318-496638.csv'),
('GaiaSource_496639-496791.csv'),
('GaiaSource_496792-496943.csv'),
('GaiaSource_496944-497073.csv'),
('GaiaSource_497074-497268.csv'),
('GaiaSource_497269-497497.csv'),
('GaiaSource_497498-497738.csv'),
('GaiaSource_497739-498099.csv'),
('GaiaSource_498100-498534.csv'),
('GaiaSource_498535-498893.csv'),
('GaiaSource_498894-499174.csv'),
('GaiaSource_499175-499564.csv'),
('GaiaSource_499565-500276.csv'),
('GaiaSource_500277-501155.csv'),
('GaiaSource_501156-502152.csv'),
('GaiaSource_502153-503324.csv'),
('GaiaSource_503325-504180.csv'),
('GaiaSource_504181-504873.csv'),
('GaiaSource_504874-505420.csv'),
('GaiaSource_505421-506182.csv'),
('GaiaSource_506183-507173.csv'),
('GaiaSource_507174-507924.csv'),
('GaiaSource_507925-508013.csv'),
('GaiaSource_508014-508122.csv'),
('GaiaSource_508123-508208.csv'),
('GaiaSource_508209-508277.csv'),
('GaiaSource_508278-508370.csv'),
('GaiaSource_508371-508500.csv'),
('GaiaSource_508501-508680.csv'),
('GaiaSource_508681-508817.csv'),
('GaiaSource_508818-508949.csv'),
('GaiaSource_508950-509012.csv'),
('GaiaSource_509013-509075.csv'),
('GaiaSource_509076-509156.csv'),
('GaiaSource_509157-509213.csv'),
('GaiaSource_509214-509262.csv'),
('GaiaSource_509263-509306.csv'),
('GaiaSource_509307-509370.csv'),
('GaiaSource_509371-509432.csv'),
('GaiaSource_509433-509540.csv'),
('GaiaSource_509541-509675.csv'),
('GaiaSource_509676-509774.csv'),
('GaiaSource_509775-509878.csv'),
('GaiaSource_509879-510031.csv'),
('GaiaSource_510032-510271.csv'),
('GaiaSource_510272-510516.csv'),
('GaiaSource_510517-510851.csv'),
('GaiaSource_510852-511083.csv'),
('GaiaSource_511084-511277.csv'),
('GaiaSource_511278-511440.csv'),
('GaiaSource_511441-511697.csv'),
('GaiaSource_511698-511953.csv'),
('GaiaSource_511954-512028.csv'),
('GaiaSource_512029-512067.csv'),
('GaiaSource_512068-512101.csv'),
('GaiaSource_512102-512146.csv'),
('GaiaSource_512147-512207.csv'),
('GaiaSource_512208-512261.csv'),
('GaiaSource_512262-512297.csv'),
('GaiaSource_512298-512335.csv'),
('GaiaSource_512336-512362.csv'),
('GaiaSource_512363-512402.csv'),
('GaiaSource_512403-512455.csv'),
('GaiaSource_512456-512507.csv'),
('GaiaSource_512508-512592.csv'),
('GaiaSource_512593-512695.csv'),
('GaiaSource_512696-512788.csv'),
('GaiaSource_512789-512855.csv'),
('GaiaSource_512856-512928.csv'),
('GaiaSource_512929-513016.csv'),
('GaiaSource_513017-513045.csv'),
('GaiaSource_513046-513072.csv'),
('GaiaSource_513073-513101.csv'),
('GaiaSource_513102-513140.csv'),
('GaiaSource_513141-513175.csv'),
('GaiaSource_513176-513215.csv'),
('GaiaSource_513216-513249.csv'),
('GaiaSource_513250-513288.csv'),
('GaiaSource_513289-513348.csv'),
('GaiaSource_513349-513383.csv'),
('GaiaSource_513384-513422.csv'),
('GaiaSource_513423-513465.csv'),
('GaiaSource_513466-513508.csv'),
('GaiaSource_513509-513555.csv'),
('GaiaSource_513556-513608.csv'),
('GaiaSource_513609-513660.csv'),
('GaiaSource_513661-513732.csv'),
('GaiaSource_513733-513797.csv'),
('GaiaSource_513798-513845.csv'),
('GaiaSource_513846-513888.csv'),
('GaiaSource_513889-513939.csv'),
('GaiaSource_513940-514006.csv'),
('GaiaSource_514007-514100.csv'),
('GaiaSource_514101-514251.csv'),
('GaiaSource_514252-514384.csv'),
('GaiaSource_514385-514511.csv'),
('GaiaSource_514512-514696.csv'),
('GaiaSource_514697-514899.csv'),
('GaiaSource_514900-515083.csv'),
('GaiaSource_515084-515176.csv'),
('GaiaSource_515177-515288.csv'),
('GaiaSource_515289-515386.csv'),
('GaiaSource_515387-515471.csv'),
('GaiaSource_515472-515583.csv'),
('GaiaSource_515584-515740.csv'),
('GaiaSource_515741-515911.csv'),
('GaiaSource_515912-516082.csv'),
('GaiaSource_516083-516513.csv'),
('GaiaSource_516514-517081.csv'),
('GaiaSource_517082-517446.csv'),
('GaiaSource_517447-517863.csv'),
('GaiaSource_517864-518434.csv'),
('GaiaSource_518435-519247.csv'),
('GaiaSource_519248-519942.csv'),
('GaiaSource_519943-520394.csv'),
('GaiaSource_520395-520696.csv'),
('GaiaSource_520697-521112.csv'),
('GaiaSource_521113-521421.csv'),
('GaiaSource_521422-521692.csv'),
('GaiaSource_521693-522063.csv'),
('GaiaSource_522064-522550.csv'),
('GaiaSource_522551-523221.csv'),
('GaiaSource_523222-523751.csv'),
('GaiaSource_523752-524427.csv'),
('GaiaSource_524428-525308.csv'),
('GaiaSource_525309-526199.csv'),
('GaiaSource_526200-527232.csv'),
('GaiaSource_527233-528422.csv'),
('GaiaSource_528423-528606.csv'),
('GaiaSource_528607-528723.csv'),
('GaiaSource_528724-528763.csv'),
('GaiaSource_528764-528815.csv'),
('GaiaSource_528816-528849.csv'),
('GaiaSource_528850-528870.csv'),
('GaiaSource_528871-528887.csv'),
('GaiaSource_528888-528971.csv'),
('GaiaSource_528972-529167.csv'),
('GaiaSource_529168-529216.csv'),
('GaiaSource_529217-529234.csv'),
('GaiaSource_529235-529246.csv'),
('GaiaSource_529247-529270.csv'),
('GaiaSource_529271-529377.csv'),
('GaiaSource_529378-529437.csv'),
('GaiaSource_529438-529452.csv'),
('GaiaSource_529453-529464.csv'),
('GaiaSource_529465-529485.csv'),
('GaiaSource_529486-529515.csv'),
('GaiaSource_529516-529538.csv'),
('GaiaSource_529539-529547.csv'),
('GaiaSource_529548-529556.csv'),
('GaiaSource_529557-529566.csv'),
('GaiaSource_529567-529575.csv'),
('GaiaSource_529576-529584.csv'),
('GaiaSource_529585-529596.csv'),
('GaiaSource_529597-529615.csv'),
('GaiaSource_529616-529648.csv'),
('GaiaSource_529649-529696.csv'),
('GaiaSource_529697-529734.csv'),
('GaiaSource_529735-529791.csv'),
('GaiaSource_529792-529822.csv'),
('GaiaSource_529823-529870.csv'),
('GaiaSource_529871-529921.csv'),
('GaiaSource_529922-529933.csv'),
('GaiaSource_529934-529952.csv'),
('GaiaSource_529953-529979.csv'),
('GaiaSource_529980-530011.csv'),
('GaiaSource_530012-530057.csv'),
('GaiaSource_530058-530195.csv'),
('GaiaSource_530196-530460.csv'),
('GaiaSource_530461-531931.csv'),
('GaiaSource_531932-532692.csv'),
('GaiaSource_532693-532720.csv'),
('GaiaSource_532721-532732.csv'),
('GaiaSource_532733-532878.csv'),
('GaiaSource_532879-533020.csv'),
('GaiaSource_533021-533074.csv'),
('GaiaSource_533075-533135.csv'),
('GaiaSource_533136-533286.csv'),
('GaiaSource_533287-534680.csv'),
('GaiaSource_534681-536599.csv'),
('GaiaSource_536600-538835.csv'),
('GaiaSource_538836-540697.csv'),
('GaiaSource_540698-540804.csv'),
('GaiaSource_540805-541066.csv'),
('GaiaSource_541067-542174.csv'),
('GaiaSource_542175-543911.csv'),
('GaiaSource_543912-545536.csv'),
('GaiaSource_545537-546921.csv'),
('GaiaSource_546922-548657.csv'),
('GaiaSource_548658-551055.csv'),
('GaiaSource_551056-553777.csv'),
('GaiaSource_553778-556045.csv'),
('GaiaSource_556046-558249.csv'),
('GaiaSource_558250-560858.csv'),
('GaiaSource_560859-563991.csv'),
('GaiaSource_563992-567098.csv'),
('GaiaSource_567099-570398.csv'),
('GaiaSource_570399-574043.csv'),
('GaiaSource_574044-577144.csv'),
('GaiaSource_577145-580138.csv'),
('GaiaSource_580139-583797.csv'),
('GaiaSource_583798-587647.csv'),
('GaiaSource_587648-590065.csv'),
('GaiaSource_590066-590595.csv'),
('GaiaSource_590596-591022.csv'),
('GaiaSource_591023-591341.csv'),
('GaiaSource_591342-591700.csv'),
('GaiaSource_591701-592140.csv'),
('GaiaSource_592141-592752.csv'),
('GaiaSource_592753-593174.csv'),
('GaiaSource_593175-593448.csv'),
('GaiaSource_593449-593784.csv'),
('GaiaSource_593785-594023.csv'),
('GaiaSource_594024-594204.csv'),
('GaiaSource_594205-594331.csv'),
('GaiaSource_594332-594444.csv'),
('GaiaSource_594445-594613.csv'),
('GaiaSource_594614-594744.csv'),
('GaiaSource_594745-594837.csv'),
('GaiaSource_594838-594930.csv'),
('GaiaSource_594931-595013.csv'),
('GaiaSource_595014-595074.csv'),
('GaiaSource_595075-595145.csv'),
('GaiaSource_595146-595197.csv'),
('GaiaSource_595198-595238.csv'),
('GaiaSource_595239-595274.csv'),
('GaiaSource_595275-595304.csv'),
('GaiaSource_595305-595341.csv'),
('GaiaSource_595342-595379.csv'),
('GaiaSource_595380-595415.csv'),
('GaiaSource_595416-595466.csv'),
('GaiaSource_595467-595527.csv'),
('GaiaSource_595528-595575.csv'),
('GaiaSource_595576-595634.csv'),
('GaiaSource_595635-595679.csv'),
('GaiaSource_595680-595720.csv'),
('GaiaSource_595721-595760.csv'),
('GaiaSource_595761-595797.csv'),
('GaiaSource_595798-595836.csv'),
('GaiaSource_595837-595868.csv'),
('GaiaSource_595869-595898.csv'),
('GaiaSource_595899-595924.csv'),
('GaiaSource_595925-595944.csv'),
('GaiaSource_595945-595964.csv'),
('GaiaSource_595965-596108.csv'),
('GaiaSource_596109-596253.csv'),
('GaiaSource_596254-596342.csv'),
('GaiaSource_596343-596436.csv'),
('GaiaSource_596437-596548.csv'),
('GaiaSource_596549-596713.csv'),
('GaiaSource_596714-596816.csv'),
('GaiaSource_596817-596894.csv'),
('GaiaSource_596895-596977.csv'),
('GaiaSource_596978-597037.csv'),
('GaiaSource_597038-597080.csv'),
('GaiaSource_597081-597115.csv'),
('GaiaSource_597116-597162.csv'),
('GaiaSource_597163-597201.csv'),
('GaiaSource_597202-597233.csv'),
('GaiaSource_597234-597263.csv'),
('GaiaSource_597264-597290.csv'),
('GaiaSource_597291-597317.csv'),
('GaiaSource_597318-597343.csv'),
('GaiaSource_597344-597370.csv'),
('GaiaSource_597371-597399.csv'),
('GaiaSource_597400-597434.csv'),
('GaiaSource_597435-597472.csv'),
('GaiaSource_597473-597523.csv'),
('GaiaSource_597524-597568.csv'),
('GaiaSource_597569-597601.csv'),
('GaiaSource_597602-597646.csv'),
('GaiaSource_597647-597696.csv'),
('GaiaSource_597697-597745.csv'),
('GaiaSource_597746-597798.csv'),
('GaiaSource_597799-597889.csv'),
('GaiaSource_597890-597993.csv'),
('GaiaSource_597994-598400.csv'),
('GaiaSource_598401-598714.csv'),
('GaiaSource_598715-599229.csv'),
('GaiaSource_599230-599534.csv'),
('GaiaSource_599535-599922.csv'),
('GaiaSource_599923-600126.csv'),
('GaiaSource_600127-600319.csv'),
('GaiaSource_600320-600622.csv'),
('GaiaSource_600623-600778.csv'),
('GaiaSource_600779-601333.csv'),
('GaiaSource_601334-601680.csv'),
('GaiaSource_601681-602074.csv'),
('GaiaSource_602075-602262.csv'),
('GaiaSource_602263-602404.csv'),
('GaiaSource_602405-602481.csv'),
('GaiaSource_602482-602568.csv'),
('GaiaSource_602569-602659.csv'),
('GaiaSource_602660-602833.csv'),
('GaiaSource_602834-602946.csv'),
('GaiaSource_602947-603019.csv'),
('GaiaSource_603020-603104.csv'),
('GaiaSource_603105-603165.csv'),
('GaiaSource_603166-603218.csv'),
('GaiaSource_603219-603268.csv'),
('GaiaSource_603269-603325.csv'),
('GaiaSource_603326-603387.csv'),
('GaiaSource_603388-603448.csv'),
('GaiaSource_603449-603503.csv'),
('GaiaSource_603504-603564.csv'),
('GaiaSource_603565-603632.csv'),
('GaiaSource_603633-603692.csv'),
('GaiaSource_603693-603737.csv'),
('GaiaSource_603738-603782.csv'),
('GaiaSource_603783-603832.csv'),
('GaiaSource_603833-603880.csv'),
('GaiaSource_603881-603940.csv'),
('GaiaSource_603941-604012.csv'),
('GaiaSource_604013-604086.csv'),
('GaiaSource_604087-604234.csv'),
('GaiaSource_604235-604406.csv'),
('GaiaSource_604407-604501.csv'),
('GaiaSource_604502-604591.csv'),
('GaiaSource_604592-604699.csv'),
('GaiaSource_604700-604894.csv'),
('GaiaSource_604895-605022.csv'),
('GaiaSource_605023-605146.csv'),
('GaiaSource_605147-605227.csv'),
('GaiaSource_605228-605340.csv'),
('GaiaSource_605341-605457.csv'),
('GaiaSource_605458-605701.csv'),
('GaiaSource_605702-605806.csv'),
('GaiaSource_605807-605881.csv'),
('GaiaSource_605882-605953.csv'),
('GaiaSource_605954-606136.csv'),
('GaiaSource_606137-606228.csv'),
('GaiaSource_606229-606266.csv'),
('GaiaSource_606267-606295.csv'),
('GaiaSource_606296-606327.csv'),
('GaiaSource_606328-606384.csv'),
('GaiaSource_606385-606443.csv'),
('GaiaSource_606444-606469.csv'),
('GaiaSource_606470-606489.csv'),
('GaiaSource_606490-606511.csv'),
('GaiaSource_606512-606537.csv'),
('GaiaSource_606538-606561.csv'),
('GaiaSource_606562-606587.csv'),
('GaiaSource_606588-606610.csv'),
('GaiaSource_606611-606630.csv'),
('GaiaSource_606631-606651.csv'),
('GaiaSource_606652-606675.csv'),
('GaiaSource_606676-606705.csv'),
('GaiaSource_606706-606751.csv'),
('GaiaSource_606752-606784.csv'),
('GaiaSource_606785-606812.csv'),
('GaiaSource_606813-606841.csv'),
('GaiaSource_606842-606864.csv'),
('GaiaSource_606865-606889.csv'),
('GaiaSource_606890-606918.csv'),
('GaiaSource_606919-606946.csv'),
('GaiaSource_606947-606979.csv'),
('GaiaSource_606980-607003.csv'),
('GaiaSource_607004-607030.csv'),
('GaiaSource_607031-607061.csv'),
('GaiaSource_607062-607099.csv'),
('GaiaSource_607100-607132.csv'),
('GaiaSource_607133-607170.csv'),
('GaiaSource_607171-607214.csv'),
('GaiaSource_607215-607251.csv'),
('GaiaSource_607252-607288.csv'),
('GaiaSource_607289-607328.csv'),
('GaiaSource_607329-607371.csv'),
('GaiaSource_607372-607409.csv'),
('GaiaSource_607410-607458.csv'),
('GaiaSource_607459-607516.csv'),
('GaiaSource_607517-607584.csv'),
('GaiaSource_607585-607660.csv'),
('GaiaSource_607661-607748.csv'),
('GaiaSource_607749-607802.csv'),
('GaiaSource_607803-607871.csv'),
('GaiaSource_607872-607934.csv'),
('GaiaSource_607935-608023.csv'),
('GaiaSource_608024-608136.csv'),
('GaiaSource_608137-608263.csv'),
('GaiaSource_608264-608321.csv'),
('GaiaSource_608322-608356.csv'),
('GaiaSource_608357-608404.csv'),
('GaiaSource_608405-608470.csv'),
('GaiaSource_608471-608519.csv'),
('GaiaSource_608520-608563.csv'),
('GaiaSource_608564-608616.csv'),
('GaiaSource_608617-608672.csv'),
('GaiaSource_608673-608730.csv'),
('GaiaSource_608731-608813.csv'),
('GaiaSource_608814-608864.csv'),
('GaiaSource_608865-608918.csv'),
('GaiaSource_608919-608969.csv'),
('GaiaSource_608970-609024.csv'),
('GaiaSource_609025-609084.csv'),
('GaiaSource_609085-609162.csv'),
('GaiaSource_609163-609233.csv'),
('GaiaSource_609234-609322.csv'),
('GaiaSource_609323-609433.csv'),
('GaiaSource_609434-609568.csv'),
('GaiaSource_609569-609737.csv'),
('GaiaSource_609738-609889.csv'),
('GaiaSource_609890-610033.csv'),
('GaiaSource_610034-610240.csv'),
('GaiaSource_610241-610378.csv'),
('GaiaSource_610379-610507.csv'),
('GaiaSource_610508-610679.csv'),
('GaiaSource_610680-610874.csv'),
('GaiaSource_610875-611077.csv'),
('GaiaSource_611078-611361.csv'),
('GaiaSource_611362-611697.csv'),
('GaiaSource_611698-612120.csv'),
('GaiaSource_612121-612492.csv'),
('GaiaSource_612493-612843.csv'),
('GaiaSource_612844-613193.csv'),
('GaiaSource_613194-613721.csv'),
('GaiaSource_613722-614400.csv'),
('GaiaSource_614401-614453.csv'),
('GaiaSource_614454-614516.csv'),
('GaiaSource_614517-614573.csv'),
('GaiaSource_614574-614635.csv'),
('GaiaSource_614636-614709.csv'),
('GaiaSource_614710-614807.csv'),
('GaiaSource_614808-614913.csv'),
('GaiaSource_614914-614985.csv'),
('GaiaSource_614986-615069.csv'),
('GaiaSource_615070-615174.csv'),
('GaiaSource_615175-615286.csv'),
('GaiaSource_615287-615411.csv'),
('GaiaSource_615412-615562.csv'),
('GaiaSource_615563-615758.csv'),
('GaiaSource_615759-616003.csv'),
('GaiaSource_616004-616247.csv'),
('GaiaSource_616248-616509.csv'),
('GaiaSource_616510-616636.csv'),
('GaiaSource_616637-616791.csv'),
('GaiaSource_616792-616964.csv'),
('GaiaSource_616965-617091.csv'),
('GaiaSource_617092-617222.csv'),
('GaiaSource_617223-617389.csv'),
('GaiaSource_617390-617611.csv'),
('GaiaSource_617612-617932.csv'),
('GaiaSource_617933-618227.csv'),
('GaiaSource_618228-618632.csv'),
('GaiaSource_618633-619122.csv'),
('GaiaSource_619123-619779.csv'),
('GaiaSource_619780-620634.csv'),
('GaiaSource_620635-621285.csv'),
('GaiaSource_621286-622263.csv'),
('GaiaSource_622264-622838.csv'),
('GaiaSource_622839-623577.csv'),
('GaiaSource_623578-624011.csv'),
('GaiaSource_624012-624429.csv'),
('GaiaSource_624430-624950.csv'),
('GaiaSource_624951-625711.csv'),
('GaiaSource_625712-626103.csv'),
('GaiaSource_626104-626499.csv'),
('GaiaSource_626500-626764.csv'),
('GaiaSource_626765-626947.csv'),
('GaiaSource_626948-627064.csv'),
('GaiaSource_627065-627169.csv'),
('GaiaSource_627170-627315.csv'),
('GaiaSource_627316-627468.csv'),
('GaiaSource_627469-627572.csv'),
('GaiaSource_627573-627676.csv'),
('GaiaSource_627677-627755.csv'),
('GaiaSource_627756-627857.csv'),
('GaiaSource_627858-628005.csv'),
('GaiaSource_628006-628225.csv'),
('GaiaSource_628226-628361.csv'),
('GaiaSource_628362-628542.csv'),
('GaiaSource_628543-628673.csv'),
('GaiaSource_628674-628805.csv'),
('GaiaSource_628806-628957.csv'),
('GaiaSource_628958-629063.csv'),
('GaiaSource_629064-629177.csv'),
('GaiaSource_629178-629318.csv'),
('GaiaSource_629319-629486.csv'),
('GaiaSource_629487-629604.csv'),
('GaiaSource_629605-629725.csv'),
('GaiaSource_629726-629868.csv'),
('GaiaSource_629869-629978.csv'),
('GaiaSource_629979-630074.csv'),
('GaiaSource_630075-630172.csv'),
('GaiaSource_630173-630270.csv'),
('GaiaSource_630271-630379.csv'),
('GaiaSource_630380-630505.csv'),
('GaiaSource_630506-630589.csv'),
('GaiaSource_630590-630677.csv'),
('GaiaSource_630678-630770.csv'),
('GaiaSource_630771-631532.csv'),
('GaiaSource_631533-632079.csv'),
('GaiaSource_632080-632397.csv'),
('GaiaSource_632398-632773.csv'),
('GaiaSource_632774-633519.csv'),
('GaiaSource_633520-634142.csv'),
('GaiaSource_634143-634585.csv'),
('GaiaSource_634586-634942.csv'),
('GaiaSource_634943-635126.csv'),
('GaiaSource_635127-635254.csv'),
('GaiaSource_635255-635388.csv'),
('GaiaSource_635389-635594.csv'),
('GaiaSource_635595-635734.csv'),
('GaiaSource_635735-635854.csv'),
('GaiaSource_635855-635975.csv'),
('GaiaSource_635976-636097.csv'),
('GaiaSource_636098-636197.csv'),
('GaiaSource_636198-636289.csv'),
('GaiaSource_636290-636389.csv'),
('GaiaSource_636390-636486.csv'),
('GaiaSource_636487-636583.csv'),
('GaiaSource_636584-636680.csv'),
('GaiaSource_636681-636777.csv'),
('GaiaSource_636778-636878.csv'),
('GaiaSource_636879-637024.csv'),
('GaiaSource_637025-637220.csv'),
('GaiaSource_637221-637342.csv'),
('GaiaSource_637343-637506.csv'),
('GaiaSource_637507-637735.csv'),
('GaiaSource_637736-637891.csv'),
('GaiaSource_637892-638007.csv'),
('GaiaSource_638008-638113.csv'),
('GaiaSource_638114-638222.csv'),
('GaiaSource_638223-638320.csv'),
('GaiaSource_638321-638428.csv'),
('GaiaSource_638429-638540.csv'),
('GaiaSource_638541-638665.csv'),
('GaiaSource_638666-638793.csv'),
('GaiaSource_638794-638914.csv'),
('GaiaSource_638915-639040.csv'),
('GaiaSource_639041-639169.csv'),
('GaiaSource_639170-639338.csv'),
('GaiaSource_639339-639525.csv'),
('GaiaSource_639526-639660.csv'),
('GaiaSource_639661-639827.csv'),
('GaiaSource_639828-640055.csv'),
('GaiaSource_640056-640426.csv'),
('GaiaSource_640427-640791.csv'),
('GaiaSource_640792-641083.csv'),
('GaiaSource_641084-641210.csv'),
('GaiaSource_641211-641376.csv'),
('GaiaSource_641377-641556.csv'),
('GaiaSource_641557-641677.csv'),
('GaiaSource_641678-641805.csv'),
('GaiaSource_641806-641987.csv'),
('GaiaSource_641988-642278.csv'),
('GaiaSource_642279-642709.csv'),
('GaiaSource_642710-643213.csv'),
('GaiaSource_643214-644005.csv'),
('GaiaSource_644006-645213.csv'),
('GaiaSource_645214-646044.csv'),
('GaiaSource_646045-647186.csv'),
('GaiaSource_647187-647310.csv'),
('GaiaSource_647311-647432.csv'),
('GaiaSource_647433-647615.csv'),
('GaiaSource_647616-647753.csv'),
('GaiaSource_647754-647868.csv'),
('GaiaSource_647869-648021.csv'),
('GaiaSource_648022-648217.csv'),
('GaiaSource_648218-648584.csv'),
('GaiaSource_648585-648919.csv'),
('GaiaSource_648920-649247.csv'),
('GaiaSource_649248-649372.csv'),
('GaiaSource_649373-649501.csv'),
('GaiaSource_649502-649674.csv'),
('GaiaSource_649675-649818.csv'),
('GaiaSource_649819-649955.csv'),
('GaiaSource_649956-650112.csv'),
('GaiaSource_650113-650281.csv'),
('GaiaSource_650282-650577.csv'),
('GaiaSource_650578-650892.csv'),
('GaiaSource_650893-651194.csv'),
('GaiaSource_651195-651902.csv'),
('GaiaSource_651903-652954.csv'),
('GaiaSource_652955-653825.csv'),
('GaiaSource_653826-654537.csv'),
('GaiaSource_654538-655527.csv'),
('GaiaSource_655528-655957.csv'),
('GaiaSource_655958-656309.csv'),
('GaiaSource_656310-656666.csv'),
('GaiaSource_656667-656981.csv'),
('GaiaSource_656982-657200.csv'),
('GaiaSource_657201-657385.csv'),
('GaiaSource_657386-657672.csv'),
('GaiaSource_657673-657875.csv'),
('GaiaSource_657876-658106.csv'),
('GaiaSource_658107-658282.csv'),
('GaiaSource_658283-658406.csv'),
('GaiaSource_658407-658556.csv'),
('GaiaSource_658557-658686.csv'),
('GaiaSource_658687-658813.csv'),
('GaiaSource_658814-658913.csv'),
('GaiaSource_658914-659011.csv'),
('GaiaSource_659012-659103.csv'),
('GaiaSource_659104-659182.csv'),
('GaiaSource_659183-659256.csv'),
('GaiaSource_659257-659320.csv'),
('GaiaSource_659321-659380.csv'),
('GaiaSource_659381-659428.csv'),
('GaiaSource_659429-659576.csv'),
('GaiaSource_659577-659831.csv'),
('GaiaSource_659832-660031.csv'),
('GaiaSource_660032-660183.csv'),
('GaiaSource_660184-660327.csv'),
('GaiaSource_660328-660443.csv'),
('GaiaSource_660444-660617.csv'),
('GaiaSource_660618-660792.csv'),
('GaiaSource_660793-660949.csv'),
('GaiaSource_660950-661077.csv'),
('GaiaSource_661078-661176.csv'),
('GaiaSource_661177-661263.csv'),
('GaiaSource_661264-661367.csv'),
('GaiaSource_661368-661443.csv'),
('GaiaSource_661444-661522.csv'),
('GaiaSource_661523-661619.csv'),
('GaiaSource_661620-661694.csv'),
('GaiaSource_661695-661758.csv'),
('GaiaSource_661759-661836.csv'),
('GaiaSource_661837-661903.csv'),
('GaiaSource_661904-661956.csv'),
('GaiaSource_661957-662006.csv'),
('GaiaSource_662007-662059.csv'),
('GaiaSource_662060-662107.csv'),
('GaiaSource_662108-662148.csv'),
('GaiaSource_662149-662187.csv'),
('GaiaSource_662188-662221.csv'),
('GaiaSource_662222-662253.csv'),
('GaiaSource_662254-662287.csv'),
('GaiaSource_662288-662326.csv'),
('GaiaSource_662327-662364.csv'),
('GaiaSource_662365-662396.csv'),
('GaiaSource_662397-662426.csv'),
('GaiaSource_662427-662453.csv'),
('GaiaSource_662454-662480.csv'),
('GaiaSource_662481-662505.csv'),
('GaiaSource_662506-662535.csv'),
('GaiaSource_662536-662597.csv'),
('GaiaSource_662598-662653.csv'),
('GaiaSource_662654-662699.csv'),
('GaiaSource_662700-662740.csv'),
('GaiaSource_662741-662776.csv'),
('GaiaSource_662777-662825.csv'),
('GaiaSource_662826-662874.csv'),
('GaiaSource_662875-662916.csv'),
('GaiaSource_662917-662951.csv'),
('GaiaSource_662952-662980.csv'),
('GaiaSource_662981-663011.csv'),
('GaiaSource_663012-663035.csv'),
('GaiaSource_663036-663068.csv'),
('GaiaSource_663069-663097.csv'),
('GaiaSource_663098-663125.csv'),
('GaiaSource_663126-663150.csv'),
('GaiaSource_663151-663171.csv'),
('GaiaSource_663172-663195.csv'),
('GaiaSource_663196-663215.csv'),
('GaiaSource_663216-663234.csv'),
('GaiaSource_663235-663252.csv'),
('GaiaSource_663253-663268.csv'),
('GaiaSource_663269-663283.csv'),
('GaiaSource_663284-663297.csv'),
('GaiaSource_663298-663321.csv'),
('GaiaSource_663322-663340.csv'),
('GaiaSource_663341-663357.csv'),
('GaiaSource_663358-663376.csv'),
('GaiaSource_663377-663395.csv'),
('GaiaSource_663396-663412.csv'),
('GaiaSource_663413-663427.csv'),
('GaiaSource_663428-663442.csv'),
('GaiaSource_663443-663456.csv'),
('GaiaSource_663457-663469.csv'),
('GaiaSource_663470-663481.csv'),
('GaiaSource_663482-663494.csv'),
('GaiaSource_663495-663507.csv'),
('GaiaSource_663508-663520.csv'),
('GaiaSource_663521-663534.csv'),
('GaiaSource_663535-663550.csv'),
('GaiaSource_663551-663715.csv'),
('GaiaSource_663716-663836.csv'),
('GaiaSource_663837-663930.csv'),
('GaiaSource_663931-664012.csv'),
('GaiaSource_664013-664087.csv'),
('GaiaSource_664088-664184.csv'),
('GaiaSource_664185-664279.csv'),
('GaiaSource_664280-664345.csv'),
('GaiaSource_664346-664397.csv'),
('GaiaSource_664398-664442.csv'),
('GaiaSource_664443-664489.csv'),
('GaiaSource_664490-664526.csv'),
('GaiaSource_664527-664559.csv'),
('GaiaSource_664560-664604.csv'),
('GaiaSource_664605-664665.csv'),
('GaiaSource_664666-664718.csv'),
('GaiaSource_664719-664761.csv'),
('GaiaSource_664762-664801.csv'),
('GaiaSource_664802-664837.csv'),
('GaiaSource_664838-664881.csv'),
('GaiaSource_664882-664918.csv'),
('GaiaSource_664919-664949.csv'),
('GaiaSource_664950-664984.csv'),
('GaiaSource_664985-665011.csv'),
('GaiaSource_665012-665034.csv'),
('GaiaSource_665035-665056.csv'),
('GaiaSource_665057-665076.csv'),
('GaiaSource_665077-665101.csv'),
('GaiaSource_665102-665132.csv'),
('GaiaSource_665133-665158.csv'),
('GaiaSource_665159-665184.csv'),
('GaiaSource_665185-665205.csv'),
('GaiaSource_665206-665227.csv'),
('GaiaSource_665228-665248.csv'),
('GaiaSource_665249-665269.csv'),
('GaiaSource_665270-665286.csv'),
('GaiaSource_665287-665303.csv'),
('GaiaSource_665304-665319.csv'),
('GaiaSource_665320-665336.csv'),
('GaiaSource_665337-665357.csv'),
('GaiaSource_665358-665376.csv'),
('GaiaSource_665377-665395.csv'),
('GaiaSource_665396-665413.csv'),
('GaiaSource_665414-665432.csv'),
('GaiaSource_665433-665450.csv'),
('GaiaSource_665451-665470.csv'),
('GaiaSource_665471-665489.csv'),
('GaiaSource_665490-665515.csv'),
('GaiaSource_665516-665543.csv'),
('GaiaSource_665544-665576.csv'),
('GaiaSource_665577-665652.csv'),
('GaiaSource_665653-665702.csv'),
('GaiaSource_665703-665748.csv'),
('GaiaSource_665749-665793.csv'),
('GaiaSource_665794-665826.csv'),
('GaiaSource_665827-665851.csv'),
('GaiaSource_665852-665882.csv'),
('GaiaSource_665883-665910.csv'),
('GaiaSource_665911-665936.csv'),
('GaiaSource_665937-665957.csv'),
('GaiaSource_665958-665975.csv'),
('GaiaSource_665976-665995.csv'),
('GaiaSource_665996-666017.csv'),
('GaiaSource_666018-666036.csv'),
('GaiaSource_666037-666052.csv'),
('GaiaSource_666053-666066.csv'),
('GaiaSource_666067-666079.csv'),
('GaiaSource_666080-666093.csv'),
('GaiaSource_666094-666106.csv'),
('GaiaSource_666107-666137.csv'),
('GaiaSource_666138-666169.csv'),
('GaiaSource_666170-666193.csv'),
('GaiaSource_666194-666213.csv'),
('GaiaSource_666214-666233.csv'),
('GaiaSource_666234-666260.csv'),
('GaiaSource_666261-666283.csv'),
('GaiaSource_666284-666301.csv'),
('GaiaSource_666302-666321.csv'),
('GaiaSource_666322-666340.csv'),
('GaiaSource_666341-666356.csv'),
('GaiaSource_666357-666377.csv'),
('GaiaSource_666378-666393.csv'),
('GaiaSource_666394-666410.csv'),
('GaiaSource_666411-666431.csv'),
('GaiaSource_666432-666448.csv'),
('GaiaSource_666449-666470.csv'),
('GaiaSource_666471-666503.csv'),
('GaiaSource_666504-666532.csv'),
('GaiaSource_666533-666576.csv'),
('GaiaSource_666577-666625.csv'),
('GaiaSource_666626-666643.csv'),
('GaiaSource_666644-666659.csv'),
('GaiaSource_666660-666672.csv'),
('GaiaSource_666673-666686.csv'),
('GaiaSource_666687-666701.csv'),
('GaiaSource_666702-666726.csv'),
('GaiaSource_666727-666757.csv'),
('GaiaSource_666758-666768.csv'),
('GaiaSource_666769-666784.csv'),
('GaiaSource_666785-666794.csv'),
('GaiaSource_666795-666817.csv'),
('GaiaSource_666818-666866.csv'),
('GaiaSource_666867-666910.csv'),
('GaiaSource_666911-666973.csv'),
('GaiaSource_666974-667030.csv'),
('GaiaSource_667031-667067.csv'),
('GaiaSource_667068-667101.csv'),
('GaiaSource_667102-667129.csv'),
('GaiaSource_667130-667158.csv'),
('GaiaSource_667159-667193.csv'),
('GaiaSource_667194-667221.csv'),
('GaiaSource_667222-667250.csv'),
('GaiaSource_667251-667285.csv'),
('GaiaSource_667286-667310.csv'),
('GaiaSource_667311-667333.csv'),
('GaiaSource_667334-667354.csv'),
('GaiaSource_667355-667376.csv'),
('GaiaSource_667377-667405.csv'),
('GaiaSource_667406-667428.csv'),
('GaiaSource_667429-667451.csv'),
('GaiaSource_667452-667473.csv'),
('GaiaSource_667474-667497.csv'),
('GaiaSource_667498-667525.csv'),
('GaiaSource_667526-667552.csv'),
('GaiaSource_667553-667586.csv'),
('GaiaSource_667587-667620.csv'),
('GaiaSource_667621-667659.csv'),
('GaiaSource_667660-667691.csv'),
('GaiaSource_667692-667721.csv'),
('GaiaSource_667722-667765.csv'),
('GaiaSource_667766-667792.csv'),
('GaiaSource_667793-667816.csv'),
('GaiaSource_667817-667839.csv'),
('GaiaSource_667840-667866.csv'),
('GaiaSource_667867-667883.csv'),
('GaiaSource_667884-667898.csv'),
('GaiaSource_667899-667925.csv'),
('GaiaSource_667926-667950.csv'),
('GaiaSource_667951-667969.csv'),
('GaiaSource_667970-667988.csv'),
('GaiaSource_667989-668005.csv'),
('GaiaSource_668006-668025.csv'),
('GaiaSource_668026-668041.csv'),
('GaiaSource_668042-668058.csv'),
('GaiaSource_668059-668077.csv'),
('GaiaSource_668078-668109.csv'),
('GaiaSource_668110-668142.csv'),
('GaiaSource_668143-668168.csv'),
('GaiaSource_668169-668182.csv'),
('GaiaSource_668183-668198.csv'),
('GaiaSource_668199-668220.csv'),
('GaiaSource_668221-668244.csv'),
('GaiaSource_668245-668296.csv'),
('GaiaSource_668297-668350.csv'),
('GaiaSource_668351-668400.csv'),
('GaiaSource_668401-668444.csv'),
('GaiaSource_668445-668512.csv'),
('GaiaSource_668513-668562.csv'),
('GaiaSource_668563-668593.csv'),
('GaiaSource_668594-668624.csv'),
('GaiaSource_668625-668654.csv'),
('GaiaSource_668655-668676.csv'),
('GaiaSource_668677-668694.csv'),
('GaiaSource_668695-668711.csv'),
('GaiaSource_668712-668735.csv'),
('GaiaSource_668736-668751.csv'),
('GaiaSource_668752-668768.csv'),
('GaiaSource_668769-668804.csv'),
('GaiaSource_668805-668856.csv'),
('GaiaSource_668857-668928.csv'),
('GaiaSource_668929-668945.csv'),
('GaiaSource_668946-668974.csv'),
('GaiaSource_668975-669017.csv'),
('GaiaSource_669018-669102.csv'),
('GaiaSource_669103-669157.csv'),
('GaiaSource_669158-669187.csv'),
('GaiaSource_669188-669245.csv'),
('GaiaSource_669246-669277.csv'),
('GaiaSource_669278-669300.csv'),
('GaiaSource_669301-669327.csv'),
('GaiaSource_669328-669353.csv'),
('GaiaSource_669354-669380.csv'),
('GaiaSource_669381-669405.csv'),
('GaiaSource_669406-669433.csv'),
('GaiaSource_669434-669462.csv'),
('GaiaSource_669463-669486.csv'),
('GaiaSource_669487-669508.csv'),
('GaiaSource_669509-669528.csv'),
('GaiaSource_669529-669549.csv'),
('GaiaSource_669550-669572.csv'),
('GaiaSource_669573-669598.csv'),
('GaiaSource_669599-669632.csv'),
('GaiaSource_669633-669658.csv'),
('GaiaSource_669659-669696.csv'),
('GaiaSource_669697-669740.csv'),
('GaiaSource_669741-669777.csv'),
('GaiaSource_669778-669810.csv'),
('GaiaSource_669811-669847.csv'),
('GaiaSource_669848-669882.csv'),
('GaiaSource_669883-669915.csv'),
('GaiaSource_669916-669953.csv'),
('GaiaSource_669954-669978.csv'),
('GaiaSource_669979-670002.csv'),
('GaiaSource_670003-670029.csv'),
('GaiaSource_670030-670062.csv'),
('GaiaSource_670063-670098.csv'),
('GaiaSource_670099-670143.csv'),
('GaiaSource_670144-670188.csv'),
('GaiaSource_670189-670225.csv'),
('GaiaSource_670226-670260.csv'),
('GaiaSource_670261-670305.csv'),
('GaiaSource_670306-670356.csv'),
('GaiaSource_670357-670416.csv'),
('GaiaSource_670417-670484.csv'),
('GaiaSource_670485-670543.csv'),
('GaiaSource_670544-670607.csv'),
('GaiaSource_670608-670683.csv'),
('GaiaSource_670684-670737.csv'),
('GaiaSource_670738-670776.csv'),
('GaiaSource_670777-670818.csv'),
('GaiaSource_670819-670862.csv'),
('GaiaSource_670863-670917.csv'),
('GaiaSource_670918-670969.csv'),
('GaiaSource_670970-671011.csv'),
('GaiaSource_671012-671055.csv'),
('GaiaSource_671056-671102.csv'),
('GaiaSource_671103-671156.csv'),
('GaiaSource_671157-671219.csv'),
('GaiaSource_671220-671285.csv'),
('GaiaSource_671286-671355.csv'),
('GaiaSource_671356-671441.csv'),
('GaiaSource_671442-671529.csv'),
('GaiaSource_671530-671616.csv'),
('GaiaSource_671617-671727.csv'),
('GaiaSource_671728-671888.csv'),
('GaiaSource_671889-672007.csv'),
('GaiaSource_672008-672142.csv'),
('GaiaSource_672143-672238.csv'),
('GaiaSource_672239-672326.csv'),
('GaiaSource_672327-672403.csv'),
('GaiaSource_672404-672462.csv'),
('GaiaSource_672463-672514.csv'),
('GaiaSource_672515-672584.csv'),
('GaiaSource_672585-672645.csv'),
('GaiaSource_672646-672692.csv'),
('GaiaSource_672693-672736.csv'),
('GaiaSource_672737-672787.csv'),
('GaiaSource_672788-672903.csv'),
('GaiaSource_672904-672986.csv'),
('GaiaSource_672987-673072.csv'),
('GaiaSource_673073-673160.csv'),
('GaiaSource_673161-673224.csv'),
('GaiaSource_673225-673281.csv'),
('GaiaSource_673282-673338.csv'),
('GaiaSource_673339-673391.csv'),
('GaiaSource_673392-673434.csv'),
('GaiaSource_673435-673467.csv'),
('GaiaSource_673468-673502.csv'),
('GaiaSource_673503-673533.csv'),
('GaiaSource_673534-673579.csv'),
('GaiaSource_673580-673619.csv'),
('GaiaSource_673620-673653.csv'),
('GaiaSource_673654-673684.csv'),
('GaiaSource_673685-673712.csv'),
('GaiaSource_673713-673739.csv'),
('GaiaSource_673740-673765.csv'),
('GaiaSource_673766-673790.csv'),
('GaiaSource_673791-673834.csv'),
('GaiaSource_673835-673873.csv'),
('GaiaSource_673874-673909.csv'),
('GaiaSource_673910-673941.csv'),
('GaiaSource_673942-673967.csv'),
('GaiaSource_673968-673990.csv'),
('GaiaSource_673991-674015.csv'),
('GaiaSource_674016-674036.csv'),
('GaiaSource_674037-674062.csv'),
('GaiaSource_674063-674092.csv'),
('GaiaSource_674093-674120.csv'),
('GaiaSource_674121-674147.csv'),
('GaiaSource_674148-674170.csv'),
('GaiaSource_674171-674193.csv'),
('GaiaSource_674194-674213.csv'),
('GaiaSource_674214-674230.csv'),
('GaiaSource_674231-674247.csv'),
('GaiaSource_674248-674265.csv'),
('GaiaSource_674266-674281.csv'),
('GaiaSource_674282-674297.csv'),
('GaiaSource_674298-674314.csv'),
('GaiaSource_674315-674331.csv'),
('GaiaSource_674332-674346.csv'),
('GaiaSource_674347-674360.csv'),
('GaiaSource_674361-674374.csv'),
('GaiaSource_674375-674389.csv'),
('GaiaSource_674390-674403.csv'),
('GaiaSource_674404-674415.csv'),
('GaiaSource_674416-674428.csv'),
('GaiaSource_674429-674440.csv'),
('GaiaSource_674441-674452.csv'),
('GaiaSource_674453-674465.csv'),
('GaiaSource_674466-674485.csv'),
('GaiaSource_674486-674501.csv'),
('GaiaSource_674502-674515.csv'),
('GaiaSource_674516-674533.csv'),
('GaiaSource_674534-674562.csv'),
('GaiaSource_674563-674576.csv'),
('GaiaSource_674577-674592.csv'),
('GaiaSource_674593-674607.csv'),
('GaiaSource_674608-674621.csv'),
('GaiaSource_674622-674637.csv'),
('GaiaSource_674638-674655.csv'),
('GaiaSource_674656-674683.csv'),
('GaiaSource_674684-674702.csv'),
('GaiaSource_674703-674732.csv'),
('GaiaSource_674733-674782.csv'),
('GaiaSource_674783-674825.csv'),
('GaiaSource_674826-674848.csv'),
('GaiaSource_674849-674867.csv'),
('GaiaSource_674868-674887.csv'),
('GaiaSource_674888-674911.csv'),
('GaiaSource_674912-674930.csv'),
('GaiaSource_674931-674950.csv'),
('GaiaSource_674951-674967.csv'),
('GaiaSource_674968-674984.csv'),
('GaiaSource_674985-675011.csv'),
('GaiaSource_675012-675035.csv'),
('GaiaSource_675036-675068.csv'),
('GaiaSource_675069-675091.csv'),
('GaiaSource_675092-675114.csv'),
('GaiaSource_675115-675135.csv'),
('GaiaSource_675136-675159.csv'),
('GaiaSource_675160-675191.csv'),
('GaiaSource_675192-675220.csv'),
('GaiaSource_675221-675252.csv'),
('GaiaSource_675253-675295.csv'),
('GaiaSource_675296-675341.csv'),
('GaiaSource_675342-675365.csv'),
('GaiaSource_675366-675403.csv'),
('GaiaSource_675404-675446.csv'),
('GaiaSource_675447-675487.csv'),
('GaiaSource_675488-675516.csv'),
('GaiaSource_675517-675544.csv'),
('GaiaSource_675545-675568.csv'),
('GaiaSource_675569-675603.csv'),
('GaiaSource_675604-675631.csv'),
('GaiaSource_675632-675654.csv'),
('GaiaSource_675655-675687.csv'),
('GaiaSource_675688-675713.csv'),
('GaiaSource_675714-675735.csv'),
('GaiaSource_675736-675761.csv'),
('GaiaSource_675762-675784.csv'),
('GaiaSource_675785-675818.csv'),
('GaiaSource_675819-675887.csv'),
('GaiaSource_675888-675955.csv'),
('GaiaSource_675956-676009.csv'),
('GaiaSource_676010-676053.csv'),
('GaiaSource_676054-676090.csv'),
('GaiaSource_676091-676145.csv'),
('GaiaSource_676146-676198.csv'),
('GaiaSource_676199-676238.csv'),
('GaiaSource_676239-676271.csv'),
('GaiaSource_676272-676302.csv'),
('GaiaSource_676303-676332.csv'),
('GaiaSource_676333-676361.csv'),
('GaiaSource_676362-676392.csv'),
('GaiaSource_676393-676420.csv'),
('GaiaSource_676421-676450.csv'),
('GaiaSource_676451-676475.csv'),
('GaiaSource_676476-676499.csv'),
('GaiaSource_676500-676522.csv'),
('GaiaSource_676523-676546.csv'),
('GaiaSource_676547-676568.csv'),
('GaiaSource_676569-676595.csv'),
('GaiaSource_676596-676621.csv'),
('GaiaSource_676622-676644.csv'),
('GaiaSource_676645-676664.csv'),
('GaiaSource_676665-676683.csv'),
('GaiaSource_676684-676701.csv'),
('GaiaSource_676702-676717.csv'),
('GaiaSource_676718-676732.csv'),
('GaiaSource_676733-676749.csv'),
('GaiaSource_676750-676768.csv'),
('GaiaSource_676769-676797.csv'),
('GaiaSource_676798-676820.csv'),
('GaiaSource_676821-676848.csv'),
('GaiaSource_676849-676887.csv'),
('GaiaSource_676888-676925.csv'),
('GaiaSource_676926-676964.csv'),
('GaiaSource_676965-676998.csv'),
('GaiaSource_676999-677028.csv'),
('GaiaSource_677029-677054.csv'),
('GaiaSource_677055-677082.csv'),
('GaiaSource_677083-677107.csv'),
('GaiaSource_677108-677136.csv'),
('GaiaSource_677137-677166.csv'),
('GaiaSource_677167-677190.csv'),
('GaiaSource_677191-677214.csv'),
('GaiaSource_677215-677234.csv'),
('GaiaSource_677235-677253.csv'),
('GaiaSource_677254-677274.csv'),
('GaiaSource_677275-677294.csv'),
('GaiaSource_677295-677310.csv'),
('GaiaSource_677311-677326.csv'),
('GaiaSource_677327-677341.csv'),
('GaiaSource_677342-677356.csv'),
('GaiaSource_677357-677369.csv'),
('GaiaSource_677370-677386.csv'),
('GaiaSource_677387-677406.csv'),
('GaiaSource_677407-677420.csv'),
('GaiaSource_677421-677437.csv'),
('GaiaSource_677438-677458.csv'),
('GaiaSource_677459-677475.csv'),
('GaiaSource_677476-677495.csv'),
('GaiaSource_677496-677513.csv'),
('GaiaSource_677514-677530.csv'),
('GaiaSource_677531-677556.csv'),
('GaiaSource_677557-677580.csv'),
('GaiaSource_677581-677596.csv'),
('GaiaSource_677597-677619.csv'),
('GaiaSource_677620-677636.csv'),
('GaiaSource_677637-677651.csv'),
('GaiaSource_677652-677667.csv'),
('GaiaSource_677668-677686.csv'),
('GaiaSource_677687-677703.csv'),
('GaiaSource_677704-677717.csv'),
('GaiaSource_677718-677732.csv'),
('GaiaSource_677733-677752.csv'),
('GaiaSource_677753-677770.csv'),
('GaiaSource_677771-677794.csv'),
('GaiaSource_677795-677819.csv'),
('GaiaSource_677820-677843.csv'),
('GaiaSource_677844-677863.csv'),
('GaiaSource_677864-677882.csv'),
('GaiaSource_677883-677911.csv'),
('GaiaSource_677912-677973.csv'),
('GaiaSource_677974-678000.csv'),
('GaiaSource_678001-678036.csv'),
('GaiaSource_678037-678084.csv'),
('GaiaSource_678085-678151.csv'),
('GaiaSource_678152-678198.csv'),
('GaiaSource_678199-678236.csv'),
('GaiaSource_678237-678290.csv'),
('GaiaSource_678291-678377.csv'),
('GaiaSource_678378-678425.csv'),
('GaiaSource_678426-678467.csv'),
('GaiaSource_678468-678500.csv'),
('GaiaSource_678501-678526.csv'),
('GaiaSource_678527-678571.csv'),
('GaiaSource_678572-678602.csv'),
('GaiaSource_678603-678622.csv'),
('GaiaSource_678623-678645.csv'),
('GaiaSource_678646-678671.csv'),
('GaiaSource_678672-678698.csv'),
('GaiaSource_678699-678724.csv'),
('GaiaSource_678725-678762.csv'),
('GaiaSource_678763-678782.csv'),
('GaiaSource_678783-678802.csv'),
('GaiaSource_678803-678825.csv'),
('GaiaSource_678826-678851.csv'),
('GaiaSource_678852-678873.csv'),
('GaiaSource_678874-678895.csv'),
('GaiaSource_678896-678921.csv'),
('GaiaSource_678922-678950.csv'),
('GaiaSource_678951-678969.csv'),
('GaiaSource_678970-678997.csv'),
('GaiaSource_678998-679031.csv'),
('GaiaSource_679032-679086.csv'),
('GaiaSource_679087-679130.csv'),
('GaiaSource_679131-679189.csv'),
('GaiaSource_679190-679251.csv'),
('GaiaSource_679252-679326.csv'),
('GaiaSource_679327-679428.csv'),
('GaiaSource_679429-679451.csv'),
('GaiaSource_679452-679473.csv'),
('GaiaSource_679474-679500.csv'),
('GaiaSource_679501-679530.csv'),
('GaiaSource_679531-679547.csv'),
('GaiaSource_679548-679567.csv'),
('GaiaSource_679568-679585.csv'),
('GaiaSource_679586-679604.csv'),
('GaiaSource_679605-679620.csv'),
('GaiaSource_679621-679631.csv'),
('GaiaSource_679632-679641.csv'),
('GaiaSource_679642-679653.csv'),
('GaiaSource_679654-679664.csv'),
('GaiaSource_679665-679675.csv'),
('GaiaSource_679676-679700.csv'),
('GaiaSource_679701-679724.csv'),
('GaiaSource_679725-679757.csv'),
('GaiaSource_679758-679792.csv'),
('GaiaSource_679793-679810.csv'),
('GaiaSource_679811-679820.csv'),
('GaiaSource_679821-679832.csv'),
('GaiaSource_679833-679843.csv'),
('GaiaSource_679844-679852.csv'),
('GaiaSource_679853-679862.csv'),
('GaiaSource_679863-679874.csv'),
('GaiaSource_679875-679886.csv'),
('GaiaSource_679887-679903.csv'),
('GaiaSource_679904-679915.csv'),
('GaiaSource_679916-679929.csv'),
('GaiaSource_679930-679972.csv'),
('GaiaSource_679973-680038.csv'),
('GaiaSource_680039-680097.csv'),
('GaiaSource_680098-680132.csv'),
('GaiaSource_680133-680168.csv'),
('GaiaSource_680169-680207.csv'),
('GaiaSource_680208-680276.csv'),
('GaiaSource_680277-680324.csv'),
('GaiaSource_680325-680373.csv'),
('GaiaSource_680374-680413.csv'),
('GaiaSource_680414-680454.csv'),
('GaiaSource_680455-680478.csv'),
('GaiaSource_680479-680503.csv'),
('GaiaSource_680504-680532.csv'),
('GaiaSource_680533-680564.csv'),
('GaiaSource_680565-680596.csv'),
('GaiaSource_680597-680634.csv'),
('GaiaSource_680635-680672.csv'),
('GaiaSource_680673-680713.csv'),
('GaiaSource_680714-680749.csv'),
('GaiaSource_680750-680788.csv'),
('GaiaSource_680789-680825.csv'),
('GaiaSource_680826-680865.csv'),
('GaiaSource_680866-680910.csv'),
('GaiaSource_680911-680960.csv'),
('GaiaSource_680961-681005.csv'),
('GaiaSource_681006-681046.csv'),
('GaiaSource_681047-681092.csv'),
('GaiaSource_681093-681121.csv'),
('GaiaSource_681122-681162.csv'),
('GaiaSource_681163-681199.csv'),
('GaiaSource_681200-681232.csv'),
('GaiaSource_681233-681266.csv'),
('GaiaSource_681267-681303.csv'),
('GaiaSource_681304-681352.csv'),
('GaiaSource_681353-681402.csv'),
('GaiaSource_681403-681456.csv'),
('GaiaSource_681457-681500.csv'),
('GaiaSource_681501-681550.csv'),
('GaiaSource_681551-681609.csv'),
('GaiaSource_681610-681668.csv'),
('GaiaSource_681669-681733.csv'),
('GaiaSource_681734-681786.csv'),
('GaiaSource_681787-681864.csv'),
('GaiaSource_681865-681931.csv'),
('GaiaSource_681932-681999.csv'),
('GaiaSource_682000-682053.csv'),
('GaiaSource_682054-682113.csv'),
('GaiaSource_682114-682183.csv'),
('GaiaSource_682184-682255.csv'),
('GaiaSource_682256-682317.csv'),
('GaiaSource_682318-682391.csv'),
('GaiaSource_682392-682477.csv'),
('GaiaSource_682478-682570.csv'),
('GaiaSource_682571-682684.csv'),
('GaiaSource_682685-682808.csv'),
('GaiaSource_682809-682942.csv'),
('GaiaSource_682943-683057.csv'),
('GaiaSource_683058-683144.csv'),
('GaiaSource_683145-683244.csv'),
('GaiaSource_683245-683343.csv'),
('GaiaSource_683344-683454.csv'),
('GaiaSource_683455-683589.csv'),
('GaiaSource_683590-683787.csv'),
('GaiaSource_683788-683951.csv'),
('GaiaSource_683952-684057.csv'),
('GaiaSource_684058-684112.csv'),
('GaiaSource_684113-684148.csv'),
('GaiaSource_684149-684200.csv'),
('GaiaSource_684201-684259.csv'),
('GaiaSource_684260-684300.csv'),
('GaiaSource_684301-684335.csv'),
('GaiaSource_684336-684372.csv'),
('GaiaSource_684373-684412.csv'),
('GaiaSource_684413-684463.csv'),
('GaiaSource_684464-684500.csv'),
('GaiaSource_684501-684534.csv'),
('GaiaSource_684535-684615.csv'),
('GaiaSource_684616-684687.csv'),
('GaiaSource_684688-684761.csv'),
('GaiaSource_684762-684823.csv'),
('GaiaSource_684824-684881.csv'),
('GaiaSource_684882-684930.csv'),
('GaiaSource_684931-685004.csv'),
('GaiaSource_685005-685062.csv'),
('GaiaSource_685063-685083.csv'),
('GaiaSource_685084-685106.csv'),
('GaiaSource_685107-685123.csv'),
('GaiaSource_685124-685136.csv'),
('GaiaSource_685137-685147.csv'),
('GaiaSource_685148-685161.csv'),
('GaiaSource_685162-685175.csv'),
('GaiaSource_685176-685196.csv'),
('GaiaSource_685197-685224.csv'),
('GaiaSource_685225-685252.csv'),
('GaiaSource_685253-685271.csv'),
('GaiaSource_685272-685295.csv'),
('GaiaSource_685296-685314.csv'),
('GaiaSource_685315-685324.csv'),
('GaiaSource_685325-685334.csv'),
('GaiaSource_685335-685345.csv'),
('GaiaSource_685346-685356.csv'),
('GaiaSource_685357-685367.csv'),
('GaiaSource_685368-685378.csv'),
('GaiaSource_685379-685393.csv'),
('GaiaSource_685394-685405.csv'),
('GaiaSource_685406-685418.csv'),
('GaiaSource_685419-685430.csv'),
('GaiaSource_685431-685441.csv'),
('GaiaSource_685442-685455.csv'),
('GaiaSource_685456-685467.csv'),
('GaiaSource_685468-685483.csv'),
('GaiaSource_685484-685498.csv'),
('GaiaSource_685499-685510.csv'),
('GaiaSource_685511-685521.csv'),
('GaiaSource_685522-685533.csv'),
('GaiaSource_685534-685546.csv'),
('GaiaSource_685547-685561.csv'),
('GaiaSource_685562-685588.csv'),
('GaiaSource_685589-685627.csv'),
('GaiaSource_685628-685657.csv'),
('GaiaSource_685658-685689.csv'),
('GaiaSource_685690-685744.csv'),
('GaiaSource_685745-685798.csv'),
('GaiaSource_685799-685838.csv'),
('GaiaSource_685839-685859.csv'),
('GaiaSource_685860-685888.csv'),
('GaiaSource_685889-685906.csv'),
('GaiaSource_685907-685925.csv'),
('GaiaSource_685926-685948.csv'),
('GaiaSource_685949-685984.csv'),
('GaiaSource_685985-686026.csv'),
('GaiaSource_686027-686062.csv'),
('GaiaSource_686063-686128.csv'),
('GaiaSource_686129-686209.csv'),
('GaiaSource_686210-686314.csv'),
('GaiaSource_686315-686403.csv'),
('GaiaSource_686404-686500.csv'),
('GaiaSource_686501-686630.csv'),
('GaiaSource_686631-686780.csv'),
('GaiaSource_686781-686933.csv'),
('GaiaSource_686934-687105.csv'),
('GaiaSource_687106-687199.csv'),
('GaiaSource_687200-687311.csv'),
('GaiaSource_687312-687411.csv'),
('GaiaSource_687412-687480.csv'),
('GaiaSource_687481-687639.csv'),
('GaiaSource_687640-687899.csv'),
('GaiaSource_687900-688120.csv'),
('GaiaSource_688121-688148.csv'),
('GaiaSource_688149-688172.csv'),
('GaiaSource_688173-688195.csv'),
('GaiaSource_688196-688229.csv'),
('GaiaSource_688230-688266.csv'),
('GaiaSource_688267-688289.csv'),
('GaiaSource_688290-688317.csv'),
('GaiaSource_688318-688355.csv'),
('GaiaSource_688356-688384.csv'),
('GaiaSource_688385-688446.csv'),
('GaiaSource_688447-688487.csv'),
('GaiaSource_688488-688520.csv'),
('GaiaSource_688521-688548.csv'),
('GaiaSource_688549-688573.csv'),
('GaiaSource_688574-688603.csv'),
('GaiaSource_688604-688631.csv'),
('GaiaSource_688632-688658.csv'),
('GaiaSource_688659-688691.csv'),
('GaiaSource_688692-688717.csv'),
('GaiaSource_688718-688742.csv'),
('GaiaSource_688743-688773.csv'),
('GaiaSource_688774-688809.csv'),
('GaiaSource_688810-688847.csv'),
('GaiaSource_688848-688883.csv'),
('GaiaSource_688884-688915.csv'),
('GaiaSource_688916-688947.csv'),
('GaiaSource_688948-688981.csv'),
('GaiaSource_688982-689023.csv'),
('GaiaSource_689024-689065.csv'),
('GaiaSource_689066-689116.csv'),
('GaiaSource_689117-689162.csv'),
('GaiaSource_689163-689188.csv'),
('GaiaSource_689189-689217.csv'),
('GaiaSource_689218-689250.csv'),
('GaiaSource_689251-689291.csv'),
('GaiaSource_689292-689326.csv'),
('GaiaSource_689327-689377.csv'),
('GaiaSource_689378-689428.csv'),
('GaiaSource_689429-689478.csv'),
('GaiaSource_689479-689544.csv'),
('GaiaSource_689545-689621.csv'),
('GaiaSource_689622-689689.csv'),
('GaiaSource_689690-689750.csv'),
('GaiaSource_689751-689828.csv'),
('GaiaSource_689829-689925.csv'),
('GaiaSource_689926-690023.csv'),
('GaiaSource_690024-690137.csv'),
('GaiaSource_690138-690202.csv'),
('GaiaSource_690203-690241.csv'),
('GaiaSource_690242-690295.csv'),
('GaiaSource_690296-690342.csv'),
('GaiaSource_690343-690400.csv'),
('GaiaSource_690401-690464.csv'),
('GaiaSource_690465-690542.csv'),
('GaiaSource_690543-690623.csv'),
('GaiaSource_690624-690705.csv'),
('GaiaSource_690706-690770.csv'),
('GaiaSource_690771-690846.csv'),
('GaiaSource_690847-690937.csv'),
('GaiaSource_690938-691043.csv'),
('GaiaSource_691044-691184.csv'),
('GaiaSource_691185-691302.csv'),
('GaiaSource_691303-691436.csv'),
('GaiaSource_691437-691587.csv'),
('GaiaSource_691588-691712.csv'),
('GaiaSource_691713-691892.csv'),
('GaiaSource_691893-692119.csv'),
('GaiaSource_692120-692274.csv'),
('GaiaSource_692275-692370.csv'),
('GaiaSource_692371-692479.csv'),
('GaiaSource_692480-692577.csv'),
('GaiaSource_692578-692694.csv'),
('GaiaSource_692695-692818.csv'),
('GaiaSource_692819-692966.csv'),
('GaiaSource_692967-693129.csv'),
('GaiaSource_693130-693292.csv'),
('GaiaSource_693293-693427.csv'),
('GaiaSource_693428-693584.csv'),
('GaiaSource_693585-693766.csv'),
('GaiaSource_693767-693981.csv'),
('GaiaSource_693982-694237.csv'),
('GaiaSource_694238-694455.csv'),
('GaiaSource_694456-694702.csv'),
('GaiaSource_694703-695006.csv'),
('GaiaSource_695007-695362.csv'),
('GaiaSource_695363-695701.csv'),
('GaiaSource_695702-696143.csv'),
('GaiaSource_696144-696386.csv'),
('GaiaSource_696387-696521.csv'),
('GaiaSource_696522-696698.csv'),
('GaiaSource_696699-696897.csv'),
('GaiaSource_696898-697115.csv'),
('GaiaSource_697116-697394.csv'),
('GaiaSource_697395-697683.csv'),
('GaiaSource_697684-698055.csv'),
('GaiaSource_698056-698458.csv'),
('GaiaSource_698459-698807.csv'),
('GaiaSource_698808-699246.csv'),
('GaiaSource_699247-699779.csv'),
('GaiaSource_699780-700445.csv'),
('GaiaSource_700446-700929.csv'),
('GaiaSource_700930-701539.csv'),
('GaiaSource_701540-702228.csv'),
('GaiaSource_702229-703045.csv'),
('GaiaSource_703046-704043.csv'),
('GaiaSource_704044-704615.csv'),
('GaiaSource_704616-704822.csv'),
('GaiaSource_704823-705074.csv'),
('GaiaSource_705075-705381.csv'),
('GaiaSource_705382-705697.csv'),
('GaiaSource_705698-705968.csv'),
('GaiaSource_705969-706346.csv'),
('GaiaSource_706347-706757.csv'),
('GaiaSource_706758-707257.csv'),
('GaiaSource_707258-707825.csv'),
('GaiaSource_707826-708423.csv'),
('GaiaSource_708424-708791.csv'),
('GaiaSource_708792-709048.csv'),
('GaiaSource_709049-709433.csv'),
('GaiaSource_709434-709747.csv'),
('GaiaSource_709748-710046.csv'),
('GaiaSource_710047-710412.csv'),
('GaiaSource_710413-710845.csv'),
('GaiaSource_710846-711444.csv'),
('GaiaSource_711445-712016.csv'),
('GaiaSource_712017-712641.csv'),
('GaiaSource_712642-713432.csv'),
('GaiaSource_713433-714343.csv'),
('GaiaSource_714344-715497.csv'),
('GaiaSource_715498-716837.csv'),
('GaiaSource_716838-717825.csv'),
('GaiaSource_717826-718777.csv'),
('GaiaSource_718778-720122.csv'),
('GaiaSource_720123-721214.csv'),
('GaiaSource_721215-721969.csv'),
('GaiaSource_721970-722959.csv'),
('GaiaSource_722960-723580.csv'),
('GaiaSource_723581-724204.csv'),
('GaiaSource_724205-725020.csv'),
('GaiaSource_725021-726249.csv'),
('GaiaSource_726250-727564.csv'),
('GaiaSource_727565-728738.csv'),
('GaiaSource_728739-729424.csv'),
('GaiaSource_729425-729840.csv'),
('GaiaSource_729841-730349.csv'),
('GaiaSource_730350-730993.csv'),
('GaiaSource_730994-731375.csv'),
('GaiaSource_731376-731725.csv'),
('GaiaSource_731726-732020.csv'),
('GaiaSource_732021-732459.csv'),
('GaiaSource_732460-732967.csv'),
('GaiaSource_732968-733739.csv'),
('GaiaSource_733740-734791.csv'),
('GaiaSource_734792-735726.csv'),
('GaiaSource_735727-736505.csv'),
('GaiaSource_736506-737645.csv'),
('GaiaSource_737646-739536.csv'),
('GaiaSource_739537-741346.csv'),
('GaiaSource_741347-743869.csv'),
('GaiaSource_743870-746018.csv'),
('GaiaSource_746019-747583.csv'),
('GaiaSource_747584-748817.csv'),
('GaiaSource_748818-750556.csv'),
('GaiaSource_750557-752583.csv'),
('GaiaSource_752584-753779.csv'),
('GaiaSource_753780-754028.csv'),
('GaiaSource_754029-754283.csv'),
('GaiaSource_754284-754492.csv'),
('GaiaSource_754493-754778.csv'),
('GaiaSource_754779-755222.csv'),
('GaiaSource_755223-755601.csv'),
('GaiaSource_755602-755839.csv'),
('GaiaSource_755840-756008.csv'),
('GaiaSource_756009-756228.csv'),
('GaiaSource_756229-756367.csv'),
('GaiaSource_756368-756503.csv'),
('GaiaSource_756504-756682.csv'),
('GaiaSource_756683-756934.csv'),
('GaiaSource_756935-757268.csv'),
('GaiaSource_757269-757502.csv'),
('GaiaSource_757503-757838.csv'),
('GaiaSource_757839-758432.csv'),
('GaiaSource_758433-759078.csv'),
('GaiaSource_759079-759805.csv'),
('GaiaSource_759806-760276.csv'),
('GaiaSource_760277-760668.csv'),
('GaiaSource_760669-761182.csv'),
('GaiaSource_761183-761683.csv'),
('GaiaSource_761684-761924.csv'),
('GaiaSource_761925-762031.csv'),
('GaiaSource_762032-762143.csv'),
('GaiaSource_762144-762283.csv'),
('GaiaSource_762284-762398.csv'),
('GaiaSource_762399-762484.csv'),
('GaiaSource_762485-762556.csv'),
('GaiaSource_762557-762635.csv'),
('GaiaSource_762636-762746.csv'),
('GaiaSource_762747-762839.csv'),
('GaiaSource_762840-762999.csv'),
('GaiaSource_763000-763191.csv'),
('GaiaSource_763192-763415.csv'),
('GaiaSource_763416-763560.csv'),
('GaiaSource_763561-763702.csv'),
('GaiaSource_763703-763886.csv'),
('GaiaSource_763887-763956.csv'),
('GaiaSource_763957-764020.csv'),
('GaiaSource_764021-764072.csv'),
('GaiaSource_764073-764123.csv'),
('GaiaSource_764124-764184.csv'),
('GaiaSource_764185-764265.csv'),
('GaiaSource_764266-764334.csv'),
('GaiaSource_764335-764399.csv'),
('GaiaSource_764400-764443.csv'),
('GaiaSource_764444-764478.csv'),
('GaiaSource_764479-764522.csv'),
('GaiaSource_764523-764557.csv'),
('GaiaSource_764558-764586.csv'),
('GaiaSource_764587-764614.csv'),
('GaiaSource_764615-764644.csv'),
('GaiaSource_764645-764668.csv'),
('GaiaSource_764669-764711.csv'),
('GaiaSource_764712-764755.csv'),
('GaiaSource_764756-764799.csv'),
('GaiaSource_764800-764831.csv'),
('GaiaSource_764832-764856.csv'),
('GaiaSource_764857-764887.csv'),
('GaiaSource_764888-764915.csv'),
('GaiaSource_764916-764977.csv'),
('GaiaSource_764978-765069.csv'),
('GaiaSource_765070-765137.csv'),
('GaiaSource_765138-765220.csv'),
('GaiaSource_765221-765324.csv'),
('GaiaSource_765325-765403.csv'),
('GaiaSource_765404-765466.csv'),
('GaiaSource_765467-765512.csv'),
('GaiaSource_765513-765562.csv'),
('GaiaSource_765563-765596.csv'),
('GaiaSource_765597-765623.csv'),
('GaiaSource_765624-765656.csv'),
('GaiaSource_765657-765687.csv'),
('GaiaSource_765688-765735.csv'),
('GaiaSource_765736-765789.csv'),
('GaiaSource_765790-765836.csv'),
('GaiaSource_765837-765869.csv'),
('GaiaSource_765870-765904.csv'),
('GaiaSource_765905-765940.csv'),
('GaiaSource_765941-766146.csv'),
('GaiaSource_766147-766464.csv'),
('GaiaSource_766465-766667.csv'),
('GaiaSource_766668-766857.csv'),
('GaiaSource_766858-767082.csv'),
('GaiaSource_767083-767466.csv'),
('GaiaSource_767467-767715.csv'),
('GaiaSource_767716-768009.csv'),
('GaiaSource_768010-768122.csv'),
('GaiaSource_768123-768203.csv'),
('GaiaSource_768204-768295.csv'),
('GaiaSource_768296-768422.csv'),
('GaiaSource_768423-768527.csv'),
('GaiaSource_768528-768578.csv'),
('GaiaSource_768579-768640.csv'),
('GaiaSource_768641-768681.csv'),
('GaiaSource_768682-768725.csv'),
('GaiaSource_768726-768785.csv'),
('GaiaSource_768786-768883.csv'),
('GaiaSource_768884-768959.csv'),
('GaiaSource_768960-769073.csv'),
('GaiaSource_769074-769257.csv'),
('GaiaSource_769258-769482.csv'),
('GaiaSource_769483-769638.csv'),
('GaiaSource_769639-769750.csv'),
('GaiaSource_769751-769898.csv'),
('GaiaSource_769899-770037.csv'),
('GaiaSource_770038-770898.csv'),
('GaiaSource_770899-772057.csv'),
('GaiaSource_772058-772756.csv'),
('GaiaSource_772757-773504.csv'),
('GaiaSource_773505-774449.csv'),
('GaiaSource_774450-776043.csv'),
('GaiaSource_776044-777230.csv'),
('GaiaSource_777231-778401.csv'),
('GaiaSource_778402-778884.csv'),
('GaiaSource_778885-779312.csv'),
('GaiaSource_779313-779914.csv'),
('GaiaSource_779915-780373.csv'),
('GaiaSource_780374-780679.csv'),
('GaiaSource_780680-780934.csv'),
('GaiaSource_780935-781145.csv'),
('GaiaSource_781146-781445.csv'),
('GaiaSource_781446-781856.csv'),
('GaiaSource_781857-782176.csv'),
('GaiaSource_782177-782770.csv'),
('GaiaSource_782771-783517.csv'),
('GaiaSource_783518-784479.csv'),
('GaiaSource_784480-784992.csv'),
('GaiaSource_784993-785417.csv'),
('GaiaSource_785418-786096.csv'),
('GaiaSource_786097-786431.csv'));


type
  starlist = array of array of double;
  ansichar_array = array of ansichar;

var
  ra1,dec1:double;
  mag1,b_r    :integer;
  leadname: string;
  readposition1,readposition2,nr_of_straylight : integer;
  ftext: textfile;
  thepath, typ : string;
  starcount, starcount2,starcount3 : array[-150..2400] of integer;//mag-1.5 up to 24


  G_to_V_correctie  : double=0.3; {V:=GP+0.3}
  G_to_BP_correctie : double=0.5; {BP:=GP+0.5}
  sort_type                 : integer=0;
  stars1,stars2             : starlist;
  blink                     : boolean=true;

const
  keypressed :word=0;



  {$ifdef mswindows}
procedure ExecuteAndWait(const aCommando: string;show_console:boolean);
var
  tmpStartupInfo: TStartupInfo;
  tmpProcessInformation: TProcessInformation;
  tmpProgram: String;
  console :longint;

begin
  tmpProgram := trim(aCommando);
  FillChar(tmpStartupInfo, SizeOf(tmpStartupInfo), 0);
  with tmpStartupInfo do
  begin
    cb := SizeOf(TStartupInfo);
    wShowWindow := SW_HIDE;
  end;
  if show_console then console:=CREATE_NEW_CONSOLE else console:=CREATE_NO_WINDOW;

  if CreateProcess(nil, pchar(tmpProgram), nil, nil, true, console ,
    nil, nil, tmpStartupInfo, tmpProcessInformation) then
  begin
    // loop every 50 ms
    while WaitForSingleObject(tmpProcessInformation.hProcess, 50) > 0 do
    begin
      Application.ProcessMessages;
    end;
    FileClose(tmpProcessInformation.hProcess); { *Converted from CloseHandle* }
    FileClose(tmpProcessInformation.hThread); { *Converted from CloseHandle* }
  end
  else
  begin
    RaiseLastOSError;
  end;
end;
{$else} {unix}

procedure execute_unix2(s:string);
var ex :integer;
begin
  ex:=fpsystem(s);
  if ex>3 then showmessage(pchar(wexitStatus));
end;
{$endif}




{$ifdef mswindows}
function ShutMeDown:string;
var
  hToken : THandle;
  tkp,p : TTokenPrivileges;
  RetLen : DWord;
  ExReply: LongBool;
  Reply : DWord;
begin
  if OpenProcessToken(GetCurrentProcess,TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY,hToken) then
  begin
    if LookupPrivilegeValue(nil,'SeShutdownPrivilege',tkp .Privileges[0].Luid) then
    begin
      tkp.PrivilegeCount := 1;
      tkp.Privileges[0].Attributes := SE_PRIVILEGE_ENABLED;
      AdjustTokenPrivileges(hToken,False,tkp,SizeOf(TTokenPrivileges),p,RetLen);
      Reply := GetLastError;
      if Reply = ERROR_SUCCESS then
      begin
        ExReply:= ExitWindowsEx(EWX_POWEROFF or EWX_FORCE, 0);
        if ExReply then Result:='Shutdown Initiated'
        else
        Result:='Shutdown failed with ' + IntToStr(GetLastError);
      end;
    end;
  end;
end;
{$else} {unix}
{$endif}


function inttostr(inp:integer): string;
begin
  str(inp,result);
end;

function doubletostr(inp:double): string;
begin
  str(inp:0:5,result);
end;

function strtostr_divide10(s1:string):string; {this give much smaller exe file then using strtofloat}
var
   err:integer; r:double;
begin
  val(s1,r,err);
  if err=0 then
  begin
    r:=r/10;
    str(r:0:1,result);
  end;
end;

function floattostr_one_digit(r:double):string;
begin
    str(r:0:1,result);
end;


procedure writetextfile(new1:boolean; name, message1:string);
var F: TextFile;
begin
  AssignFile(F,main_form.gaia_path2.text+PathDelim+name);//cant be too long !!
  if new1 then Rewrite(F) {clear previous info}
          else Append(f);
  Writeln(F,formatdatetime('c', now)+'; '+message1);
  Flush(f);  { Ensures that the text was actually written to file. }
  CloseFile(F);
end;


procedure writeLONGREPORT;
var F: TextFile;
    i : integer;
begin
  AssignFile(F,main_form.gaia_path2.text+PathDelim+'longreport.txt'+'result_sort_small_steps'+typ+'.txt');
  Rewrite(F); {clear previous info}
  Writeln(F,'mag x 100; bp_stars; stars_without_bp; stars_effect_by_straylight');
  for i:=-150 to 2300 do
      Writeln(F,inttostr(i)+';'+inttostr(starcount[i])+';'+inttostr(starcount2[i])+';'+inttostr(starcount3[i]) );{keep record in steps of 0.01 magnitude. first value stars with BP other without}
  CloseFile(F);
end;

procedure convert_A6to5;
var i,j:integer;
    name1:string;
    info1  : array[0..112] of ansichar;
    fromf    : file;
    buf5: array[1..12] of byte;
    p5           : ^hnskyhdr290_5;		        { pointer to hnskyrecord }
    marker_record, mag2, rec_pos_start, rec_pos_stop,
    filesizevalue                                       :  integer;
    all_records  : array of hnskyhdr290_A6;
    recordposition, nr_of_records :integer;
begin
  writetextfile(true,'result6to5.txt','Started');{clear previous message}
  nr_of_stars:=0;

  for i:=1 to 290 do {create,  reset output files}
  begin
    name1:= Main_form.abbreviation1.text+'_' +filenames290[i];
    main_form.compact_status1.caption:='Making 5 byte record database from: '+name1;
    Application.ProcessMessages; {allow application  to update form1 with above messages}

    assignfile(fromf,name1);
    filemode:=0;{read}
    reset(fromf,1);
    Blockread(fromf,info1,110);

    ///temp!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//    strpcopy(info1,copy('GAIA DR3, density<='+Main_form.edit_density1.text+' stars/sqr(degree), Epoch='+Main_form.epoch1.text+'. Including 82 bright Tycho2 stars. Magnitude is BP                                                                    ',1,112));{do not  override  length of info1, otherwise error at the end of program}
//    info1[109]:=#$A6;



    if info1[109]=#$A6 then
        info1[109]:=#5 {5 byte record}
    else
     begin
       messagebox(main_form.handle,pchar('Error not $A6 byte record source file !'),pchar('Converting 6 to 5 bytes'),MB_ICONINFORMATION);
       closefile(fromf);
       exit;
    end;


    filesizevalue:=FileSize(fromf);
    nr_of_records:=round((filesizevalue-110)/SizeOf(hnskyhdr290_A6));
    SetLength(all_records,nr_of_records+1);
    Blockread(fromf,all_records[0],nr_of_records*SizeOf(hnskyhdr290_A6));{read all records at once}
    recordposition:=0;

    assignfile(tof,'tmp_' +filenames290[i]);{designation files}
    filemode:=2;{read/write}
    rewrite(tof,1);


    Blockwrite(tof,info1,110,Numwritten);{header is 110 bytes }
    if numwritten<>110 then
    begin
      messagebox(main_form.handle,pchar('ERROR !!! Can"t create file files. Close HNSKY'),pchar('Error'),MB_ICONERROR);
      closefile(fromf);
      closefile(tof);
      exit;
    end;


    rec_pos_start:=0;{skip header, start where the magnitude starts}
    rec_pos_stop:=0;{skip header, start where the magnitude stops}

    repeat
      marker_record:=-999;
      for j:=0 to 255 do
      begin
        recordposition:=rec_pos_start;
        p5:= @buf5[1];			{ set pointer }
        repeat {Go through all 255 dec9 values}
          if  ((all_records[recordposition].ra7=255) and (all_records[recordposition].ra8=255) and (all_records[recordposition].ra9=255))  then  {special magnitude record is found}
          begin {special 6 byte record}
            if all_records[recordposition].dec9>-20 then mag2:=all_records[recordposition].dec9 else  mag2:=256+all_records[recordposition].dec9;{new magn 12.8 is -12.8, 12.9 = -12.7}
             {magnitude is stored in mag2 till new magnitude record is found}
             rec_pos_stop:=recordposition;{where the magnitude starts}
          end
          else
          begin {same magnitude}

            if all_records[recordposition].dec9+128=j then {within dec9 range}
            begin
              if all_records[recordposition].dec9+128<>marker_record then {compare highest shortint of Dec if already seen and written}
              begin
                marker_record:=j; {remember first marker record is written}
              {Right accension===========================================}
                p5.ra7 := $FF;
                p5.ra8 := $FF;
                p5.ra9 := $FF;{set marker for new magnitude in record}
                {declination part===========================================}
                {store 2 bytes for dec9 and mag0}
                p5.dec7 := all_records[recordposition].dec9+128;{store dec9 shortint as byte}
                p5.dec8 := mag2+16;{store mag0 shortint as byte with 16 offset for negative numbers}
                blockwrite(tof,buf5, SizeOf(hnskyhdr290_5),Numwritten);
              end;

             {now write real data,dec9 and mag0 are stored ONCE in marker record}
              {Right accension===========================================}
              p5.ra7 :=all_records[recordposition].ra7;
              p5.ra8 :=all_records[recordposition].ra8;
              p5.ra9 :=all_records[recordposition].ra9;
              {declination===========================================}
              p5.dec7 := all_records[recordposition].dec7;
              p5.dec8 := all_records[recordposition].dec8;{dec9 and mag0 are stored in marker record}
              blockwrite(tof,buf5, SizeOf(hnskyhdr290_5),Numwritten);
              inc(nr_of_stars);
            end;{withing dec9 range}
          end;{do all 255 dec9 values}
          inc(recordposition);
        until   ((rec_pos_stop>rec_pos_start+1) or (recordposition>=nr_of_records) );{where the magnitude starts}
        if j<>255 then recordposition:=rec_pos_start;{go back to the beginning of the magnitude, but not at last cyclus to enable eof dectection}

        if keypressed=vk_F4 then begin closefile(tof);  halt; end;;
        if keypressed=vk_F7  then
        begin
          repeat
            main_form.status1.caption:='Paused';
            if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
            if blink then blink:=false else  blink:=true;{blinker}
            sleep(500);
            Application.ProcessMessages; {allow application  to update form1 with above messages}
          until keypressed=vk_F8;
          main_form.status1.caption:='Running';
        end;

        if j=0 then main_form.compact_status1.caption:='Making 5 byte record database from: '+name1+', magn: '+inttostr(mag2)+', stars_done: '+inttostr(nr_of_stars);;
      end;{for j loop}
      rec_pos_start:=rec_pos_stop; {do next magnitude}
    until recordposition>=nr_of_records; ;{all magnitudes done}

    writetextfile(false,'result6to5.txt',name1+ ' total stars_done:'+inttostr(nr_of_stars));{write result to file}
    closefile(tof);
    closefile(fromf);
  end;{i loop}

end;

procedure convert_A7to6;
var i,j:integer;
    name1:string;
    info1  : array[0..112] of ansichar;
    fromf    : file;
    buf6: array[1..12] of byte;
    p6         : ^hnskyhdr290_6;
    marker_record, mag2, rec_pos_start, rec_pos_stop,
    filesizevalue                                       :  integer;
    all_records  : array of hnskyhdr290_A7;
    recordposition, nr_of_records :integer;
begin
  writetextfile(true,'result7to6.txt','Started');{clear previous message}
  nr_of_stars:=0;

  for i:=1 to 290 do {create,  reset output files}
  begin
    name1:= Main_form.abbreviation1.text+'_' +filenames290[i]; {use for destination TYC file names and not UCAC4 names}
    main_form.compact_status1.caption:='Making 5 byte record database from: '+name1;
    Application.ProcessMessages; {allow application  to update form1 with above messages}

    assignfile(fromf,name1);
    filemode:=0;{read}
    reset(fromf,1);
    Blockread(fromf,info1,110);

    if info1[109]=#$A7 then
        info1[109]:=#6 {6 byte record}
    else
    begin
       messagebox(main_form.handle,pchar('Error not $A7 byte record source file !'),pchar('Converting 7 to 6 bytes'),MB_ICONINFORMATION);
       exit;
    end;


    filesizevalue:=FileSize(fromf);
    nr_of_records:=round((filesizevalue-110)/SizeOf(hnskyhdr290_A7));
    SetLength(all_records,nr_of_records+1);
    Blockread(fromf,all_records[0],nr_of_records*SizeOf(hnskyhdr290_A7));{read all records at once}
    recordposition:=0;

    assignfile(tof,'tmp_' +filenames290[i]);{designation files}
    filemode:=2;{read/write}
    rewrite(tof,1);
    Blockwrite(tof,info1,110,Numwritten);{header is 110 bytes }
    if numwritten<>110 then
    begin
      messagebox(main_form.handle,pchar('ERROR !!! Can"t create file files. Close HNSKY'),pchar('Error'),MB_ICONERROR);
      exit;
    end;


    rec_pos_start:=0;{skip header, start where the magnitude starts}
    rec_pos_stop:=0;{skip header, start where the magnitude stops}

    repeat
      marker_record:=-999;
      for j:=0 to 255 do
      begin
        recordposition:=rec_pos_start;
        p6:= @buf6[1];			{ set pointer }

        repeat {do all 255 dec9 values}
          if  ((all_records[recordposition].ra7=255) and (all_records[recordposition].ra8=255) and (all_records[recordposition].ra9=255))  then  {special magnitude record is found}
          begin {special 6 byte record}
            if all_records[recordposition].dec9>-20 then mag2:=all_records[recordposition].dec9 else  mag2:=256+all_records[recordposition].dec9;{new magn 12.8 is -12.8, 12.9 = -12.7}
             {magnitude is stored in mag2 till new magnitude record is found}
             rec_pos_stop:=recordposition;{where the magnitude starts}
          end
          else
          begin {same magnitude}

            if all_records[recordposition].dec9+128=j then {within dec9 range}
            begin
              if all_records[recordposition].dec9+128<>marker_record then {compare highest shortint of Dec if already seen and written}
              begin
                marker_record:=j; {remember first marker record is written}
              {Right accension===========================================}
                 p6.ra7 := $FF;
                 p6.ra8 := $FF;
                 p6.ra9 := $FF;{set marker for new magnitude in record}

                {declination part===========================================}
                {store 2 bytes for dec9 and mag0}
                 p6.dec7 := all_records[recordposition].dec9+128;{store dec9 shortint as byte}
                 p6.dec8 := mag2+16;{store mag0 shortint as byte with 16 offset for negative numbers}
                 p6.bp_rp := 0;
                 blockwrite(tof,buf6, SizeOf(hnskyhdr290_6),Numwritten);
              end;
              {now write real data,dec9 and mag0 are stored ONCE in marker record}
              {Right accension===========================================}
              p6.ra7 :=all_records[recordposition].ra7;
              p6.ra8 :=all_records[recordposition].ra8;
              p6.ra9 :=all_records[recordposition].ra9;
              {declination===========================================}
              p6.dec7 := all_records[recordposition].dec7;
              p6.dec8 := all_records[recordposition].dec8;{dec9 and mag0 are stored in marker record}
              p6.bp_rp:=all_records[recordposition].bp_rp;
              blockwrite(tof,buf6, SizeOf(hnskyhdr290_6),Numwritten);
              inc(nr_of_stars);

            end;{withing dec9 range}
          end;{do all 255 dec9 values}
          inc(recordposition);
        until   ((rec_pos_stop>rec_pos_start+1) or (recordposition>=nr_of_records) );{where the magnitude starts}
        if j<>255 then recordposition:=rec_pos_start;{go back to the beginning of the magnitude, but not at last cyclus to enable eof dectection}

        if keypressed=vk_F4 then begin closefile(tof);  halt; end;;
        if keypressed=vk_F7  then
        begin
          repeat
            main_form.status1.caption:='Paused';
            if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
            if blink then blink:=false else  blink:=true;{blinker}
            sleep(500);
            Application.ProcessMessages; {allow application  to update form1 with above messages}
          until keypressed=vk_F8;
          main_form.status1.caption:='Running';
        end;

        if j=0 then main_form.compact_status1.caption:='Making 6 byte record database from: '+name1+', magn: '+inttostr(mag2)+', stars_done: '+inttostr(nr_of_stars);;
      end;{for j loop}
      rec_pos_start:=rec_pos_stop; {do next magnitude}
    until recordposition>=nr_of_records; ;{all magnitudes done}

    writetextfile(false,'result7to6.txt',name1+ ' total stars_done:'+inttostr(nr_of_stars));{write result to file}
    closefile(tof);
    closefile(fromf);
  end;{i loop}


end;

procedure TMain_form.convert_to_smaller_record1Click(Sender: TObject);
var
  i : integer;
  name1,name2,tempname : string;
  newDateTime : TDateTime;

begin
  if main_form.bp_magnitude1.checked then sort_type:=0
  else
  if main_form.v_magnitude2.checked then sort_type:=1
  else
  if main_form.V_magnitude_and_BR1.checked then sort_type:=2;

  if sort_type<>0 then typ:='V' else typ:='B';

  if ((main_form.v_magnitude2.checked=false) and (main_form.BP_magnitude1.checked=false) and (main_form.V_magnitude_and_BR1.checked=false)) then
  begin
    messagebox(main_form.handle,pchar('Selection missing. Specify magnitude type in step 1'),pchar('Error'),MB_ICONERROR);
    exit;
  end;

  if V_magnitude_and_BR1.checked=false then
                                       convert_A6to5
                                       else
                                       convert_A7to6;

  main_form.status1.caption:='Running';

  for i:=1 to 290 do
  begin

    name1:= Main_form.abbreviation1.text+'_' +filenames290[i]; {source files}
    tempname:='gxx_' +filenames290[i];
    renamefile(name1,tempname);{G16 source to gxx}

    name2:='tmp_' +filenames290[i];{result file files}
    renamefile(name2,name1);{tmp result to g16}

    renamefile(tempname,name2);{rename gxx to tmp}


    newDateTime :=date;
    FileSetDate(name1, DateTimeToFileDate(newDateTime));{set date to midnight}
  end;

  if ((Main_form.powerdown_enabled.checked)and (nr_of_stars>100)) then
  {$ifdef mswindows}
  main_form.caption:= ShutMeDown
  {$else} {unix}
  fpSystem('/sbin/shutdown -P now')
  {$endif}
  else
  messagebox(main_form.handle,pchar('Ready.   Stars done:'+ inttostr(nr_of_stars)),pchar('Ready'),MB_ICONINFORMATION);
  main_form.status1.caption:='Finished';

  //writelongreport;{write log file in steps of 0.01 magn}


end;



procedure write_new_magnitude_recordA6(magn:integer);{marker record indicating new magnitude step of 0.1 magn for 6 byte records}
var
  buf2: array[1..12] of byte;
  p6           : ^hnskyhdr290_A6;		        { pointer to hnskyrecord }

begin
  p6:= @buf2[1];			{ set pointer }
  with p6^ do
  begin
   {Right accension===========================================}
    ra7 := $FF;
    ra8 := $FF;
    ra9 := $FF;{set marker for new magnitude in record}

   {declination===========================================}
   {make 3 byte integer:}
    dec7 := 0;
    dec8 := 0;
    dec9 := shortint(magn);{store magnitude in highest byte, allowing more digits later. note 128 is written as -128, 129 is written as -127, 130 as -126}
  end;
  blockwrite(tof,buf2, SizeOf(hnskyhdr290_6),Numwritten);
end;


procedure write_new_magnitude_recordA7(magn:integer);{marker record indicating new magnitude step of 0.1 magn for 6 byte records}
var
  buf2: array[1..12] of byte;
  pA7           : ^hnskyhdr290_A7;		        { pointer to hnskyrecord }
begin
  pA7:= @buf2[1];			{ set pointer }
  with pA7^ do
  begin
   {Right accension===========================================}
    ra7 := $FF;
    ra8 := $FF;
    ra9 := $FF;{set marker for new magnitude in record}

   {declination===========================================}
   {make 3 byte integer:}
    dec7 := 0;
    dec8 := 0;
    dec9 := shortint(magn);{store magnitude in highest byte, allowing more digits later}
    bp_rp:= 0;

  end;
  blockwrite(tof,buf2, SizeOf(hnskyhdr290_A7),Numwritten);
end;


function floattostr2(x: double):string;
begin
  str(x:0:1,result);
end;


procedure TMain_form.countstars1Click(Sender: TObject);
var
  bp_active_x10 : integer;
  file_name,line1: string;
begin
  nr_of_stars:=0;
  for bp_active_x10:=100 to 180 do
  begin
    file_name:=thepath+PathDelim+'Gaia'+PathDelim+'Gaia_DR3_BP_'+floattostr2(bp_active_x10/10)+'.csv';
    main_form.caption:=('Counting stars: ');
    main_form.thefile1.caption:=file_name;
    application.processmessages;
    if fileexists(file_name) then
    begin
      assignfile(ftext,file_name); {load  file in Tstrings}
      reset(ftext);
      repeat
       readln(ftext,line1);
       nr_of_stars:=nr_of_stars+1;
      until (eof(ftext));
      closefile(ftext);
      nr_of_stars:=nr_of_stars-1;{remove comment}
    end
    else
    application.MessageBox(pchar('Does not exist :'+file_name), 'Error', MB_OK);
  end;

  file_name:=thepath+PathDelim+'Gaia'+PathDelim+'Gaia_DR3_BP_0.0-09.95.csv';
  assignfile(ftext,file_name); {load  file in Tstrings}
  reset(ftext);
  repeat
   readln(ftext,line1);
   nr_of_stars:=nr_of_stars+1;
  until (eof(ftext));
  closefile(ftext);
  nr_of_stars:=nr_of_stars-1;{remove comment}


  file_name:=thepath+PathDelim+'Gaia'+PathDelim+'Gaia_DR3_missing_BP_G_0.0-17.3.csv';   {will contain stars in GP range 0 ..17.35 equivalent to V 0.4 ..16.75 and BP 0.5 ..17.85.}
  assignfile(ftext,file_name); {load  file in Tstrings}
  reset(ftext);
  repeat
   readln(ftext,line1);
   nr_of_stars:=nr_of_stars+1;
  until (eof(ftext));
  closefile(ftext);
  nr_of_stars:=nr_of_stars-1;{remove comment}



  file_name:=thepath+PathDelim+'Gaia'+PathDelim+'Gaia_DR3_missing_BP_G_17.4-17.7.csv';    {will contain stars in GP range 17.35 ..17.75 equivalent to V 17.65 ..18.05 and BP 17.85 ..18.25/  So range required 17.65 ..18.25}
  assignfile(ftext,file_name); {load  file in Tstrings}
  reset(ftext);
  repeat
   readln(ftext,line1);
   nr_of_stars:=nr_of_stars+1;
  until (eof(ftext));
  closefile(ftext);
  nr_of_stars:=nr_of_stars-1;{remove comment}


  messagebox(main_form.handle,pchar('Ready.   Stars counted:'+ inttostr(nr_of_stars)),pchar('Ready'),MB_ICONINFORMATION);
end;

procedure TMain_form.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  keypressed:=key
end;


procedure TMain_form.bp_magnitude1Change(Sender: TObject);
begin
  if bp_magnitude1.checked then Main_form.abbreviation1.text:=StringReplace(Main_form.abbreviation1.text, 'V', 'G',[rfReplaceAll])
  else
  Main_form.abbreviation1.text:=StringReplace(Main_form.abbreviation1.text, 'G', 'V',[rfReplaceAll]);

end;

procedure TMain_form.filter_star_density1Change(Sender: TObject);
begin
  step1_magnitude1.enabled:=filter_star_density1.checked=false;
end;



function extract_tycho(regel:string; epoch2:double; out ra1,dec1,  magB,magV, b_r : double): boolean;
var
   info  : string;
   error1,error2, error_total,komma1,errorBT,errorVT,oldkomma,tyc1,tyc2,tyc3,hip1,errorhip:integer;
   mag1R,magVT, magBT,pmRA, pmDEC  : double;

begin
  result:=false;
  error_total:=0;

  komma1:=posex(',',regel,1);
  info:=copy(regel,1,komma1-1);{ra}
  val(info,ra1,error1); error_total:=error_total+error1;
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{dec}
  val(info,dec1,error1); error_total:=error_total+error1;
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{tyc1}
  val(info,tyc1,error1);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{tyc2}
  val(info,tyc2,error1);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{tyc3}
  val(info,tyc3,error1);
  oldkomma:=komma1+1;


  //     IF pos(',17,1398,',regel)>0 then
  //      beep;

  //_RAJ2000,_DEJ2000,TYC1,TYC2,TYC3,pmRA,pmDE,BTmag,VTmag,HIP,RA(ICRS),DE(ICRS)
  //deg,deg, , , ,mas/yr,mas/yr,mag,mag, ,deg,deg

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{pmRA}
  val(info,pmRA,error1);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma); {pmdec}
  val(info,pmDEC,error1);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma);{magBT}
  if pos(' ',info)>0  then errorBT:=1 else  val(info,magBT,errorBT);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma); {magVT}
  if pos(' ',info)>0 then errorVT:=1 else val(info,magVT,errorVT);
  oldkomma:=komma1+1;

  komma1:=posex(',',regel,oldkomma);
  info:=copy(regel,oldkomma,komma1-oldkomma); {hip}
  val(info,hip1,errorhip);
  oldkomma:=komma1+1;


  b_r:=-128; {unknown Bp-Rp value for Tycho stars, will be calculated later if within range}

  if ((errorBT=0) and (errorVT=0)) then
  begin
    magB := magVt -0.006739+0.2758*(magBt-magVt)-0.135*sqr(magBt-magVt)  {Gaia BPg := Vt -0.006739+0.2758*(Bt-Vt)-0.135*(Bt-Vt)^2+0.01098(Bt-Vt)^3}
                     +0.01098*sqr(magBt-magVt)*(magBt-magVt);

    magV:=magVT - 0.090 * (magBT - magVT);  {V = VT - 0.090 * (BT - VT)}
    if ((magBT-magVT>=-0.2) and (magBT-magVt<=2.0)) then {valid conversion range}
    begin
       b_r:=round(10*(0.03147 +1.456*(magBt-magVt) -0.6043*sqr(magBt-magVt)+0.1750*sqr(magBt-magVt)*(magBt-magVt) )); {Gaia GBP-GRP formula}
    end;

    if  ((tyc1=  129	) and (tyc2=	1873	) and (tyc3=	1	)) then begin b_r:=round(10*2.1);end;	;{M0, Betelgeuze}
    if  ((tyc1= 6803	) and (tyc2=	2158	) and (tyc3=	1	)) then begin b_r:=round(10*2.1);end;	;{M0, Antares}

    if  ((tyc1= 7689	) and (tyc2=	2617	) and (tyc3=	1	)) then begin b_r:=round(10*1.5);end;	;{K5}
    if  ((tyc1= 7663	) and (tyc2=	4093	) and (tyc3=	1	)) then begin b_r:=round(10*-0.3);end;	;{03}
    if  ((tyc1= 1991	) and (tyc2=	1895	) and (tyc3=	1	)) then begin b_r:=round(10*1.5);end;	;{K0}
    if  ((tyc1= 1423	) and (tyc2=	1349	) and (tyc3=	2	)) then begin b_r:=round(10*1.5);end;	;{K0}
  end
  else
  if errorBT=0 then
  begin
    magB:=MagBT;{no VT magnitude, use BT instead 25 stars only}
    magV:=MagBT;
  end
  else
  if errorVT=0 then {no BT magnitude use VT}
  begin
    MagB:=MagVT;
    if  ((tyc1=	5949	) and (tyc2=	2777	) and (tyc3=	1	)) then begin magB:=-1.46;{A1} b_r:=round(10*0.3);end;	;{sirus, simbad reports for tyc an other magnitude then hip ??}
    if  ((tyc1=	3105	) and (tyc2=	2070	) and (tyc3=	1	)) then begin magB:=0.03;{A0}  b_r:=round(10*0.3);end;
    if  ((tyc1=	9007	) and (tyc2=	5849	) and (tyc3=	1	)) then begin magB:=0.01;{G2}  b_r:=round(10*0.9);end;
    if  ((tyc1=	1472	) and (tyc2=	1436	) and (tyc3=	1	)) then begin magB:=-0.05;{K1} b_r:=round(10*1.5);end;
    if  ((tyc1=	3358	) and (tyc2=	3141	) and (tyc3=	1	)) then begin magB:=0.08;{G3}  b_r:=round(10*0.9);end;
    if  ((tyc1=	187	) and (tyc2=	2184	) and (tyc3=	1	)) then begin magB:=0.37;{F5}  b_r:=round(10*0.7);end;
    if  ((tyc1=	9005	) and (tyc2=	3919	) and (tyc3=	1	)) then begin magB:=0.6	;{B1}  b_r:=round(10*0.0);end;
    if  ((tyc1=	9007	) and (tyc2=	5848	) and (tyc3=	1	)) then begin magB:=1.33;{K1}  b_r:=round(10*1.5);end; {alpha Centauri 2}
    if  ((tyc1=	2457	) and (tyc2=	2407	) and (tyc3=	1	)) then begin magB:=1.93;{A1}  b_r:=round(10*0.3);end;{castor}
    if  ((tyc1=	8573	) and (tyc2=	3571	) and (tyc3=	1	)) then begin magB:=1.99;{A0}  b_r:=round(10*0.3);end;
    if  ((tyc1=	4146	) and (tyc2=	1274	) and (tyc3=	1	)) then begin magB:=2;{G9/k0}  b_r:=round(10*1.2);end; {dubhe}
    if  ((tyc1=	1329	) and (tyc2=	1746	) and (tyc3=	1	)) then begin magB:=1.92;{A1}  b_r:=round(10*0.3);end; {alhena}
    if  ((tyc1=	8579	) and (tyc2=	2692	) and (tyc3=	1	)) then begin magB:=2.01;{K3}  b_r:=round(10*1.5);end; {avior}
    if  ((tyc1=	4766	) and (tyc2=	2445	) and (tyc3=	1	)) then begin magB:=2.41;{B0}  b_r:=round(10*0.0);end;
    if  ((tyc1=	2457	) and (tyc2=	2407	) and (tyc3=	2	)) then begin magB:=2.97;end;
    if  ((tyc1=	1472	) and (tyc2=	1436	) and (tyc3=	2	)) then begin magB:=4.05;{}end;
    if  ((tyc1=	1423	) and (tyc2=	1349	) and (tyc3=	2	)) then begin magB:=4.225;{o9} end;
    if  ((tyc1=	4766	) and (tyc2=	2445	) and (tyc3=	2	)) then begin magB:=3.76;{} end; {some of these hip numbers are double used !!, so use tyc}
    if  ((tyc1=	9005	) and (tyc2=	3919	) and (tyc3=	2	)) then begin magB:=4.58;end; {some of these hip numbers are double used !!, so use tyc}
    if  ((tyc1=	8579	) and (tyc2=	2692	) and (tyc3=	2	)) then begin magB:=3.85;end; {some of these hip numbers are double used !!, so use tyc}
    if  ((tyc1=	4146	) and (tyc2=	1274	) and (tyc3=	2	)) then begin magB:=4.91;end; {some of these hip numbers are double used !!, so use tyc}
    if  ((tyc1=	7892	) and (tyc2=	7679	) and (tyc3=	2	)) then begin magB:=6.22;end; {some of these hip numbers are double used !!, so use tyc}
    if  ((tyc1=	8573	) and (tyc2=	3571	) and (tyc3=	2	)) then begin magB:=5.57;end; {some of these hip numbers are double used !!, so use tyc}

    MagV:=MagB;//avoid zeros

  end
  else
  begin
    mag1R:=9999;
    error_total:=999;
  end;

  magB:=round(magB*10);
  magV:=round(magV*10);

  if error_total<>0 then result:=false {ignore this star entry, try next }
  else
  begin
    DEC1 {(epoch T)} := (DEC1 + pmDEC * (epoch2 - 1991.25)/(3600*1000))*  (pi/180);  {DEC first}
    RA1  {(epoch T)} := (RA1  + pmRA / cos(dec1)*(epoch2 - 1991.25)/(3600*1000))*(pi/180);
    result:=true;
  end;
end;


function gaia_extract_source({slist:Tstringlist} regel : string;epoch2: double; out ra,dec,magG,magBP,magRP: double) : boolean;
var
 s  : string;
   error1, error_total,komma,oldkomma,i,x :integer;
   pmra,pmdec : double;

begin
//          0            1                2          3        4    5       6     7          8      9             10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           67
//   solution_id,designation,source_id,random_index,ref_epoch,ra,ra_error,dec,dec_error,parallax,parallax_error,parallax_over_error,pm,pmra,pmra_error,pmdec,pmdec_error,ra_dec_corr,ra_parallax_corr,ra_pmra_corr,ra_pmdec_corr,dec_parallax_corr,dec_pmra_corr,dec_pmdec_corr,parallax_pmra_corr,parallax_pmdec_corr,pmra_pmdec_corr,astrometric_n_obs_al,astrometric_n_obs_ac,astrometric_n_good_obs_al,astrometric_n_bad_obs_al,astrometric_gof_al,astrometric_chi2_al,astrometric_excess_noise,astrometric_excess_noise_sig,astrometric_params_solved,astrometric_primary_flag,nu_eff_used_in_astrometry,pseudocolour,pseudocolour_error,ra_pseudocolour_corr,dec_pseudocolour_corr,parallax_pseudocolour_corr,pmra_pseudocolour_corr,pmdec_pseudocolour_corr,astrometric_matched_transits,visibility_periods_used,astrometric_sigma5d_max,matched_transits,new_matched_transits,matched_transits_removed,ipd_gof_harmonic_amplitude,ipd_gof_harmonic_phase,ipd_frac_multi_peak,ipd_frac_odd_win,ruwe,scan_direction_strength_k1,scan_direction_strength_k2,scan_direction_strength_k3,scan_direction_strength_k4,scan_direction_mean_k1,scan_direction_mean_k2,scan_direction_mean_k3,scan_direction_mean_k4,duplicated_source,phot_g_n_obs,phot_g_mean_flux,phot_g_mean_flux_error,phot_g_mean_flux_over_error,phot_g_mean_mag,phot_bp_n_obs,phot_bp_mean_flux,phot_bp_mean_flux_error,phot_bp_mean_flux_over_error,phot_bp_mean_mag,phot_rp_n_obs,phot_rp_mean_flux,phot_rp_mean_flux_error,phot_rp_mean_flux_over_error,phot_rp_mean_mag,phot_bp_rp_excess_factor,phot_bp_n_contaminated_transits,phot_bp_n_blended_transits,phot_rp_n_contaminated_transits,phot_rp_n_blended_transits,phot_proc_mode,bp_rp,bp_g,g_rp,radial_velocity,radial_velocity_error,rv_method_used,rv_nb_transits,rv_nb_deblended_transits,rv_visibility_periods_used,rv_expected_sig_to_noise,rv_renormalised_gof,rv_chisq_pvalue,rv_time_duration,rv_amplitude_robust,rv_template_teff,rv_template_logg,rv_template_fe_h,rv_atm_param_origin,vbroad,vbroad_error,vbroad_nb_transits,grvs_mag,grvs_mag_error,grvs_mag_nb_transits,rvs_spec_sig_to_noise,phot_variable_flag,l,b,ecl_lon,ecl_lat,in_qso_candidates,in_galaxy_candidates,non_single_star,has_xp_continuous,has_xp_sampled,has_rvs,has_epoch_photometry,has_epoch_rv,has_mcmc_gspphot,has_mcmc_msc,in_andromeda_survey,classprob_dsc_combmod_quasar,classprob_dsc_combmod_galaxy,classprob_dsc_combmod_star,teff_gspphot,teff_gspphot_lower,teff_gspphot_upper,logg_gspphot,logg_gspphot_lower,logg_gspphot_upper,mh_gspphot,mh_gspphot_lower,mh_gspphot_upper,distance_gspphot,distance_gspphot_lower,distance_gspphot_upper,azero_gspphot,azero_gspphot_lower,azero_gspphot_upper,ag_gspphot,ag_gspphot_lower,ag_gspphot_upper,ebpminrp_gspphot,ebpminrp_gspphot_lower,ebpminrp_gspphot_upper,libname_gspphot
//   1636148068921376768,"Gaia DR3 4295806720",4295806720,545300884,2016.0,44.99615537864534,0.10161827,0.005615226341865997,0.10133387,0.3543305595550248,0.12266381,2.8886316,12.616485,11.93835156938502,0.13794228,-4.0806193394130865,0.13316983,0.12293493,0.13202813,-0.08891027,0.022551458,-0.3653421,-0.03690377,-0.24483804,0.06301233,0.13570854,0.3343367,184,0,183,1,2.6720488,242.20697,0.3806193,2.0765078,31,"False",1.5089388,null,null,null,null,null,null,null,22,16,0.21780181,22,9,0,0.01759732,90.23934,0,0,1.1429516,0.30795118,0.19765861,0.43010107,0.8420776,-87.75478,-30.69455,-46.20191,30.174356,"False",182,1653.39471645947,2.0757642,796.5234,17.641426,18,800.4295459066461,12.601409,63.51905,18.080235,20,1187.588003883822,15.823832,75.0506,17.061232,1.2023853,0,0,0,2,0,1.0190029,0.43880844,0.5801945,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,"NOT_AVAILABLE",176.95107618038946,-48.901520870941965,42.53372584780011,-16.32957416215404,"False","False",0,"True","False","False","False","False","True","True","False",3.0354892E-11,7.0457914E-13,0.9999876,5052.976,5040.658,5066.6284,4.7793,4.7613,4.7924,-1.4592,-1.5732,-1.3439,1497.0547,1466.7346,1536.1321,0.0064,0.0016,0.0176,0.0052,0.0013,0.0143,0.0028,7.0E-4,0.0078,"MARCS"
//   1636148068921376768,"Gaia DR3 34361129088",34361129088,894504938,2016.0,45.00432028915398,0.09731972,0.021047763781174733,0.101752974,3.235017271512856,0.12045025,26.857704,35.230515,29.518344127131527,0.13369285,19.231654938806578,0.13392176,0.16325329,6.428645E-4,-0.073663116,-0.012016551,-0.40389284,-0.10152152,-0.31593448,0.14065048,0.23142646,0.38175407,172,0,171,1,1.081467,194.59933,0.26741344,1.0328022,31,"False",1.285487,null,null,null,null,null,null,null,20,15,0.22053866,20,9,0,0.05737302,84.542816,0,0,1.0578898,0.28431648,0.18242157,0.4234895,0.8483561,-101.856606,-31.586445,-44.381237,29.909302,"False",170,1763.191386728999,2.1212356,831.2096,17.571619,18,389.99713585371074,9.491409,41.089485,18.86089,19,2178.214858374066,15.074686,144.49487,16.402643,1.4565701,0,2,0,1,0,2.4582462,1.2892704,1.1689758,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,"NOT_AVAILABLE",176.94278852482034,-48.88493355232444,42.54657309907107,-16.317212317623884,"False","False",0,"False","False","False","False","False","True","True","False",1.0820195E-13,5.682676E-13,0.9993886,3478.5408,3461.1475,3497.5784,4.7,4.6405,4.7734,-0.6143,-0.7064,-0.4964,302.2347,292.5325,312.6373,0.7643,0.7292,0.7975,0.505,0.4815,0.5273,0.3096,0.2956,0.3228,"MARCS"
//   1636148068921376768,"Gaia DR3 38655544960",38655544960,1757259052,2016.0,45.004978371745516,0.017885398,0.019879675701858644,0.01877158,3.1391701154499523,0.022347411,140.47131,35.30821,29.686339048921702,0.023771733,19.115199913956804,0.023830384,0.1152631,0.07323115,-0.10691941,-0.03021361,-0.4488658,-0.15551351,-0.37927917,0.18184616,0.26367012,0.35528076,183,0,182,1,0.26434276,181.43846,0.0,0.0,31,"False",1.4550159,null,null,null,null,null,null,null,21,15,0.03929549,21,9,0,0.024301996,98.629005,0,0,1.012191,0.30656147,0.20578752,0.45299426,0.84656596,-96.31889,-34.497215,-44.82578,30.34742,"False",180,42030.60043942405,11.392837,3689.213,14.128453,20,17955.47937733753,26.03932,689.55255,14.70305,19,34263.48754002838,36.75135,932.30554,13.410816,1.2424035,0,3,0,2,0,1.2922335,0.5745964,0.71763706,41.187176,3.1130338,2,10,1,8,7.034563,null,null,749.9199,null,4500.0,3.0,-0.25,111,null,null,null,13.068616,0.049816404,10,null,"NOT_AVAILABLE",176.94476211452783,-48.88527012426483,42.546872019115916,-16.318521975182243,"False","False",0,"True","True","False","False","False","True","True","False",1.03982646E-13,5.193881E-13,0.9998059,4708.7944,4659.062,4723.2773,4.5588,4.5261,4.5654,-0.087,-0.1218,-0.0681,332.8322,330.4709,347.1729,0.2345,0.184,0.2516,0.182,0.1425,0.1955,0.0961,0.0752,0.1032,"MARCS"

//   first star values
//   ra=44.99615537864534
//   dec=0.005615226341865997
//   pmRA=11.93835156938502
//   pmDec=-4.0806193394130865
//   g=17.641426
//   bp=18.080235
//   rp=17.061232

   //fast decode. Work faster then using  tstringlist.commatext:=regel;
   error_total:=0;
   oldkomma:=1;
   for i:=0 to 79 do
   begin
    komma:=posex(',',regel,oldkomma);
    if i=5 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{ra}
      val(s,ra,error1);
      error_total:= error_total+error1; //ra should be there
    end
    else
    if i=7 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{dec}
      val(s,dec,error1);
      error_total:= error_total+error1;//dec should be there
    end
    else
    if i=13 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{pmra}
      val(s,pmra,error1);
    end
    else
    if i=15 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{pmdec}
      val(s,pmdec,error1);
    end
    else

    if i=69 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{G}
      val(s,magG,error1);
      error_total:= error_total+error1; //G should be there
    end
    else
    if i=74 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{BP}
      val(s,magBP,error1);
    end
    else
    if i=79 then
    begin
      s:=copy(regel,oldkomma,komma-oldkomma);{RP}
      val(s,magRP,error1);
    end;
    oldkomma:=komma+1;
  end;

  x:=length(regel);

  {GAIA DR3 2016 epoch !!!!!!}
   dec {(epoch T)} := (dec + pmDEC * (epoch2 - 2016.0)/(3600*1000))*  (pi/180);  {DEC first}
   ra  {(epoch T)} := (ra  + pmRA / cos(dec)*(epoch2 - 2016.0)/(3600*1000))*(pi/180);

//   Stars with high proper motion, extracted from http://simbad.cds.unistra.fr/simbad/sim-fid

//   ppm 21580, magnitude 4.680, Gaia DR3 2261614264931057664
//   ---------
//   Coordinates(ICRS,ep=J2016,eq=2000): 293.0975946910581  +69.6534513174981
//   Coordinates(ICRS,ep=J2025,eq=2000): 293.1018867018636  +69.6491062087362

//   Coordinates(ICRS,ep=J2016,eq=2000): 19 32 23.4227258539  +69 39 12.424742993
//   Coordinates(ICRS,ep=J2025,eq=2000): 19 32 24.4528084473  +69 38 56.782351450



//   ppm 25718, magnitude 3.44, Gaia DR3 425040000962559616
//   ---------
//   Coordinates(ICRS,ep=J2016,eq=2000): 012.2852265598358  +57.8127275470797
//   Coordinates(ICRS,ep=J2025,eq=2000): 012.2902878234048  +57.8113493373821

//   Coordinates(ICRS,ep=J2016,eq=2000): 00 49 08.4543743606  +57 48 45.819169487
//   Coordinates(ICRS,ep=J2025,eq=2000): 00 49 09.6690776172  +57 48 40.857614576


   result:=(error_total=0);
end;



procedure load_source_stars(filen : string; out source_stars : ansichar_array); //read whole file at once in array
var
  Fstream: TFileStream;
  len:Integer;
const
  leng=1024000000;//1000 mbyte
begin
  setlength(source_stars,leng);
  Fstream := TFileStream.Create(filen , fmOpenRead);
  try
    Fstream.read(source_stars[0],leng);
    len:=Fstream.position;
    setlength(source_stars,len);
  finally
    FStream.Free;
  end;
end;

procedure TMain_form.start_sorting_source1Click(Sender: TObject);
var
  i,count,position,oldposition,err:integer;
  ff,  file_opened,to_open,line,ras,decs,magGs,magBPs,magRPs,pmras,pmdecs,f,p,gaia_path : string;
  tof : textfile;
  ra,dec,magG,magBP,magRP,epoch2,b_r : double;
  success : boolean;
  searchResult : TSearchRec;
  source_stars : ansichar_array;
  Bufout       : Array[0..2000] of byte;


  procedure readline;  inline;
  var
    len : integer;
  begin
    len:=length(source_stars);
    repeat
      inc(position)
    until ((position>=len) or (source_stars[position]=ansichar($0A)) );//find end of line in array
    if position<>oldposition then
      SetString(line, Pansichar(@source_stars[oldposition]), position-oldposition){convert part of array to string}
    else
      line:='';
    oldposition:=position+1;
  end;

begin
  epoch2:=epochupdown1.position;
  for i:=-150 to 2300 do
  begin
    starcount[i]:=0;{keep record in steps of 0.01 magnitude}
    starcount2[i]:=0;{keep record in steps of 0.01 magnitude}
    starcount3[i]:=0;{straylight}
  end;

  main_form.status1.caption:='Running';
  nr_of_stars:=0;
  nr_of_skipped:=0;
  nr_of_straylight:=0;{stars effected by straylight}
//  stars_without_bp:=0;{stars without bp magn}

  gaia_path:=gaia_path2.text;//to string for speed

  //delete old .csv1 files
  p:=gaia_path+'\*.csv1';
  if sysutils.FindFirst(p, faAnyFile, searchResult) = 0 then
  begin
    try
    repeat
      f:=gaia_path+PathDelim+searchResult.Name;
      sysutils.deletefile(f);
    until FindNext(searchResult) <> 0;
    finally
      sysutils.FindClose(searchResult);
    end;
  end;

  nr_of_stars:=0;
  writetextfile(true,'result.txt','start');{write result to file}

  //read Gaia source
  file_opened:=''; {indicates of file is open}

  for i:=0 to length(dr3files)-1 do
  begin
    ff:=dr3files[i];

    active_file1.caption:=ff+',  '+inttostr(i);
    ExecuteAndWait('"'+'C:\Program Files\7-Zip\7zG.exe" x -aoa "'+gaia_path+PathDelim+ff+'.gz' {filename3}+'"',true);{execute command and wait}
    application.processmessages;

    if fileexists(ff) then
    begin
      load_source_stars(ff, source_stars ); //read whole file at once in array
      count:=0;
      oldposition:=0;
      position:=0;
      repeat //skip comments
        readline;
      until ((length(line)<3) or (line[1]<>'#'));
      repeat
        readline;
        success:=gaia_extract_source(line,epoch2,{var} ra,dec,magG,magBP,magRP);
        if success then
        begin
          inc(count);
          if frac(count/4000)=0 then
          begin
            stars_done2.Caption:=inttostr(count);
            application.processmessages;
            if keypressed=vk_F4 then begin closefile(tof); source_stars:=nil; halt; end;;
            if keypressed=vk_F7  then
            begin
              repeat
                main_form.status1.caption:='Paused';
                if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
                Application.ProcessMessages; {allow application  to update form1 with above messages}
                if blink then blink:=false else  blink:=true;{blinker}
                sleep(500);
                Application.ProcessMessages; {allow application  to update form1 with above messages}
              until keypressed=vk_F8;
              main_form.status1.caption:='Running';
            end;
          end;

          to_open:=gaia_path+'\area_'+name290(ra,dec)+'.csv2';

          if file_opened<>to_open then {dump file not open yet}
          begin {other dump file required,  close and open other section}
            if file_opened<>'' then
               closefile(Tof);{close file already open}

            if fileexists(to_open) then
            begin
              assignfile(tof,to_open);{assign correct 290 file}
              append(tof);
            end
            else
            begin //new file
              assignfile(tof,to_open);{assign correct 290 file}
              rewrite(tof);//create file
            end;
            system.SetTextBuf(tof,Bufout);//create larger then 128 bytes buffer for a little more speed
          end;
          //   first star values, will be stored in file ....290, corrected epoch
          //   ra=44.99615537864534
          //   dec=0.005615226341865997
          //   pmRA=11.93835156938502
          //   pmDec=-4.0806193394130865
          //   mag=181
          str(ra:15:14,ras);//store in radians
          str(dec:15:14,decs);
          str(magG:8:6,magGs);
         str(magBP:8:6,magBPs);
          str(magRP:8:6,magRPs);
          writeln(tof,ras+','+decs+','+magGs+','+magBPs+','+magRPs);
          file_opened:=to_open;{remember file openened}
          inc(nr_of_stars);

        end;//success
      until length(line)<3;

      closefile(tof);
      file_opened:=''; {indicates of file is open}

       writetextfile(false,'result.txt',ff+' stars done:'+ inttostr(nr_of_stars)+',  file nr:'+inttostr(i));{write result to file}

    end
    else
    application.MessageBox(pchar('Does not exist :'+ff), 'Error', MB_OK);

    sysutils.DeleteFile(thepath+PathDelim+ff) ;//make space (in program directory)
  end; //loop

  writetextfile(false,'result.txt','Ready.   Stars done:'+ inttostr(nr_of_stars));{write result to file}

  source_stars:=nil;//free mem

  if ((powerdown_enabled.checked)and (nr_of_stars>100)) then
  {$ifdef mswindows}
  main_form.caption:= ShutMeDown
  {$else} {unix}
  fpSystem('/sbin/shutdown -P now')
  {$endif}
  else
  messagebox(main_form.handle,pchar('Ready.   Stars done:'+ inttostr(nr_of_stars)),pchar('Ready'),MB_ICONINFORMATION);
end;


procedure save_stars(filen : string; stars : starlist);
var
  Fstream: TFileStream;
  i,j:Integer;
  wid,len : integer;
begin
 begin
  wid:=length(stars);
  len:=length(stars[0]);
  Fstream := TFileStream.Create(FileN, fmCreate);
  try
    Fstream.Write(wid,SizeOf(wid));
    Fstream.Write(len,SizeOf(len));

    for i := 0 to wid-1 do
    begin
      for j := 0 to len-1 do
      begin
        Fstream.Write(stars[i,j],SizeOf(stars[i,j]));
      end;
    end;
  finally
    Fstream.Free;
  end;
  //ShowMessage('saved!');
 end;
end;


procedure load_stars(filen : string; out stars : starlist);
var
  Fstream: TFileStream;
  i,j:Integer;
  wid,len : integer;
begin
  Fstream := TFileStream.Create(filen , fmOpenRead);
  try
    Fstream.read(wid,SizeOf(wid));
    Fstream.read(len,SizeOf(len));
    setlength(stars,wid,len);
    for i := 0 to wid-1 do
    begin for j := 0 to len-1 do
         FStream.Read(stars[i,j], SizeOf(stars));
    end;
  finally
    FStream.Free;
  end;
end;



procedure TMain_form.convert_to_290_1Click(Sender: TObject);
var
  nr_of_errors                : longint;
  fname,name1,gaia_path,dstring : string;
  info1  : array[0..112] of ansichar;
  buf2: array[1..12] of byte;
  p6         : ^hnskyhdr290_A6;       { pointer to hnskyrecord }
  pA7        : ^hnskyhdr290_A7;	       { pointer to hnskyrecord }
  k,count,i,rastart,decstart, oldmag1,mag1,maxmagn  :  integer;
  density_filter : boolean;

begin
 if main_form.bp_magnitude1.checked then sort_type:=0
 else
 if main_form.v_magnitude2.checked then sort_type:=1
 else
 if main_form.V_magnitude_and_BR1.checked then sort_type:=2;

 if sort_type<>0 then typ:='V' else typ:='B';

 main_form.status1.caption:='Running';
 gaia_path:=gaia_path2.text;
 writetextfile(true,'result290'+typ+'.txt','Start');{write result to file}
 nr_of_errors:=0;

 density_filter:=filter_star_density1.Checked;
 maxmagn:=step1_maxmagnitude1.position;

 for k:=1 to 290 do {create,  reset output files}
 begin
   if keypressed=vk_F4 then begin closefile(tof); closefile(ftext); halt; end;;
   if keypressed=vk_F7  then
   begin
     repeat
       main_form.status1.caption:='Paused';
       if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
       if blink then blink:=false else  blink:=true;{blinker}
       sleep(500);
       Application.ProcessMessages; {allow application  to update form1 with above messages}
     until keypressed=vk_F8;
     main_form.status1.caption:='Running';
   end;

   fname:= 'area_' +filenames290[k]+'.bin1';
   label_filesort2.caption:=fname;
   application.processmessages;

   if  fileexists(gaia_path+PathDelim+fname)=false then
     //ShowMessage(fname+' does not exist!')
   else
   begin

     load_stars(gaia_path+PathDelim+fname,stars1);

      if density_filter then
      begin
        dstring:=inttostr(round(density1.position/100));
        if length(dstring)<2 then dstring:='0'+dstring;
        if sort_type=0 then leadname:='d'+dstring+'_' {d50_}
        else
        leadname:='v'+dstring+'_';{v50_}
      end
      else
      begin
        if sort_type=0 then leadname:='h'+copy(step1_magnitude1.Text,1,2)+'_' {h17_}
        else
        leadname:='v'+copy(step1_magnitude1.Text,1,2)+'_'; {v17_}
      end;


     {make header begin===========================================================}
     if density_filter=false then
     begin
       if sort_type=0 then strpcopy(info1,copy('GAIA DR3, stars up to BP magnitude '+ strtostr_divide10(step1_magnitude1.text) +', Epoch='+epoch1.text+'. Including 82 bright Tycho2 stars. Magnitude is BP                                               ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       if sort_type=1 then strpcopy(info1,copy('GAIA DR3, stars up to V magnitude '+ strtostr_divide10(step1_magnitude1.text) +', Epoch='+epoch1.text+'. Including 82 bright Tycho2 stars. Magnitude is V                                                  ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       if sort_type=2 then strpcopy(info1,copy('GAIA DR3, stars up to V magnitude '+ strtostr_divide10(step1_magnitude1.text) +', Epoch='+epoch1.text+'. 82 Tycho2 stars. Magnitude is V, Bp-Rp info included                                                  ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       begin
         messagebox(main_form.handle,pchar('Selection missing. Specify magnitude type'),pchar('Error'),MB_ICONERROR);
         exit;
       end;
     end
     else
     begin
       if sort_type=0 then strpcopy(info1,copy('GAIA DR3, density<='+edit_density1.text+' stars/sqr(degree), Epoch='+epoch1.text+'. Including 82 bright Tycho2 stars. Magnitude is BP                                               ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       if sort_type=1 then strpcopy(info1,copy('GAIA DR3, density<='+edit_density1.text+' stars/sqr(degree), Epoch='+epoch1.text+'. Including 82 bright Tycho2 stars. Magnitude is V                                                  ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       if sort_type=2 then strpcopy(info1,copy('GAIA DR3, density<='+edit_density1.text+' stars/sqr(degree), Epoch='+epoch1.text+'. 82 Tycho2 stars. Magnitude is V, Bp-Rp info included                                                  ',1,112)){do not  override  length of info1, otherwise error at the end of program}
       else
       begin
         messagebox(main_form.handle,pchar('Selection missing. Specify magnitude type'),pchar('Error'),MB_ICONERROR);
         exit;
       end;
     end;



     if main_form.V_magnitude_and_BR1.checked=false then info1[109]:=#$A6    {interim 6 byte record}
                                                    else info1[109]:=#$A7;  {interim A7, 7 byte record with B_R included}

     if density_filter=false then
       info1[108]:=ansichar(maxmagn);{store maximum magnitude limit, not used yet}



     name1:=leadname+filenames290[k];

     if ((k=1) and (FileExists(name1)=true)) then {some pre checks}
     begin
       if Application.MessageBox('Destination files exist, overwrite ?','Attention !',	MB_YESNO or MB_ICONEXCLAMATION) = IDNO then halt;
     end;

     assignfile(tof,name1);
     filemode:=2;{read/write}
     rewrite(tof,1);
     Blockwrite(tof,info1,110,Numwritten);{header is 110 bytes, was 111 bytes }
     if numwritten<>110 then
     begin
       messagebox(main_form.handle,pchar('ERROR !!! Can"t create file files. Close HNSKY'),pchar('Error'),MB_ICONERROR);
       exit;
     end;

     {make header end===========================================================}

     oldmag1:=-999;
     count:=0;

     if sort_type<=1 then //records with BP or V magnitude
     repeat
         ra1:=stars1[0,count];
         dec1:=stars1[1,count];
         mag1:=round(stars1[2,count]);

         begin {6 byte record}
           p6:= @buf2[1];			{ set pointer }
           with p6^ do
           begin
            {Right accension===========================================}

             rastart := round(((256*256*256)-1)*(limit_radialen(ra1))/(2*pi));
             if rastart>=$FFFFFF then rastart:=0; { $FFFFFF is used as marker and should never occur. This value equals 2*pi could happen sometimes due to rounding}
             {make 3 byte word:}
             ra7 := lo(word(rastart));
             ra8 := hi(word(rastart));
             ra9 := rastart shr 16;{make 3 byte word};

             {declination===========================================}
             decstart :=round(( ((256*256*128)-1)*(dec1)/(0.5*pi)));

             {make 3 byte integer:}
             dec7 := lo(word(decstart));
             dec8 := hi(word(decstart));
             dec9 := decstart shr 16 ;{make 3 byte integer, important decstart must be longint};

            {magnitude===========================================}
             if (((mag1/10)>25.4-2) or ((mag1/10)<-2.0)) then  inc(nr_of_errors)
             else
             begin
               {write special magnitude record if required}
               if mag1<>oldmag1 then
               begin
                 write_new_magnitude_recordA6(mag1);{write special header with magnitude}
                 oldmag1:=mag1;
               end;
               {end write special magnitude record if required}

               blockwrite(tof,buf2, SizeOf(hnskyhdr290_6),Numwritten);
               inc(nr_of_stars);
             end;
            {====write to 290 files end====}
           end;
         end;{6 byte records}
         inc(count);
     until (  (count>=length(stars1[0])) or
              ((density_filter=false) and (mag1>maxmagn)) )

     else
     repeat //sort_type=2, records with V magnitude and BP-RP difference
         ra1:=stars1[0,count];
         dec1:=stars1[1,count];
         mag1:=round(stars1[2,count]);// V magnitude
         b_r:=round(stars1[3,count]); // BP-RP

         begin {7 byte record}
           pA7:= @buf2[1];			{ set pointer }
           with pA7^ do
           begin
            {Right accension===========================================}
             rastart := round(((256*256*256)-1)*(limit_radialen(ra1))/(2*pi));
             if rastart>=$FFFFFF then rastart:=0; { $FFFFFF is used as marker and should never occur. This value equals 2*pi could happen sometimes due to rounding}
             {make 3 byte word:}
             ra7 := lo(word(rastart));
             ra8 := hi(word(rastart));
             ra9 := rastart shr 16;{make 3 byte word};

             {declination===========================================}
             decstart :=round(( ((256*256*128)-1)*(dec1)/(0.5*pi)));

             {make 3 byte integer:}
             dec7 := lo(word(decstart));
             dec8 := hi(word(decstart));
             dec9 := decstart shr 16 ;{make 3 byte integer, important decstart must be longint};
             Bp_Rp := b_r;
            {magnitude===========================================}
             if (((mag1/10)>25.4-2) or ((mag1/10)<-2.0)) then  inc(nr_of_errors)
             else
             begin
               {write special magnitude record if required}
               if mag1<>oldmag1 then
               begin
                 write_new_magnitude_recordA6(mag1);{write special header with magnitude}
                 oldmag1:=mag1;
               end;
               {end write special magnitude record if required}

               blockwrite(tof,buf2, SizeOf(hnskyhdr290_6),Numwritten);
               inc(nr_of_stars);
             end;
            {====write to 290 files end====}
           end;
         end;{6 byte records}
        inc(count);
      until (  (count>=length(stars1[0])) or
               ((density_filter=false) and (mag1>maxmagn)) );


     closefile(tof);

     writetextfile(false,'result290'+typ+'.txt','Ready.   Stars done:'+ inttostr(nr_of_stars));{write result to file}

    end;//file exist
  end;
  label_filesort2.caption:='Ready';

   if ((powerdown_enabled.checked)and (nr_of_stars>100)) then
   {$ifdef mswindows}
   main_form.caption:= ShutMeDown
   {$else} {unix}
   fpSystem('/sbin/shutdown -P now')
   {$endif}
   else
   begin
     messagebox(main_form.handle,pchar('Ready.   Stars done: '+ inttostr(nr_of_stars)),pchar('Ready'),MB_ICONINFORMATION);
     main_form.status1.caption:='Finished';
   end;

end;


procedure sort_on_magnitude(stars_in : starlist; out stars_out : starlist);
var
  i,j,count,count2  : integer;
begin
  count:=length(stars_in[0]);

  setlength(stars2,4,count);

  //sort on magnitude
  count2:=0;

  for i:=-15 to 240 do //go through all magnitudes -1.5 to 24, steps of 0.1 magnitude
  begin
    for j:=0 to count-1 do
    begin

      if stars1[2,j]=i then //correct magnitude?
      begin
        stars2[0,count2]:=stars1[0,j];
        stars2[1,count2]:=stars1[1,j];
        stars2[2,count2]:=stars1[2,j];
        stars2[3,count2]:=stars1[3,j];
        inc(count2);


        if frac(count2/4000)=0 then
        begin
          application.processmessages;

          if keypressed=vk_F4 then begin closefile(tof); closefile(ftext); halt; end;;
          if keypressed=vk_F7  then
          begin
            repeat
              main_form.status1.caption:='Paused';
              if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
              if blink then blink:=false else  blink:=true;{blinker}
              sleep(500);
              Application.ProcessMessages; {allow application  to update form1 with above messages}
            until keypressed=vk_F8;
            main_form.status1.caption:='Running';
          end;
        end;
      end;
    end;
  end;
  setlength(stars2,4,count2); //reduce for case stars are outside magnitude range
end;


procedure  add_tycho(area,epoch2:integer; var stars: starlist; var count: integer);
var
  area_tycho: integer;
  tychofile,line,a,b: string;
  success: boolean;
  ra,dec,magB,magV,b_r : double;
  dfac : integer;
begin
  //read bright tycho stars
  tychofile:=thepath+PathDelim+PathDelim+main_form.gaia_missing_stars1.text;
  if fileexists(tychofile)=false then
  begin
    application.MessageBox(pchar('Does not exist :'+main_form.gaia_missing_stars1.text), 'Error', MB_OK) ;
    exit;
  end
  else

  assignfile(ftext,tychofile);
  reset(ftext);
  count:=0;
  readln(ftext,line); //skip comments
  repeat
    readln(ftext,line);
    if length(line)>2 then
    begin
      success:=extract_tycho(line, epoch2, {var} ra,dec, magB,magV, b_r);

      if success then
      begin
        //a:=filenames290(area);
       // b:=name290(ra,dec);
        if filenames290[area]=name290(ra,dec) then
        begin
          stars1[0,count]:=ra;
          stars1[1,count]:=dec;
          if sort_type=0 then
             stars1[2,count]:=magB
          else
            stars1[2,count]:=magV;
          //if sort_type=2 then
          //  stars1[3,count]:=b_r;//blue min red
          inc(count);
        end;
      end;
    end;
  until eof(ftext);
  closefile(ftext);
//  writetextfile(false,'result.txt',' Tycho added, stars done:'+ inttostr(nr_of_stars));//write result to file

end;


procedure TMain_form.sort_on_magnitude1Click(Sender: TObject);
var
   gaia_path,s,regel,fname :string;
   error1,error_total,count,count2,komma1,komma2,komma3,komma4,i,j,k,m,small_counter,position,epoch2,x,dfac : integer;
   ra,dec,magG,magBP,magRP,b_r,ra_min,ra_max,dec_min,dec_max,density,surface,min_density,max_density,actual_density,total_surface, Gflux,BPflux,RPflux,c,r: double;
   straylight : boolean;
begin

  if main_form.bp_magnitude1.checked then sort_type:=0
  else
  if main_form.v_magnitude2.checked then sort_type:=1
  else
  if main_form.V_magnitude_and_BR1.checked then sort_type:=2;

  if sort_type<>0 then typ:='V' else typ:='B';

  main_form.status1.caption:='Running';

  gaia_path:=gaia_path2.text;//to string for speed
  epoch2:=epochupdown1.position;
  for k:=1 to 290 do {create,  reset output files}
  begin
    count:=0;
    setlength(stars1,4,5000000);//ra,dec,bp or V magn, b_r (BP-RP)


    add_tycho(k {area},epoch2,{var} stars1, count); //add bright Tycho files

    fname:= 'area_' +filenames290[k]+'.csv2';
    label_filesort1.caption:=inttostr(k)+',  '+fname;
    application.processmessages;

    if  fileexists(gaia_path+PathDelim+fname)=false then
     //ShowMessage(fname+' does not exist!')
    else
    begin
      assignfile(ftext,gaia_path+PathDelim+fname);
      reset(ftext);
      repeat
        readln(ftext,regel);
        error_total:=0;

        komma1:=pos(',',regel);
        s:=copy(regel,1,komma1-1);{ra}
        val(s,ra,error1);
        error_total:= error_total+error1;

        komma2:=posex(',',regel,komma1+1);
        s:=copy(regel,komma1+1,komma2-komma1-1);{dec}
        val(s,dec,error1);
        error_total:= error_total+error1;

        komma3:=posex(',',regel,komma2+1);
        s:=copy(regel,komma2+1,komma3-komma2-1);{magG}
        val(s,magG,error1);
        error_total:= error_total+error1;

        komma4:=posex(',',regel,komma3+1);
        s:=copy(regel,komma3+1,komma4-komma3-1);{magBP}
        val(s,magBP,error1);
        error_total:= error_total+error1;

        s:=copy(regel,komma4+1,10);{magRP}
        val(s,magRP,error1);
        error_total:= error_total+error1;

        if error_total=0 then
        begin
        //##########################################


              {quality check by flux ratio}
              //SELECT gaia_source.ra,gaia_source.dec, gaia_source.pmra, gaia_source.pmdec, gaia_source.phot_g_mean_mag, gaia_source.phot_bp_mean_mag, gaia_source.phot_rp_mean_mag, phot_g_mean_flux, phot_bp_mean_flux, phot_rp_mean_flux
              //FROM gaiaedr3.gaia_source
              //WHERE (gaiaedr3.gaia_source.phot_bp_mean_mag>=12.7 AND gaiaedr3.gaia_source.phot_bp_mean_mag<12.8)
              //
              //C:=(BPflux +RPflux)/Gflux  is normally a little above 1 so about 1.15.. So chapter 6 "Gaia Early Data Release 3 Photometric content and validation"
              //if flux is calculated from the magnitudes it is a little above 2}

              //De flux kan ik ook terugrekenen van de magnitude. Dat is gemakkelijker want de flux heb ik nog niet in de database.
              //Het blijkt als je de flux uitrekend dan is de ratio (BPflux+RPflux)/Gflux meestal iets boven circa 2. Maar loopt voor de
              //slechte waarden op tot wel 27. Het idee is nu wanneer deze ratio groter dan 4 en G>BP de G magnitude te gebruiken, anders BP.
              //De conditie G>BP is nodig voor hele rode sterren om te voorkomen dat je een infrarood magnitude neemt.
              straylight:=false;
              b_r:=-128;{no info}

              if ((magBP<>0) and (magRP<>0)) then {do quality check}
              begin
                Gflux:=power(10,(20-magG)/2.5);
                BPflux:=power(10,(20-magBP)/2.5);
                RPflux:=power(10,(20-magRP)/2.5);
                c:=(BPflux+RPflux)/Gflux;
                if ((c>4) and (magG>magBP)) then {straylight do not rely on BP and RP. C is normally a little above 2}
                begin
                  magBP:=0;
                  magRP:=0;
                  straylight:=true;
                end
                else
                begin
                  if abs(magBP-magRP)<=12.7 then
                  b_r:=round((magBP-magRP)*10);//blue red difference
                end;

              end;


              if sort_type=0 then
              begin
                if magBP<>0 {BP magn data available} then
                  mag1:=round(magBP*10)
                else
                  mag1:=round((magG+G_to_BP_correctie)*10); {add half magnitude, average for mag 15. 0.51 for mag 15, 0.41 for mag 10.8 }
              end
              else
              begin {V magnitude}
                if ((magBP<>0) and (magRP<>0)) then
                  begin
                    if ((magBP-magRP>=-0.5) and (magBP-magRP<=5.0)) then {formula valid edr3}
                    mag1:=round((magG + 0.02704 - 0.0124*(magBP-magRP) + 0.2156*sqr(magBP-magRP) -0.01426*sqr(magBP-magRP)*(magBP-magRP) )*10)  {edr3}
                    else {1% of the stars}
                    mag1:=round((magBP-0.18)*10);{rough estimate -0.187 for mag 15}
                  end
                  else
                  mag1:=round((magG+G_to_V_correctie)*10); {rough estimate for 0.26 for mag 10.8, 0.33 for mag 15}
              end;

             //Voor een fotografische sterren database gebaseerd op BPg kan ik de Tycho aanvullende sterren omrekenen
             //Tycho -> BPg
             //BPg := Vt -0.006739+0.2758*(Bt-Vt)-0.135*(Bt-Vt)^2+0.01098(Bt-Vt)^3
             //En voor de Gaia met de ontbrekende BPg magnitude zoiets als:
             //BPg := G+0.5

             //Voor een V magnitude database kan ik V bereken voor zowel Gaia als Tycho:
             //Gaia -> V
             //V := G + 0.01760 + 0.006860 * (BPg−RPg) + 0.1732 * (BPg−RPg)^2
             //En voor de ontbrekende BPg magnitudes zoiets als:
             //V:= G+0.3
             //Tycho->V
             //V := Vt - 0.090 * (Bt - Vt) {oude formule}


              if magBP<>0 {BP magn data available} then inc(starcount [min(2400,round(magBP*100))],1){for checking if database is complete}
                                                   else inc(starcount2[min(2400,round((magG+0.5)*100))],1);{for checking if database is complete}

              if straylight then
              begin
                inc(starcount3[min(2400,round((magG+0.5)*100))],1);{stars effected by straylight}
                inc(nr_of_straylight);
              end;

        //##########################################


          x:=length(stars1[0]);
          stars1[0,count]:=ra;
          stars1[1,count]:=dec;
          stars1[2,count]:=mag1;//BP or calculated V magnitude
          stars1[3,count]:=b_r; //BP-RP

          inc(count);
          if count>=length(stars1[0]) then
                               setlength(stars1,4,length(stars1[0])+1000000);//increase size
        end;// error_total=0

        if frac(count/3000)=0 then
        begin
          stars_sorted_magn1.Caption:=inttostr(count);
          application.processmessages;
          if keypressed=vk_F4 then begin closefile(tof); closefile(ftext); halt; end;;
          if keypressed=vk_F7  then
          begin
            repeat
              main_form.status1.caption:='Paused';
              if blink then main_form.status1.font.color:=Clred else main_form.status1.font.color:=CLblack;
              if blink then blink:=false else  blink:=true;{blinker}
              sleep(500);
              Application.ProcessMessages; {allow application  to update form1 with above messages}
            until keypressed=vk_F8;
            main_form.status1.caption:='Running';
          end;
        end;


    until eof(ftext);

    closefile(ftext);
    setlength(stars1,4,count);
    sort_on_magnitude(stars1,stars2);//sort on magnitude

    if filter_star_density1.checked then
    begin
      count:=0;
      max_density:=0;
      min_density:=999999999999999;
      total_surface:=0;

      density:=density1.position;//stars per square degree

      dfac:=round(sqrt(density*0.5));//divide in areas of about 50 stars.
      //Density=5000=> divide in 50x50 for whole area containing about total_surface*5000 stars equals about 25*5000 stars.  Density for each area is 25*5000/(50*10)=50 stars
      //Density=500=> divide in 16x16 for whole area containing about 25*500 stars. Density for each area is 25*500/(16*16)=50 stars
      //density 5000 =>dfac=50
      //density 500  =>dfac=16

      if ((k>1) and (k<290)) then //not at the poles
      begin
        for i:=0 to dfac-1 do //dived 5x5 degrees in about 0.1 x 0.1 degrees segments
        for j:=0 to dfac-1 do
        begin
          small_counter:=0;
          ra_min:=centers290[k,3]+(i/dfac)*(centers290[k,4]-centers290[k,3]);  {1..6, ra_center, dec_center, ra_min    ,ra_max, dec_min, dec_max}
          ra_max:=ra_min+(1/dfac)*(centers290[k,4]-centers290[k,3]);
          dec_min:=centers290[k,5]+(j/dfac)*(centers290[k,6]-centers290[k,5]);
          dec_max:=dec_min+(1/dfac)*(centers290[k,6]-centers290[k,5]);
          surface:=(ra_max-ra_min)*cos(0.5*(dec_max+dec_min)) * (dec_max-dec_min)*sqr(180/pi);//surface in degrees

          for m:=0 to length(stars2[0])-1 do// copy stars from stars2 to stars1 up to specified star density
          if ((small_counter<=density*surface) and (stars2[0,m]>=ra_min) and (stars2[0,m]<ra_max) and (stars2[1,m]>=dec_min) and (stars2[1,m]<dec_max)) then
          begin //within the small segment
            stars1[0,count]:=stars2[0,m];//copy brightest stars
            stars1[1,count]:=stars2[1,m];
            stars1[2,count]:=stars2[2,m];//magnitude
            stars1[3,count]:=stars2[3,m];//BP-RP
            inc(small_counter);//small segment counter
            inc(count);//total counter
          end;

          //reporting
          actual_density:=small_counter/surface;
          if actual_density>max_density then max_density:=actual_density;
          if actual_density<min_density then min_density:=actual_density;
          total_surface:=total_surface+surface;

        end;//for loop
      end
      else
      begin //poles area 1 and 290. North pole are 290 the density is about 6957/degr, south pole area 1 density is 15816/degrees. See also image https://sci.esa.int/web/gaia/-/the-density-of-stars-from-gaia-s-early-data-release-3
         small_counter:=0;
         r:=(centers290[1,6]-centers290[1,5])*180/pi;//radius of the pole circle
         surface:=pi*sqr(r);//do not divide the pole areas in smaller segments
         for m:=0 to length(stars2[0])-1 do// copy stars from stars2 to stars1 up to specified star density
         if small_counter<=density*surface then
         begin //within the small segment
           stars1[0,count]:=stars2[0,m];//copy brightest stars
           stars1[1,count]:=stars2[1,m];
           stars1[2,count]:=stars2[2,m];//magnitude
           stars1[3,count]:=stars2[3,m];//BP-RP
           inc(small_counter);//small segment counter
           inc(count);//total counter
         end;
         actual_density:=small_counter/surface;
         max_density:=density;
         min_density:=density;
         total_surface:=surface;
      end;

      setlength(stars1,4,count);
      actual_density1.caption:='Min density:'+floattostrF(min_density,FFfixed,6,0)+', Max density: '+floattostrF(max_density,FFfixed,6,0)+', original average star density:'+floattostrF(length(stars2[0])/total_surface,FFfixed,6,0)+', total surface:'+floattostrF(total_surface,FFfixed,6,2)+'°' ;//report density
      sort_on_magnitude(stars1,stars2);//sort again
      application.processmessages;
    end;

    save_stars(gaia_path+PathDelim+changefileext(fname,'.bin1'),stars2)
    end;//file exist

  end;//for loop 290 files

  stars1:=nil;
  stars2:=nil;

  writelongreport;{write long log file in steps of 0.01 magn}


  if ((powerdown_enabled.checked)and (count>100)) then
  {$ifdef mswindows}
  main_form.caption:= ShutMeDown
  {$else} {unix}
  fpSystem('/sbin/shutdown -P now')
  {$endif}
  else
  begin
    messagebox(main_form.handle,pchar('Ready.'),pchar('Ready'),MB_ICONINFORMATION);
    main_form.status1.caption:='Finished';
  end;

//  load_stars(gaia_path2.text+PathDelim+'area_3101.290.bin1',stars2);
end;


function getinstalldir:string;
begin
  result:=extractfiledir(paramstr(0));
end;


procedure TMain_form.FormCreate(Sender: TObject);
begin
  thepath:=getinstalldir;
//  application_path:= extractfilepath(application.location);{}

end;


end.

