pkzip25  -add source_GAIA_to_290_%date:/=-%   *.pas *.dfm *.dpr *.dproj *.lpr *.lfm *.lpi *.lps *.dof *.cfg *.res *.ini .\help\uk\*.htm *.bat *.txt Gaia_edr*.csv
xcopy source*.zip d:\hnsky_source /s/y/d/c
xcopy source*.zip e:\hnsky_source /s/y/d/c
xcopy source*.zip f:\hnsky_source /s/y/d/c
xcopy source*.zip g:\hnsky_source /s/y/d/c
xcopy source*.zip h:\hnsky_source /s/y/d/c
xcopy source*.zip i:\hnsky_source /s/y/d/c
xcopy source*.zip j:\hnsky_source /s/y/d/c
xcopy source*.zip k:\hnsky_source /s/y/d/c
pause


