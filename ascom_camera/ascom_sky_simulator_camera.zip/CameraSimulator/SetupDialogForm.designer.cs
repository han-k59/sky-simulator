namespace ASCOM.Sky_Simulator
{
	partial class SetupDialogForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SetupDialogForm));
            this.cmdOK = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.groupBoxCCD = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBoxOmitOddBins = new System.Windows.Forms.CheckBox();
            this.textBoxCameraYSize = new System.Windows.Forms.TextBox();
            this.textBoxCameraXSize = new System.Windows.Forms.TextBox();
            this.textBoxMaxBinY = new System.Windows.Forms.TextBox();
            this.textBoxMaxBinX = new System.Windows.Forms.TextBox();
            this.textBoxSensorName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxBayerOffsetY = new System.Windows.Forms.TextBox();
            this.labelBayerOffsetY = new System.Windows.Forms.Label();
            this.textBoxBayerOffsetX = new System.Windows.Forms.TextBox();
            this.labelBayerOffsetX = new System.Windows.Forms.Label();
            this.comboBoxSensorType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.checkBoxHasShutter = new System.Windows.Forms.CheckBox();
            this.checkBoxCanAsymmetricBin = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxGainSettings = new System.Windows.Forms.GroupBox();
            this.checkBoxgaincontrol1 = new System.Windows.Forms.CheckBox();
            this.groupBoxCooling = new System.Windows.Forms.GroupBox();
            this.BtnCoolerConfiguration = new System.Windows.Forms.Button();
            this.checkBoxHasCooler = new System.Windows.Forms.CheckBox();
            this.checkBoxCanGetCoolerPower = new System.Windows.Forms.CheckBox();
            this.checkBoxCanSetCCDTemperature = new System.Windows.Forms.CheckBox();
            this.groupBoxExposure = new System.Windows.Forms.GroupBox();
            this.textBoxMaxExposure = new System.Windows.Forms.TextBox();
            this.textBoxMinExposure = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBoxCanStopExposure = new System.Windows.Forms.CheckBox();
            this.checkBoxCanAbortExposure = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxPixelSizeY = new System.Windows.Forms.TextBox();
            this.textBoxPixelSizeX = new System.Windows.Forms.TextBox();
            this.textBoxMaxADU = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.labelSizeY = new System.Windows.Forms.Label();
            this.labelSizeX = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.readnoise_textBox1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.skyglow_textBox1 = new System.Windows.Forms.TextBox();
            this.buttonSetImageFile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.checkBoxInterfaceVersion = new System.Windows.Forms.CheckBox();
            this.groupBoxGuiding = new System.Windows.Forms.GroupBox();
            this.checkBoxCanPulseGuide = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.checkBoxUseReadoutModes = new System.Windows.Forms.CheckBox();
            this.checkBoxCanFastReadout = new System.Windows.Forms.CheckBox();
            this.checkBoxLogging = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBoxReadoutModes = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picASCOM = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBoxCCD.SuspendLayout();
            this.groupBoxGainSettings.SuspendLayout();
            this.groupBoxCooling.SuspendLayout();
            this.groupBoxExposure.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxGuiding.SuspendLayout();
            this.groupBoxReadoutModes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picASCOM)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdOK
            // 
            this.cmdOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.cmdOK.Location = new System.Drawing.Point(776, 422);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(59, 24);
            this.cmdOK.TabIndex = 0;
            this.cmdOK.Text = "OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.Location = new System.Drawing.Point(693, 422);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(59, 25);
            this.cmdCancel.TabIndex = 1;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // groupBoxCCD
            // 
            this.groupBoxCCD.Controls.Add(this.label9);
            this.groupBoxCCD.Controls.Add(this.checkBoxOmitOddBins);
            this.groupBoxCCD.Controls.Add(this.textBoxCameraYSize);
            this.groupBoxCCD.Controls.Add(this.textBoxCameraXSize);
            this.groupBoxCCD.Controls.Add(this.textBoxMaxBinY);
            this.groupBoxCCD.Controls.Add(this.textBoxMaxBinX);
            this.groupBoxCCD.Controls.Add(this.textBoxSensorName);
            this.groupBoxCCD.Controls.Add(this.label13);
            this.groupBoxCCD.Controls.Add(this.textBoxBayerOffsetY);
            this.groupBoxCCD.Controls.Add(this.labelBayerOffsetY);
            this.groupBoxCCD.Controls.Add(this.textBoxBayerOffsetX);
            this.groupBoxCCD.Controls.Add(this.labelBayerOffsetX);
            this.groupBoxCCD.Controls.Add(this.comboBoxSensorType);
            this.groupBoxCCD.Controls.Add(this.label12);
            this.groupBoxCCD.Controls.Add(this.checkBoxHasShutter);
            this.groupBoxCCD.Controls.Add(this.checkBoxCanAsymmetricBin);
            this.groupBoxCCD.Controls.Add(this.label6);
            this.groupBoxCCD.Controls.Add(this.label4);
            this.groupBoxCCD.Controls.Add(this.label3);
            this.groupBoxCCD.Controls.Add(this.label2);
            this.groupBoxCCD.Location = new System.Drawing.Point(4, 126);
            this.groupBoxCCD.Name = "groupBoxCCD";
            this.groupBoxCCD.Size = new System.Drawing.Size(146, 246);
            this.groupBoxCCD.TabIndex = 4;
            this.groupBoxCCD.TabStop = false;
            this.groupBoxCCD.Text = "CCD";
            // 
            // label9
            // 
            this.label9.AllowDrop = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(80, 10);
            this.label9.MaximumSize = new System.Drawing.Size(120, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 48);
            this.label9.TabIndex = 30;
            this.label9.Text = "Same as IMAGE file";
            // 
            // checkBoxOmitOddBins
            // 
            this.checkBoxOmitOddBins.AutoSize = true;
            this.checkBoxOmitOddBins.Location = new System.Drawing.Point(6, 112);
            this.checkBoxOmitOddBins.Name = "checkBoxOmitOddBins";
            this.checkBoxOmitOddBins.Size = new System.Drawing.Size(93, 17);
            this.checkBoxOmitOddBins.TabIndex = 29;
            this.checkBoxOmitOddBins.Text = "Omit Odd Bins";
            this.toolTip1.SetToolTip(this.checkBoxOmitOddBins, "Throw NotImplementedExceptions for odd bin values of 3 or greater. This has no ef" +
        "fect unless MaxBinX and MaxBinY are 4 or greater.");
            this.checkBoxOmitOddBins.UseVisualStyleBackColor = true;
            // 
            // textBoxCameraYSize
            // 
            this.textBoxCameraYSize.Location = new System.Drawing.Point(90, 38);
            this.textBoxCameraYSize.Name = "textBoxCameraYSize";
            this.textBoxCameraYSize.Size = new System.Drawing.Size(47, 20);
            this.textBoxCameraYSize.TabIndex = 28;
            this.toolTip1.SetToolTip(this.textBoxCameraYSize, "The number of unbinned pixels down the the height of the CCD");
            this.textBoxCameraYSize.Visible = false;
            // 
            // textBoxCameraXSize
            // 
            this.textBoxCameraXSize.Location = new System.Drawing.Point(90, 13);
            this.textBoxCameraXSize.Name = "textBoxCameraXSize";
            this.textBoxCameraXSize.Size = new System.Drawing.Size(47, 20);
            this.textBoxCameraXSize.TabIndex = 27;
            this.toolTip1.SetToolTip(this.textBoxCameraXSize, "The number of unbinned pixels across the width of the CCD");
            this.textBoxCameraXSize.Visible = false;
            // 
            // textBoxMaxBinY
            // 
            this.textBoxMaxBinY.Enabled = false;
            this.textBoxMaxBinY.Location = new System.Drawing.Point(109, 63);
            this.textBoxMaxBinY.Name = "textBoxMaxBinY";
            this.textBoxMaxBinY.Size = new System.Drawing.Size(16, 20);
            this.textBoxMaxBinY.TabIndex = 26;
            this.toolTip1.SetToolTip(this.textBoxMaxBinY, "The maximum bin value in Y");
            // 
            // textBoxMaxBinX
            // 
            this.textBoxMaxBinX.Enabled = false;
            this.textBoxMaxBinX.Location = new System.Drawing.Point(71, 63);
            this.textBoxMaxBinX.Name = "textBoxMaxBinX";
            this.textBoxMaxBinX.Size = new System.Drawing.Size(16, 20);
            this.textBoxMaxBinX.TabIndex = 25;
            this.toolTip1.SetToolTip(this.textBoxMaxBinX, "The maximum X bin value");
            // 
            // textBoxSensorName
            // 
            this.textBoxSensorName.Location = new System.Drawing.Point(47, 161);
            this.textBoxSensorName.Name = "textBoxSensorName";
            this.textBoxSensorName.Size = new System.Drawing.Size(90, 20);
            this.textBoxSensorName.TabIndex = 24;
            this.toolTip1.SetToolTip(this.textBoxSensorName, "Set the Sensor Name.");
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "Name";
            // 
            // textBoxBayerOffsetY
            // 
            this.textBoxBayerOffsetY.Location = new System.Drawing.Point(126, 217);
            this.textBoxBayerOffsetY.Name = "textBoxBayerOffsetY";
            this.textBoxBayerOffsetY.Size = new System.Drawing.Size(18, 20);
            this.textBoxBayerOffsetY.TabIndex = 22;
            this.toolTip1.SetToolTip(this.textBoxBayerOffsetY, "Bayer Offset in Y");
            // 
            // labelBayerOffsetY
            // 
            this.labelBayerOffsetY.AutoSize = true;
            this.labelBayerOffsetY.Location = new System.Drawing.Point(112, 220);
            this.labelBayerOffsetY.Name = "labelBayerOffsetY";
            this.labelBayerOffsetY.Size = new System.Drawing.Size(17, 13);
            this.labelBayerOffsetY.TabIndex = 21;
            this.labelBayerOffsetY.Text = "Y:";
            // 
            // textBoxBayerOffsetX
            // 
            this.textBoxBayerOffsetX.Location = new System.Drawing.Point(88, 217);
            this.textBoxBayerOffsetX.Name = "textBoxBayerOffsetX";
            this.textBoxBayerOffsetX.Size = new System.Drawing.Size(18, 20);
            this.textBoxBayerOffsetX.TabIndex = 20;
            this.toolTip1.SetToolTip(this.textBoxBayerOffsetX, "Bayer offset in X");
            // 
            // labelBayerOffsetX
            // 
            this.labelBayerOffsetX.AutoSize = true;
            this.labelBayerOffsetX.Location = new System.Drawing.Point(4, 220);
            this.labelBayerOffsetX.Name = "labelBayerOffsetX";
            this.labelBayerOffsetX.Size = new System.Drawing.Size(84, 13);
            this.labelBayerOffsetX.TabIndex = 19;
            this.labelBayerOffsetX.Text = "Bayer Offset   X:";
            this.toolTip1.SetToolTip(this.labelBayerOffsetX, "Set the offset in X and Y pixels to the first pixel in the Bayer array. For camer" +
        "as with a colour filter array only.");
            // 
            // comboBoxSensorType
            // 
            this.comboBoxSensorType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSensorType.FormattingEnabled = true;
            this.comboBoxSensorType.Items.AddRange(new object[] {
            "Monochrome"});
            this.comboBoxSensorType.Location = new System.Drawing.Point(47, 187);
            this.comboBoxSensorType.Name = "comboBoxSensorType";
            this.comboBoxSensorType.Size = new System.Drawing.Size(90, 21);
            this.comboBoxSensorType.TabIndex = 16;
            this.toolTip1.SetToolTip(this.comboBoxSensorType, "Set the sensor type, Monochrome for a monochrome camera.");
            this.comboBoxSensorType.SelectedIndexChanged += new System.EventHandler(this.comboBoxSensorType_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 190);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Type";
            // 
            // checkBoxHasShutter
            // 
            this.checkBoxHasShutter.AutoSize = true;
            this.checkBoxHasShutter.Location = new System.Drawing.Point(6, 135);
            this.checkBoxHasShutter.Name = "checkBoxHasShutter";
            this.checkBoxHasShutter.Size = new System.Drawing.Size(82, 17);
            this.checkBoxHasShutter.TabIndex = 14;
            this.checkBoxHasShutter.Text = "Has Shutter";
            this.toolTip1.SetToolTip(this.checkBoxHasShutter, "Check this if the camera has a mechanical shutter.");
            this.checkBoxHasShutter.UseVisualStyleBackColor = true;
            // 
            // checkBoxCanAsymmetricBin
            // 
            this.checkBoxCanAsymmetricBin.AutoSize = true;
            this.checkBoxCanAsymmetricBin.Enabled = false;
            this.checkBoxCanAsymmetricBin.Location = new System.Drawing.Point(6, 89);
            this.checkBoxCanAsymmetricBin.Name = "checkBoxCanAsymmetricBin";
            this.checkBoxCanAsymmetricBin.Size = new System.Drawing.Size(119, 17);
            this.checkBoxCanAsymmetricBin.TabIndex = 13;
            this.checkBoxCanAsymmetricBin.Text = "Can Asymmetric Bin";
            this.toolTip1.SetToolTip(this.checkBoxCanAsymmetricBin, "Check this if the camera can have different X and Y bin values");
            this.checkBoxCanAsymmetricBin.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(93, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Y:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Max Bin  X:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Height (Pixels)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Width (Pixels)";
            // 
            // groupBoxGainSettings
            // 
            this.groupBoxGainSettings.Controls.Add(this.label14);
            this.groupBoxGainSettings.Controls.Add(this.checkBoxgaincontrol1);
            this.groupBoxGainSettings.Location = new System.Drawing.Point(156, 91);
            this.groupBoxGainSettings.Name = "groupBoxGainSettings";
            this.groupBoxGainSettings.Size = new System.Drawing.Size(161, 114);
            this.groupBoxGainSettings.TabIndex = 5;
            this.groupBoxGainSettings.TabStop = false;
            this.groupBoxGainSettings.Text = "Gain Settings";
            // 
            // checkBoxgaincontrol1
            // 
            this.checkBoxgaincontrol1.AutoSize = true;
            this.checkBoxgaincontrol1.Location = new System.Drawing.Point(9, 35);
            this.checkBoxgaincontrol1.Name = "checkBoxgaincontrol1";
            this.checkBoxgaincontrol1.Size = new System.Drawing.Size(108, 17);
            this.checkBoxgaincontrol1.TabIndex = 31;
            this.checkBoxgaincontrol1.Text = "Allow setting gain";
            this.toolTip1.SetToolTip(this.checkBoxgaincontrol1, "Allow gain control between 100 (unity gain) and 1000");
            this.checkBoxgaincontrol1.UseVisualStyleBackColor = true;
            // 
            // groupBoxCooling
            // 
            this.groupBoxCooling.Controls.Add(this.BtnCoolerConfiguration);
            this.groupBoxCooling.Controls.Add(this.checkBoxHasCooler);
            this.groupBoxCooling.Controls.Add(this.checkBoxCanGetCoolerPower);
            this.groupBoxCooling.Controls.Add(this.checkBoxCanSetCCDTemperature);
            this.groupBoxCooling.Location = new System.Drawing.Point(156, 4);
            this.groupBoxCooling.Name = "groupBoxCooling";
            this.groupBoxCooling.Size = new System.Drawing.Size(161, 81);
            this.groupBoxCooling.TabIndex = 6;
            this.groupBoxCooling.TabStop = false;
            this.groupBoxCooling.Text = "Cooling";
            // 
            // BtnCoolerConfiguration
            // 
            this.BtnCoolerConfiguration.Location = new System.Drawing.Point(97, 12);
            this.BtnCoolerConfiguration.Name = "BtnCoolerConfiguration";
            this.BtnCoolerConfiguration.Size = new System.Drawing.Size(52, 23);
            this.BtnCoolerConfiguration.TabIndex = 14;
            this.BtnCoolerConfiguration.Text = "Setup";
            this.toolTip1.SetToolTip(this.BtnCoolerConfiguration, resources.GetString("BtnCoolerConfiguration.ToolTip"));
            this.BtnCoolerConfiguration.UseVisualStyleBackColor = true;
            this.BtnCoolerConfiguration.Click += new System.EventHandler(this.BtnCoolerConfiguration_Click);
            // 
            // checkBoxHasCooler
            // 
            this.checkBoxHasCooler.AutoSize = true;
            this.checkBoxHasCooler.Location = new System.Drawing.Point(6, 16);
            this.checkBoxHasCooler.Name = "checkBoxHasCooler";
            this.checkBoxHasCooler.Size = new System.Drawing.Size(78, 17);
            this.checkBoxHasCooler.TabIndex = 2;
            this.checkBoxHasCooler.Text = "Has Cooler";
            this.toolTip1.SetToolTip(this.checkBoxHasCooler, "Check this if the camera has a CCD cooler that can be controlled.");
            this.checkBoxHasCooler.UseVisualStyleBackColor = true;
            // 
            // checkBoxCanGetCoolerPower
            // 
            this.checkBoxCanGetCoolerPower.AutoSize = true;
            this.checkBoxCanGetCoolerPower.Location = new System.Drawing.Point(6, 56);
            this.checkBoxCanGetCoolerPower.Name = "checkBoxCanGetCoolerPower";
            this.checkBoxCanGetCoolerPower.Size = new System.Drawing.Size(131, 17);
            this.checkBoxCanGetCoolerPower.TabIndex = 1;
            this.checkBoxCanGetCoolerPower.Text = "Can Get Cooler Power";
            this.toolTip1.SetToolTip(this.checkBoxCanGetCoolerPower, "Check this if the cooler power can be read");
            this.checkBoxCanGetCoolerPower.UseVisualStyleBackColor = true;
            // 
            // checkBoxCanSetCCDTemperature
            // 
            this.checkBoxCanSetCCDTemperature.AutoSize = true;
            this.checkBoxCanSetCCDTemperature.Location = new System.Drawing.Point(6, 36);
            this.checkBoxCanSetCCDTemperature.Name = "checkBoxCanSetCCDTemperature";
            this.checkBoxCanSetCCDTemperature.Size = new System.Drawing.Size(152, 17);
            this.checkBoxCanSetCCDTemperature.TabIndex = 0;
            this.checkBoxCanSetCCDTemperature.Text = "Can Set CCD Temperature";
            this.toolTip1.SetToolTip(this.checkBoxCanSetCCDTemperature, "Check this if the CCD temperature can be set");
            this.checkBoxCanSetCCDTemperature.UseVisualStyleBackColor = true;
            // 
            // groupBoxExposure
            // 
            this.groupBoxExposure.Controls.Add(this.textBoxMaxExposure);
            this.groupBoxExposure.Controls.Add(this.textBoxMinExposure);
            this.groupBoxExposure.Controls.Add(this.label16);
            this.groupBoxExposure.Controls.Add(this.label5);
            this.groupBoxExposure.Controls.Add(this.checkBoxCanStopExposure);
            this.groupBoxExposure.Controls.Add(this.checkBoxCanAbortExposure);
            this.groupBoxExposure.Location = new System.Drawing.Point(156, 284);
            this.groupBoxExposure.Name = "groupBoxExposure";
            this.groupBoxExposure.Size = new System.Drawing.Size(161, 115);
            this.groupBoxExposure.TabIndex = 7;
            this.groupBoxExposure.TabStop = false;
            this.groupBoxExposure.Text = "Exposure";
            // 
            // textBoxMaxExposure
            // 
            this.textBoxMaxExposure.Location = new System.Drawing.Point(93, 83);
            this.textBoxMaxExposure.Name = "textBoxMaxExposure";
            this.textBoxMaxExposure.Size = new System.Drawing.Size(61, 20);
            this.textBoxMaxExposure.TabIndex = 5;
            // 
            // textBoxMinExposure
            // 
            this.textBoxMinExposure.Location = new System.Drawing.Point(93, 57);
            this.textBoxMinExposure.Name = "textBoxMinExposure";
            this.textBoxMinExposure.Size = new System.Drawing.Size(61, 20);
            this.textBoxMinExposure.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "Max Exposure (s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Min exposure (s)";
            // 
            // checkBoxCanStopExposure
            // 
            this.checkBoxCanStopExposure.AutoSize = true;
            this.checkBoxCanStopExposure.Location = new System.Drawing.Point(7, 40);
            this.checkBoxCanStopExposure.Name = "checkBoxCanStopExposure";
            this.checkBoxCanStopExposure.Size = new System.Drawing.Size(116, 17);
            this.checkBoxCanStopExposure.TabIndex = 1;
            this.checkBoxCanStopExposure.Text = "Can Stop exposure";
            this.checkBoxCanStopExposure.UseVisualStyleBackColor = true;
            // 
            // checkBoxCanAbortExposure
            // 
            this.checkBoxCanAbortExposure.AutoSize = true;
            this.checkBoxCanAbortExposure.Location = new System.Drawing.Point(6, 17);
            this.checkBoxCanAbortExposure.Name = "checkBoxCanAbortExposure";
            this.checkBoxCanAbortExposure.Size = new System.Drawing.Size(120, 17);
            this.checkBoxCanAbortExposure.TabIndex = 0;
            this.checkBoxCanAbortExposure.Text = "Can Abort Exposure";
            this.checkBoxCanAbortExposure.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxPixelSizeY);
            this.groupBox1.Controls.Add(this.textBoxPixelSizeX);
            this.groupBox1.Controls.Add(this.textBoxMaxADU);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.labelSizeY);
            this.groupBox1.Controls.Add(this.labelSizeX);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(146, 116);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pixel";
            // 
            // textBoxPixelSizeY
            // 
            this.textBoxPixelSizeY.Location = new System.Drawing.Point(88, 35);
            this.textBoxPixelSizeY.Name = "textBoxPixelSizeY";
            this.textBoxPixelSizeY.Size = new System.Drawing.Size(42, 20);
            this.textBoxPixelSizeY.TabIndex = 17;
            this.toolTip1.SetToolTip(this.textBoxPixelSizeY, "Set the pixel height in microns");
            // 
            // textBoxPixelSizeX
            // 
            this.textBoxPixelSizeX.Location = new System.Drawing.Point(88, 13);
            this.textBoxPixelSizeX.Name = "textBoxPixelSizeX";
            this.textBoxPixelSizeX.Size = new System.Drawing.Size(42, 20);
            this.textBoxPixelSizeX.TabIndex = 16;
            this.toolTip1.SetToolTip(this.textBoxPixelSizeX, "Set the pixel width in microns.");
            // 
            // textBoxMaxADU
            // 
            this.textBoxMaxADU.Location = new System.Drawing.Point(83, 61);
            this.textBoxMaxADU.Name = "textBoxMaxADU";
            this.textBoxMaxADU.Size = new System.Drawing.Size(47, 20);
            this.textBoxMaxADU.TabIndex = 14;
            this.toolTip1.SetToolTip(this.textBoxMaxADU, "This is the maximum ADU value that the camera can return");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Maximum ADU";
            // 
            // labelSizeY
            // 
            this.labelSizeY.AutoSize = true;
            this.labelSizeY.Location = new System.Drawing.Point(6, 38);
            this.labelSizeY.Name = "labelSizeY";
            this.labelSizeY.Size = new System.Drawing.Size(83, 13);
            this.labelSizeY.TabIndex = 9;
            this.labelSizeY.Text = "Height (microns)";
            // 
            // labelSizeX
            // 
            this.labelSizeX.AutoSize = true;
            this.labelSizeX.Location = new System.Drawing.Point(6, 16);
            this.labelSizeX.Name = "labelSizeX";
            this.labelSizeX.Size = new System.Drawing.Size(80, 13);
            this.labelSizeX.TabIndex = 8;
            this.labelSizeX.Text = "Width (microns)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.readnoise_textBox1);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.skyglow_textBox1);
            this.groupBox2.Location = new System.Drawing.Point(323, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(528, 212);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Simulation";
            // 
            // label7
            // 
            this.label7.AllowDrop = true;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1, 93);
            this.label7.MaximumSize = new System.Drawing.Size(530, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(522, 120);
            this.label7.TabIndex = 22;
            this.label7.Text = resources.GetString("label7.Text");
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 50);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "Camera read noise";
            // 
            // readnoise_textBox1
            // 
            this.readnoise_textBox1.Location = new System.Drawing.Point(168, 47);
            this.readnoise_textBox1.Name = "readnoise_textBox1";
            this.readnoise_textBox1.Size = new System.Drawing.Size(47, 20);
            this.readnoise_textBox1.TabIndex = 20;
            this.toolTip1.SetToolTip(this.readnoise_textBox1, "The number of electrons for a change of one step on the ADU out");
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(86, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "Sky glow";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(245, 50);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "e-/pix";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(245, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "e-/pix/s";
            // 
            // skyglow_textBox1
            // 
            this.skyglow_textBox1.Location = new System.Drawing.Point(168, 21);
            this.skyglow_textBox1.Name = "skyglow_textBox1";
            this.skyglow_textBox1.Size = new System.Drawing.Size(47, 20);
            this.skyglow_textBox1.TabIndex = 16;
            this.toolTip1.SetToolTip(this.skyglow_textBox1, "The number of electrons for a change of one step on the ADU out");
            // 
            // buttonSetImageFile
            // 
            this.buttonSetImageFile.FlatAppearance.BorderSize = 2;
            this.buttonSetImageFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSetImageFile.ForeColor = System.Drawing.Color.Red;
            this.buttonSetImageFile.Image = global::ASCOM.Sky_Simulator.Properties.Resources.sky_simulator;
            this.buttonSetImageFile.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonSetImageFile.Location = new System.Drawing.Point(376, 372);
            this.buttonSetImageFile.Name = "buttonSetImageFile";
            this.buttonSetImageFile.Size = new System.Drawing.Size(266, 75);
            this.buttonSetImageFile.TabIndex = 2;
            this.buttonSetImageFile.Text = "  IMAGE FILE (Select with this button the same path to image.png as in the Sky Si" +
    "mulator program) !!!!";
            this.buttonSetImageFile.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.toolTip1.SetToolTip(this.buttonSetImageFile, resources.GetString("buttonSetImageFile.ToolTip"));
            this.buttonSetImageFile.UseVisualStyleBackColor = true;
            this.buttonSetImageFile.Click += new System.EventHandler(this.buttonSetImageFile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "image.png|image.png|All files (*.*)|*.*";
            // 
            // checkBoxInterfaceVersion
            // 
            this.checkBoxInterfaceVersion.AutoSize = true;
            this.checkBoxInterfaceVersion.Location = new System.Drawing.Point(329, 98);
            this.checkBoxInterfaceVersion.Name = "checkBoxInterfaceVersion";
            this.checkBoxInterfaceVersion.Size = new System.Drawing.Size(115, 17);
            this.checkBoxInterfaceVersion.TabIndex = 10;
            this.checkBoxInterfaceVersion.Text = "Interface Version 2";
            this.toolTip1.SetToolTip(this.checkBoxInterfaceVersion, "Check this if the camera simulates a Version 2 camera. If unchecked the V2 parame" +
        "ters will raise a not implemented error.");
            this.checkBoxInterfaceVersion.UseVisualStyleBackColor = true;
            this.checkBoxInterfaceVersion.CheckedChanged += new System.EventHandler(this.checkBoxInterfaceVersion_CheckedChanged);
            // 
            // groupBoxGuiding
            // 
            this.groupBoxGuiding.Controls.Add(this.checkBoxCanPulseGuide);
            this.groupBoxGuiding.Location = new System.Drawing.Point(608, 72);
            this.groupBoxGuiding.Name = "groupBoxGuiding";
            this.groupBoxGuiding.Size = new System.Drawing.Size(121, 46);
            this.groupBoxGuiding.TabIndex = 11;
            this.groupBoxGuiding.TabStop = false;
            this.groupBoxGuiding.Text = "Guiding";
            // 
            // checkBoxCanPulseGuide
            // 
            this.checkBoxCanPulseGuide.AutoSize = true;
            this.checkBoxCanPulseGuide.Location = new System.Drawing.Point(6, 26);
            this.checkBoxCanPulseGuide.Name = "checkBoxCanPulseGuide";
            this.checkBoxCanPulseGuide.Size = new System.Drawing.Size(105, 17);
            this.checkBoxCanPulseGuide.TabIndex = 0;
            this.checkBoxCanPulseGuide.Text = "Can Pulse Guide";
            this.toolTip1.SetToolTip(this.checkBoxCanPulseGuide, "Check this if the camera can accept pulse guide commands. They will have no effec" +
        "t.");
            this.checkBoxCanPulseGuide.UseVisualStyleBackColor = true;
            // 
            // checkBoxUseReadoutModes
            // 
            this.checkBoxUseReadoutModes.AutoSize = true;
            this.checkBoxUseReadoutModes.Location = new System.Drawing.Point(3, 42);
            this.checkBoxUseReadoutModes.Name = "checkBoxUseReadoutModes";
            this.checkBoxUseReadoutModes.Size = new System.Drawing.Size(141, 17);
            this.checkBoxUseReadoutModes.TabIndex = 0;
            this.checkBoxUseReadoutModes.Text = "Multiple Readout Modes";
            this.toolTip1.SetToolTip(this.checkBoxUseReadoutModes, "Check this if the camera can accept pulse guide commands. They will have no effec" +
        "t.");
            this.checkBoxUseReadoutModes.UseVisualStyleBackColor = true;
            // 
            // checkBoxCanFastReadout
            // 
            this.checkBoxCanFastReadout.AutoSize = true;
            this.checkBoxCanFastReadout.Location = new System.Drawing.Point(4, 19);
            this.checkBoxCanFastReadout.Name = "checkBoxCanFastReadout";
            this.checkBoxCanFastReadout.Size = new System.Drawing.Size(122, 17);
            this.checkBoxCanFastReadout.TabIndex = 1;
            this.checkBoxCanFastReadout.Text = "Can do Fast readout";
            this.toolTip1.SetToolTip(this.checkBoxCanFastReadout, "Check this if the camera can accept pulse guide commands. They will have no effec" +
        "t.");
            this.checkBoxCanFastReadout.UseVisualStyleBackColor = true;
            this.checkBoxCanFastReadout.CheckedChanged += new System.EventHandler(this.checkBoxCanFastReadout_CheckedChanged);
            // 
            // checkBoxLogging
            // 
            this.checkBoxLogging.AutoSize = true;
            this.checkBoxLogging.Location = new System.Drawing.Point(491, 98);
            this.checkBoxLogging.Name = "checkBoxLogging";
            this.checkBoxLogging.Size = new System.Drawing.Size(64, 17);
            this.checkBoxLogging.TabIndex = 13;
            this.checkBoxLogging.Text = "Logging";
            this.toolTip1.SetToolTip(this.checkBoxLogging, "Check this to turn logging on. Log files are in the \"My Documents\\ASCOM\\<date>\" f" +
        "older.\r\n");
            this.checkBoxLogging.UseVisualStyleBackColor = true;
            this.checkBoxLogging.CheckedChanged += new System.EventHandler(this.checkBoxLogging_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(558, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "?";
            this.toolTip1.SetToolTip(this.label11, resources.GetString("label11.ToolTip"));
            // 
            // groupBoxReadoutModes
            // 
            this.groupBoxReadoutModes.Controls.Add(this.checkBoxCanFastReadout);
            this.groupBoxReadoutModes.Controls.Add(this.checkBoxUseReadoutModes);
            this.groupBoxReadoutModes.Location = new System.Drawing.Point(158, 209);
            this.groupBoxReadoutModes.Name = "groupBoxReadoutModes";
            this.groupBoxReadoutModes.Size = new System.Drawing.Size(159, 69);
            this.groupBoxReadoutModes.TabIndex = 12;
            this.groupBoxReadoutModes.TabStop = false;
            this.groupBoxReadoutModes.Text = "Readout Modes";
            // 
            // label1
            // 
            this.label1.AllowDrop = true;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(326, 9);
            this.label1.MaximumSize = new System.Drawing.Size(530, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 45);
            this.label1.TabIndex = 14;
            this.label1.Text = "Sky Simulator camera v2022-02-16\r\n\r\nBy www.hnsky.org\r\n";
            // 
            // picASCOM
            // 
            this.picASCOM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picASCOM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picASCOM.Image = ((System.Drawing.Image)(resources.GetObject("picASCOM.Image")));
            this.picASCOM.InitialImage = ((System.Drawing.Image)(resources.GetObject("picASCOM.InitialImage")));
            this.picASCOM.Location = new System.Drawing.Point(11, 391);
            this.picASCOM.Name = "picASCOM";
            this.picASCOM.Size = new System.Drawing.Size(48, 56);
            this.picASCOM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picASCOM.TabIndex = 3;
            this.picASCOM.TabStop = false;
            this.picASCOM.Click += new System.EventHandler(this.BrowseToAscom);
            this.picASCOM.DoubleClick += new System.EventHandler(this.BrowseToAscom);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 65);
            this.label14.MaximumSize = new System.Drawing.Size(140, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(135, 39);
            this.label14.TabIndex = 32;
            this.label14.Text = "Unity gain at 100. \r\nGain can set between 100 and 1000";
            // 
            // SetupDialogForm
            // 
            this.AcceptButton = this.cmdOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.cmdCancel;
            this.ClientSize = new System.Drawing.Size(863, 459);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBoxLogging);
            this.Controls.Add(this.buttonSetImageFile);
            this.Controls.Add(this.groupBoxReadoutModes);
            this.Controls.Add(this.groupBoxGuiding);
            this.Controls.Add(this.checkBoxInterfaceVersion);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxExposure);
            this.Controls.Add(this.groupBoxCooling);
            this.Controls.Add(this.groupBoxGainSettings);
            this.Controls.Add(this.groupBoxCCD);
            this.Controls.Add(this.picASCOM);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SetupDialogForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sky Simulator camera Setup";
            this.Load += new System.EventHandler(this.SetupDialogForm_Load);
            this.groupBoxCCD.ResumeLayout(false);
            this.groupBoxCCD.PerformLayout();
            this.groupBoxGainSettings.ResumeLayout(false);
            this.groupBoxGainSettings.PerformLayout();
            this.groupBoxCooling.ResumeLayout(false);
            this.groupBoxCooling.PerformLayout();
            this.groupBoxExposure.ResumeLayout(false);
            this.groupBoxExposure.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBoxGuiding.ResumeLayout(false);
            this.groupBoxGuiding.PerformLayout();
            this.groupBoxReadoutModes.ResumeLayout(false);
            this.groupBoxReadoutModes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picASCOM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.Button cmdCancel;
		private System.Windows.Forms.PictureBox picASCOM;
        private System.Windows.Forms.GroupBox groupBoxCCD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxCanAsymmetricBin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBoxHasShutter;
        private System.Windows.Forms.GroupBox groupBoxGainSettings;
        private System.Windows.Forms.GroupBox groupBoxCooling;
        private System.Windows.Forms.CheckBox checkBoxCanGetCoolerPower;
        private System.Windows.Forms.CheckBox checkBoxCanSetCCDTemperature;
        private System.Windows.Forms.GroupBox groupBoxExposure;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelSizeY;
        private System.Windows.Forms.Label labelSizeX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxMaxADU;
        private System.Windows.Forms.ComboBox comboBoxSensorType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxMaxBinY;
        private System.Windows.Forms.TextBox textBoxMaxBinX;
        private System.Windows.Forms.TextBox textBoxSensorName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxBayerOffsetY;
        private System.Windows.Forms.Label labelBayerOffsetY;
        private System.Windows.Forms.TextBox textBoxBayerOffsetX;
        private System.Windows.Forms.Label labelBayerOffsetX;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxMaxExposure;
        private System.Windows.Forms.TextBox textBoxMinExposure;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBoxCanStopExposure;
        private System.Windows.Forms.CheckBox checkBoxCanAbortExposure;
        private System.Windows.Forms.CheckBox checkBoxHasCooler;
        private System.Windows.Forms.TextBox textBoxPixelSizeY;
        private System.Windows.Forms.TextBox textBoxPixelSizeX;
        private System.Windows.Forms.TextBox textBoxCameraYSize;
        private System.Windows.Forms.TextBox textBoxCameraXSize;
        private System.Windows.Forms.Button buttonSetImageFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox checkBoxInterfaceVersion;
        private System.Windows.Forms.GroupBox groupBoxGuiding;
        private System.Windows.Forms.CheckBox checkBoxCanPulseGuide;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox checkBoxOmitOddBins;
        private System.Windows.Forms.GroupBox groupBoxReadoutModes;
        private System.Windows.Forms.CheckBox checkBoxUseReadoutModes;
        private System.Windows.Forms.CheckBox checkBoxCanFastReadout;
        private System.Windows.Forms.CheckBox checkBoxLogging;
        private System.Windows.Forms.Button BtnCoolerConfiguration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox skyglow_textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox readnoise_textBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checkBoxgaincontrol1;
        private System.Windows.Forms.Label label14;
    }
}