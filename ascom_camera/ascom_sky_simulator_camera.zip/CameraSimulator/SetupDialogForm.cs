using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ASCOM.DeviceInterface;
using System.Collections;

namespace ASCOM.Sky_Simulator
{
    [ComVisible(false)]                 // Form not registered for COM!
    public partial class SetupDialogForm : Form
    {
        private const string STR_N2 = "N2";
        private Camera camera;

        private CoolerSetupForm coolerSetupForm; // Variable to hold an instance of the cooler configuration form
        internal bool okButtonPressed = false;

        public SetupDialogForm()
        {
            InitializeComponent();
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {
            okButtonPressed = true;
            SaveProperties();
            this.Dispose();
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            okButtonPressed = false;
            this.Dispose();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1300:SpecifyMessageBoxOptions")]
        private void BrowseToAscom(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://ascom-standards.org/");
            }
            catch (System.ComponentModel.Win32Exception noBrowser)
            {
                if (noBrowser.ErrorCode == -2147467259)
                    MessageBox.Show(noBrowser.Message);
            }
            catch (System.Exception other)
            {
                MessageBox.Show(other.Message);
            }
        }

        internal void InitProperties(Camera theCamera)
        {
            checkBoxLogging.Checked = Log.Enabled;
            checkBoxInterfaceVersion.Checked = (theCamera.interfaceVersion == 2);
            textBoxPixelSizeX.Text = theCamera.pixelSizeX.ToString(STR_N2, CultureInfo.CurrentCulture);
            textBoxPixelSizeY.Text = theCamera.pixelSizeY.ToString(STR_N2, CultureInfo.CurrentCulture);
            //textBoxFullWellCapacity.Text = camera.fullWellCapacity.ToString();
            textBoxMaxADU.Text = theCamera.maxADU.ToString(CultureInfo.CurrentCulture);
       //     textBoxElectronsPerADU.Text = theCamera.electronsPerADU.ToString(STR_N2, CultureInfo.CurrentCulture);//mod sky_simulator

            skyglow_textBox1.Text = theCamera.sky_glow.ToString(STR_N2, CultureInfo.CurrentCulture);//mod sky_simulator
            readnoise_textBox1.Text = theCamera.read_noise.ToString(STR_N2, CultureInfo.CurrentCulture);//mod sky_simulator

            textBoxCameraXSize.Text = theCamera.cameraXSize.ToString(CultureInfo.CurrentCulture);
            textBoxCameraYSize.Text = theCamera.cameraYSize.ToString(CultureInfo.CurrentCulture);
            checkBoxCanAsymmetricBin.Checked = theCamera.canAsymmetricBin;
            textBoxMaxBinX.Text = "1"; // theCamera.maxBinX.ToString(CultureInfo.CurrentCulture); // Sky_simulator, force max bin to 1
            textBoxMaxBinY.Text = "1"; // theCamera.maxBinY.ToString(CultureInfo.CurrentCulture); // Sky_simulator, force max bin to 1
            checkBoxHasShutter.Checked = theCamera.hasShutter;
            textBoxSensorName.Text = theCamera.sensorName;
            comboBoxSensorType.SelectedIndex = 0; // (int)theCamera.sensorType;//sky_simulator, force monochrome
            textBoxBayerOffsetX.Text = theCamera.bayerOffsetX.ToString(CultureInfo.CurrentCulture);
            textBoxBayerOffsetY.Text = theCamera.bayerOffsetY.ToString(CultureInfo.CurrentCulture);
            checkBoxOmitOddBins.Checked = theCamera.omitOddBins;

            checkBoxHasCooler.Checked = theCamera.hasCooler;
            checkBoxCanSetCCDTemperature.Checked = theCamera.canSetCcdTemperature;
            checkBoxCanGetCoolerPower.Checked = theCamera.canGetCoolerPower;

            checkBoxCanAbortExposure.Checked = theCamera.canAbortExposure;
            checkBoxCanStopExposure.Checked = theCamera.canStopExposure;
            textBoxMaxExposure.Text = theCamera.exposureMax.ToString(CultureInfo.CurrentCulture);
            textBoxMinExposure.Text = theCamera.exposureMin.ToString(CultureInfo.CurrentCulture);

            checkBoxgaincontrol1.Checked = theCamera.gaincontrol; // mod sky_simulator


            checkBoxCanPulseGuide.Checked = theCamera.canPulseGuide;

            checkBoxCanFastReadout.Checked = theCamera.canFastReadout;
            if (theCamera.canFastReadout)
            {
                checkBoxUseReadoutModes.Enabled = false;
            }
            else
            {
                checkBoxUseReadoutModes.Checked = theCamera.readoutModes.Count > 1;
            }

            camera = theCamera;

        }

        private void SaveProperties()
        {
            Log.Enabled = checkBoxLogging.Checked;
            camera.pixelSizeX = double.Parse(textBoxPixelSizeX.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.pixelSizeY = double.Parse(textBoxPixelSizeY.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            //camera.fullWellCapacity = Convert.ToDouble(textBoxFullWellCapacity.Text, CultureInfo.InvariantCulture);
            camera.maxADU = int.Parse(textBoxMaxADU.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
           // camera.electronsPerADU = double.Parse(textBoxElectronsPerADU.Text, NumberStyles.Number, CultureInfo.CurrentCulture);//mod sky_simulator
            camera.sky_glow = double.Parse(skyglow_textBox1.Text, NumberStyles.Number, CultureInfo.CurrentCulture);//mod sky_simulator
            camera.read_noise = double.Parse(readnoise_textBox1.Text, NumberStyles.Number, CultureInfo.CurrentCulture);//mod sky_simulator


            camera.cameraXSize = int.Parse(textBoxCameraXSize.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.cameraYSize = int.Parse(textBoxCameraYSize.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.canAsymmetricBin = checkBoxCanAsymmetricBin.Checked;
            camera.maxBinX = short.Parse(textBoxMaxBinX.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.maxBinY = short.Parse(textBoxMaxBinY.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.hasShutter = checkBoxHasShutter.Checked;
            camera.sensorName = textBoxSensorName.Text;
            camera.sensorType = (SensorType)comboBoxSensorType.SelectedIndex;
            camera.bayerOffsetX = short.Parse(textBoxBayerOffsetX.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.bayerOffsetY = short.Parse(textBoxBayerOffsetY.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.omitOddBins = checkBoxOmitOddBins.Checked;

            camera.hasCooler = checkBoxHasCooler.Checked;
            camera.canSetCcdTemperature = checkBoxCanSetCCDTemperature.Checked;
            camera.canGetCoolerPower = checkBoxCanGetCoolerPower.Checked;

            camera.canAbortExposure = checkBoxCanAbortExposure.Checked;
            camera.canStopExposure = checkBoxCanStopExposure.Checked;
            camera.exposureMin = double.Parse(textBoxMinExposure.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            camera.exposureMax = double.Parse(textBoxMaxExposure.Text, NumberStyles.Number, CultureInfo.CurrentCulture);
            //camera.applyNoise = checkBoxApplyNoise.Checked; //mod sky_simulator
            camera.gaincontrol = checkBoxgaincontrol1.Checked; //mod sky_simulator

            if (checkBoxgaincontrol1.Checked) // mod sky_simulator
            {
                camera.gainMin = 100;
                camera.gainMax = 1000;
                camera.gains = null;
            }
            else
            {
                camera.gainMin = 100;
                camera.gainMax = 100;
                camera.gains = null;
            }

            camera.canPulseGuide = checkBoxCanPulseGuide.Checked;
            camera.interfaceVersion = (short)(checkBoxInterfaceVersion.Checked ? 2 : 1);

            camera.canFastReadout = checkBoxCanFastReadout.Checked;
            if (checkBoxUseReadoutModes.Checked)
            {
                camera.readoutModes = new ArrayList { "Raw Monochrome", "Live View", "Raw To Hard Drive" };
            }
            else
            {
                camera.readoutModes = new ArrayList { "Default" };
            }
        }

        private void buttonSetImageFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.CheckPathExists = true;
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.InitialDirectory = Path.GetDirectoryName(camera.imagePath);
            openFileDialog1.FileName = Path.GetFileName(camera.imagePath);
            openFileDialog1.ShowDialog();
            camera.imagePath = openFileDialog1.FileName;
        }

        private void checkBoxInterfaceVersion_CheckedChanged(object sender, EventArgs e)
        {
            // enable the V2 properties if checked
            textBoxBayerOffsetX.Enabled = checkBoxInterfaceVersion.Checked;
            textBoxBayerOffsetY.Enabled = checkBoxInterfaceVersion.Checked;
            textBoxMaxExposure.Enabled = checkBoxInterfaceVersion.Checked;
            textBoxMinExposure.Enabled = checkBoxInterfaceVersion.Checked;
            textBoxSensorName.Enabled = checkBoxInterfaceVersion.Checked;
            comboBoxSensorType.Enabled = checkBoxInterfaceVersion.Checked;
        }

        private void checkBoxCanFastReadout_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxUseReadoutModes.Enabled = !(sender as CheckBox).Checked;
        }

        private void comboBoxSensorType_SelectedIndexChanged(object sender, EventArgs e)
        {
            var si = (sender as ComboBox).SelectedItem as string;
            labelBayerOffsetX.Enabled =
                labelBayerOffsetY.Enabled =
                textBoxBayerOffsetX.Enabled =
                textBoxBayerOffsetY.Enabled = (si != "Monochrome" && si != "Color");
        }

        private void checkBoxLogging_CheckedChanged(object sender, EventArgs e)
        {
            Log.Enabled = checkBoxLogging.Checked;
        }

        /// <summary>
        /// Cooler configuration button event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCoolerConfiguration_Click(object sender, EventArgs e)
        {
            // Create and initialise the cooling configuration form
            coolerSetupForm = new CoolerSetupForm(); // Create the cooler configuration form
            coolerSetupForm.InitProperties(camera); // Initialise the form

            coolerSetupForm.ShowDialog(); // Display the form - Any changes will be saved by the form when its OK button is pressed.
            coolerSetupForm.Dispose();
            coolerSetupForm = null;
        }

        private void SetupDialogForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Image file will be read again for each exposure. Image file is unlocked.\n  Grey level is transported logarithmic in 24 bit using a 3x 8 bit PNG file.Decoding \n Greylevel:= -1 + exp((256 * 256 * Red + 256 * Green + Blue) / (189000))   Range 0. . 3.4E38");
        }
    }
}