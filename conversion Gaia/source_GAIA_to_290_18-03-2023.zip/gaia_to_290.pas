program gaia_to_290;

uses
  Forms, Interfaces,
  gaia_to_290unit {Main_form},
  Unit_290 in 'Unit_290.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMain_form, Main_form);
  Application.Run;
end.

