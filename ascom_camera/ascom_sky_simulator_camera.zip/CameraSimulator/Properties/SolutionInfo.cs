﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("HanK")]
[assembly: AssemblyProduct("Sky Simulator ASCOM Camera")]
