
unit Unit_290;

{$MODE Delphi}

interface
var
  tof    : file;
  nr_of_stars           : longint;
  nr_of_skipped         : longint;


type
hnskyhdr290_A7 = packed record {interim record}
             ra7 : byte;
             ra8 : byte;
             ra9 : byte;
             dec7: byte;
             dec8: byte;    {note with word and smallint, delphi makes longer records !!!}
             dec9: shortint;
             Bp_Rp: shortint;{blue minus red magnitude}
   end;

hnskyhdr290_A6 = packed record {interim record}
             ra7 : byte;
             ra8 : byte;
             ra9 : byte;
             dec7: byte;
             dec8: byte;    {note with word and smallint, delphi makes longer records !!!}
             dec9: shortint;
   end;
hnskyhdr290_5 = packed record
             ra7 : byte;
             ra8 : byte;
             ra9 : byte;
             dec7: byte;
             dec8: byte;    {note with word and smallint, delphi makes longer records !!!}
   end;

hnskyhdr290_6 = packed record
             ra7 : byte;
             ra8 : byte;
             ra9 : byte;
             dec7: byte;
             dec8: byte;    {note with word and smallint, delphi makes longer records !!!}
             Bp_Rp: shortint;{blue minus red magnitude}
   end;



var
   Numwritten                  : integer;
   new_magnitude_record_written : array[1..1801] of integer;{keep record if new magnitude step record is written to file for 6 byte records}

function limit_radialen(z:double):double;

function name290(ra,dec:real): string; {give segment name}

const
filenames290 : array[1..290] of string= {}
(('0101.290'),

 ('0201.290'),  {combined cells from 8}
 ('0202.290'),
 ('0203.290'),
 ('0204.290'),

 ('0301.290'),
 ('0302.290'),
 ('0303.290'),
 ('0304.290'),
 ('0305.290'),
 ('0306.290'),
 ('0307.290'),
 ('0308.290'),

 ('0401.290'),
 ('0402.290'),
 ('0403.290'),
 ('0404.290'),
 ('0405.290'),
 ('0406.290'),
 ('0407.290'),
 ('0408.290'),
 ('0409.290'),
 ('0410.290'),
 ('0411.290'),
 ('0412.290'),

 ('0501.290'),
 ('0502.290'),
 ('0503.290'),
 ('0504.290'),
 ('0505.290'),
 ('0506.290'),
 ('0507.290'),
 ('0508.290'),
 ('0509.290'),
 ('0510.290'),
 ('0511.290'),
 ('0512.290'),
 ('0513.290'),
 ('0514.290'),
 ('0515.290'),
 ('0516.290'),

 ('0601.290'),
 ('0602.290'),
 ('0603.290'),
 ('0604.290'),
 ('0605.290'),
 ('0606.290'),
 ('0607.290'),
 ('0608.290'),
 ('0609.290'),
 ('0610.290'),
 ('0611.290'),
 ('0612.290'),
 ('0613.290'),
 ('0614.290'),
 ('0615.290'),
 ('0616.290'),
 ('0617.290'),
 ('0618.290'),
 ('0619.290'),
 ('0620.290'),

 ('0701.290'),
 ('0702.290'),
 ('0703.290'),
 ('0704.290'),
 ('0705.290'),
 ('0706.290'),
 ('0707.290'),
 ('0708.290'),
 ('0709.290'),
 ('0710.290'),
 ('0711.290'),
 ('0712.290'),
 ('0713.290'),
 ('0714.290'),
 ('0715.290'),
 ('0716.290'),
 ('0717.290'),
 ('0718.290'),
 ('0719.290'),
 ('0720.290'),
 ('0721.290'),
 ('0722.290'),
 ('0723.290'),
 ('0724.290'),

 ('0801.290'),
 ('0802.290'),
 ('0803.290'),
 ('0804.290'),
 ('0805.290'),
 ('0806.290'),
 ('0807.290'),
 ('0808.290'),
 ('0809.290'),
 ('0810.290'),
 ('0811.290'),
 ('0812.290'),
 ('0813.290'),
 ('0814.290'),
 ('0815.290'),
 ('0816.290'),
 ('0817.290'),
 ('0818.290'),
 ('0819.290'),
 ('0820.290'),
 ('0821.290'),
 ('0822.290'),
 ('0823.290'),
 ('0824.290'),
 ('0825.290'),
 ('0826.290'),
 ('0827.290'),
 ('0828.290'),

 ('0901.290'),
 ('0902.290'),
 ('0903.290'),
 ('0904.290'),
 ('0905.290'),
 ('0906.290'),
 ('0907.290'),
 ('0908.290'),
 ('0909.290'),
 ('0910.290'),
 ('0911.290'),
 ('0912.290'),
 ('0913.290'),
 ('0914.290'),
 ('0915.290'),
 ('0916.290'),
 ('0917.290'),
 ('0918.290'),
 ('0919.290'),
 ('0920.290'),
 ('0921.290'),
 ('0922.290'),
 ('0923.290'),
 ('0924.290'),
 ('0925.290'),
 ('0926.290'),
 ('0927.290'),
 ('0928.290'),
 ('0929.290'),
 ('0930.290'),
 ('0931.290'),
 ('0932.290'),

 ('1001.290'),
 ('1002.290'),
 ('1003.290'),
 ('1004.290'),
 ('1005.290'),
 ('1006.290'),
 ('1007.290'),
 ('1008.290'),
 ('1009.290'),
 ('1010.290'),
 ('1011.290'),
 ('1012.290'),
 ('1013.290'),
 ('1014.290'),
 ('1015.290'),
 ('1016.290'),
 ('1017.290'),
 ('1018.290'),
 ('1019.290'),
 ('1020.290'),
 ('1021.290'),
 ('1022.290'),
 ('1023.290'),
 ('1024.290'),
 ('1025.290'),
 ('1026.290'),
 ('1027.290'),
 ('1028.290'),
 ('1029.290'),
 ('1030.290'),
 ('1031.290'),
 ('1032.290'),

 ('1101.290'),
 ('1102.290'),
 ('1103.290'),
 ('1104.290'),
 ('1105.290'),
 ('1106.290'),
 ('1107.290'),
 ('1108.290'),
 ('1109.290'),
 ('1110.290'),
 ('1111.290'),
 ('1112.290'),
 ('1113.290'),
 ('1114.290'),
 ('1115.290'),
 ('1116.290'),
 ('1117.290'),
 ('1118.290'),
 ('1119.290'),
 ('1120.290'),
 ('1121.290'),
 ('1122.290'),
 ('1123.290'),
 ('1124.290'),
 ('1125.290'),
 ('1126.290'),
 ('1127.290'),
 ('1128.290'),

 ('1201.290'),
 ('1202.290'),
 ('1203.290'),
 ('1204.290'),
 ('1205.290'),
 ('1206.290'),
 ('1207.290'),
 ('1208.290'),
 ('1209.290'),
 ('1210.290'),
 ('1211.290'),
 ('1212.290'),
 ('1213.290'),
 ('1214.290'),
 ('1215.290'),
 ('1216.290'),
 ('1217.290'),
 ('1218.290'),
 ('1219.290'),
 ('1220.290'),
 ('1221.290'),
 ('1222.290'),
 ('1223.290'),
 ('1224.290'),

 ('1301.290'),
 ('1302.290'),
 ('1303.290'),
 ('1304.290'),
 ('1305.290'),
 ('1306.290'),
 ('1307.290'),
 ('1308.290'),
 ('1309.290'),
 ('1310.290'),
 ('1311.290'),
 ('1312.290'),
 ('1313.290'),
 ('1314.290'),
 ('1315.290'),
 ('1316.290'),
 ('1317.290'),
 ('1318.290'),
 ('1319.290'),
 ('1320.290'),

  ('1401.290'),
 ('1402.290'),
 ('1403.290'),
 ('1404.290'),
 ('1405.290'),
 ('1406.290'),
 ('1407.290'),
 ('1408.290'),
 ('1409.290'),
 ('1410.290'),
 ('1411.290'),
 ('1412.290'),
 ('1413.290'),
 ('1414.290'),
 ('1415.290'),
 ('1416.290'),

 ('1501.290'),
 ('1502.290'),
 ('1503.290'),
 ('1504.290'),
 ('1505.290'),
 ('1506.290'),
 ('1507.290'),
 ('1508.290'),
 ('1509.290'),
 ('1510.290'),
 ('1511.290'),
 ('1512.290'),

 ('1601.290'),
 ('1602.290'),
 ('1603.290'),
 ('1604.290'),
 ('1605.290'),
 ('1606.290'),
 ('1607.290'),
 ('1608.290'),

 ('1701.290'),
 ('1702.290'),
 ('1703.290'),
 ('1704.290'),

 ('1801.290'));


const
ring0=-90*pi/180;
ring1=-85.23224404*pi/180;
ring2=-75.66348756*pi/180;
ring3=-65.99286637*pi/180;
ring4=-56.14497387*pi/180;
ring5=-46.03163067*pi/180;
ring6=-35.54307745*pi/180;
ring7=-24.53348115*pi/180;
ring8=-12.79440589*pi/180;
ring9=  0;
ring10=12.79440589*pi/180;
ring11=24.53348115*pi/180;
ring12=35.54307745*pi/180;
ring13=46.03163067*pi/180;
ring14=56.14497387*pi/180;
ring15=65.99286637*pi/180;
ring16=75.66348756*pi/180;
ring17=85.23224404*pi/180;
ring18=90*pi/180;



centers290 : array[1..290,1..6] of real= {divide sky in 290 area's in bands of constant DEC}
     {ra_center, dec_center, ra_min    ,ra_max, dec_min, dec_max}
    (( 0       , ring0          ,  0        ,pi         ,ring0,ring1),  {1  south pole    }

    (0.5/4*2*pi, (ring1+ring2)/2, 0.0/4*2*pi, 1.0/4*2*pi,ring1,ring2),  {4 circle segments. Keep the min dimension around 5 degrees resulting in three segments}
    (1.5/4*2*pi, (ring1+ring2)/2, 1.0/4*2*pi, 2.0/4*2*pi,ring1,ring2),  {4 circle segments}
    (2.5/4*2*pi, (ring1+ring2)/2, 2.0/4*2*pi, 3.0/4*2*pi,ring1,ring2),  {4 circle segments}
    (3.5/4*2*pi, (ring1+ring2)/2, 3.0/4*2*pi, 4.0/4*2*pi,ring1,ring2),  {4 circle segments}

    (0.5/8*2*pi, (ring2+ring3)/2, 0.0/8*2*pi, 1.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (1.5/8*2*pi, (ring2+ring3)/2, 1.0/8*2*pi, 2.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (2.5/8*2*pi, (ring2+ring3)/2, 2.0/8*2*pi, 3.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (3.5/8*2*pi, (ring2+ring3)/2, 3.0/8*2*pi, 4.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (4.5/8*2*pi, (ring2+ring3)/2, 4.0/8*2*pi, 5.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (5.5/8*2*pi, (ring2+ring3)/2, 5.0/8*2*pi, 6.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (6.5/8*2*pi, (ring2+ring3)/2, 6.0/8*2*pi, 7.0/8*2*pi,ring2,ring3),  {8 circle segments}
    (7.5/8*2*pi, (ring2+ring3)/2, 7.0/8*2*pi, 8.0/8*2*pi,ring2,ring3),  {8 circle segments}


    (0.5/12*2*pi, (ring3+ring4)/2, 0.0/12*2*pi, 1.0/12*2*pi,ring3,ring4),
    (1.5/12*2*pi, (ring3+ring4)/2, 1.0/12*2*pi, 2.0/12*2*pi,ring3,ring4),
    (2.5/12*2*pi, (ring3+ring4)/2, 2.0/12*2*pi, 3.0/12*2*pi,ring3,ring4),
    (3.5/12*2*pi, (ring3+ring4)/2, 3.0/12*2*pi, 4.0/12*2*pi,ring3,ring4),
    (4.5/12*2*pi, (ring3+ring4)/2, 4.0/12*2*pi, 5.0/12*2*pi,ring3,ring4),
    (5.5/12*2*pi, (ring3+ring4)/2, 5.0/12*2*pi, 6.0/12*2*pi,ring3,ring4),
    (6.5/12*2*pi, (ring3+ring4)/2, 6.0/12*2*pi, 7.0/12*2*pi,ring3,ring4),
    (7.5/12*2*pi, (ring3+ring4)/2, 7.0/12*2*pi, 8.0/12*2*pi,ring3,ring4),
    (8.5/12*2*pi, (ring3+ring4)/2, 8.0/12*2*pi, 9.0/12*2*pi,ring3,ring4),
    (9.5/12*2*pi, (ring3+ring4)/2, 9.0/12*2*pi, 10.0/12*2*pi,ring3,ring4),
    (10.5/12*2*pi, (ring3+ring4)/2, 10.0/12*2*pi, 11.0/12*2*pi,ring3,ring4),
    (11.5/12*2*pi, (ring3+ring4)/2, 11.0/12*2*pi, 12.0/12*2*pi,ring3,ring4),


    (0.5/16*2*pi, (ring4+ring5)/2, 0.0/16*2*pi, 1.0/16*2*pi,ring4,ring5),
    (1.5/16*2*pi, (ring4+ring5)/2, 1.0/16*2*pi, 2.0/16*2*pi,ring4,ring5),
    (2.5/16*2*pi, (ring4+ring5)/2, 2.0/16*2*pi, 3.0/16*2*pi,ring4,ring5),
    (3.5/16*2*pi, (ring4+ring5)/2, 3.0/16*2*pi, 4.0/16*2*pi,ring4,ring5),
    (4.5/16*2*pi, (ring4+ring5)/2, 4.0/16*2*pi, 5.0/16*2*pi,ring4,ring5),
    (5.5/16*2*pi, (ring4+ring5)/2, 5.0/16*2*pi, 6.0/16*2*pi,ring4,ring5),
    (6.5/16*2*pi, (ring4+ring5)/2, 6.0/16*2*pi, 7.0/16*2*pi,ring4,ring5),
    (7.5/16*2*pi, (ring4+ring5)/2, 7.0/16*2*pi, 8.0/16*2*pi,ring4,ring5),
    (8.5/16*2*pi, (ring4+ring5)/2, 8.0/16*2*pi, 9.0/16*2*pi,ring4,ring5),
    (9.5/16*2*pi, (ring4+ring5)/2, 9.0/16*2*pi, 10.0/16*2*pi,ring4,ring5),
    (10.5/16*2*pi, (ring4+ring5)/2, 10.0/16*2*pi, 11.0/16*2*pi,ring4,ring5),
    (11.5/16*2*pi, (ring4+ring5)/2, 11.0/16*2*pi, 12.0/16*2*pi,ring4,ring5),
    (12.5/16*2*pi, (ring4+ring5)/2, 12.0/16*2*pi, 13.0/16*2*pi,ring4,ring5),
    (13.5/16*2*pi, (ring4+ring5)/2, 13.0/16*2*pi, 14.0/16*2*pi,ring4,ring5),
    (14.5/16*2*pi, (ring4+ring5)/2, 14.0/16*2*pi, 15.0/16*2*pi,ring4,ring5),
    (15.5/16*2*pi, (ring4+ring5)/2, 15.0/16*2*pi, 16.0/16*2*pi,ring4,ring5),


    (0.5/20*2*pi, (ring5+ring6)/2, 0.0/20*2*pi, 1.0/20*2*pi,ring5,ring6),
    (1.5/20*2*pi, (ring5+ring6)/2, 1.0/20*2*pi, 2.0/20*2*pi,ring5,ring6),
    (2.5/20*2*pi, (ring5+ring6)/2, 2.0/20*2*pi, 3.0/20*2*pi,ring5,ring6),
    (3.5/20*2*pi, (ring5+ring6)/2, 3.0/20*2*pi, 4.0/20*2*pi,ring5,ring6),
    (4.5/20*2*pi, (ring5+ring6)/2, 4.0/20*2*pi, 5.0/20*2*pi,ring5,ring6),
    (5.5/20*2*pi, (ring5+ring6)/2, 5.0/20*2*pi, 6.0/20*2*pi,ring5,ring6),
    (6.5/20*2*pi, (ring5+ring6)/2, 6.0/20*2*pi, 7.0/20*2*pi,ring5,ring6),
    (7.5/20*2*pi, (ring5+ring6)/2, 7.0/20*2*pi, 8.0/20*2*pi,ring5,ring6),
    (8.5/20*2*pi, (ring5+ring6)/2, 8.0/20*2*pi, 9.0/20*2*pi,ring5,ring6),
    (9.5/20*2*pi, (ring5+ring6)/2, 9.0/20*2*pi, 10.0/20*2*pi,ring5,ring6),
    (10.5/20*2*pi, (ring5+ring6)/2, 10.0/20*2*pi, 11.0/20*2*pi,ring5,ring6),
    (11.5/20*2*pi, (ring5+ring6)/2, 11.0/20*2*pi, 12.0/20*2*pi,ring5,ring6),
    (12.5/20*2*pi, (ring5+ring6)/2, 12.0/20*2*pi, 13.0/20*2*pi,ring5,ring6),
    (13.5/20*2*pi, (ring5+ring6)/2, 13.0/20*2*pi, 14.0/20*2*pi,ring5,ring6),
    (14.5/20*2*pi, (ring5+ring6)/2, 14.0/20*2*pi, 15.0/20*2*pi,ring5,ring6),
    (15.5/20*2*pi, (ring5+ring6)/2, 15.0/20*2*pi, 16.0/20*2*pi,ring5,ring6),
    (16.5/20*2*pi, (ring5+ring6)/2, 16.0/20*2*pi, 17.0/20*2*pi,ring5,ring6),
    (17.5/20*2*pi, (ring5+ring6)/2, 17.0/20*2*pi, 18.0/20*2*pi,ring5,ring6),
    (18.5/20*2*pi, (ring5+ring6)/2, 18.0/20*2*pi, 19.0/20*2*pi,ring5,ring6),
    (19.5/20*2*pi, (ring5+ring6)/2, 19.0/20*2*pi, 20.0/20*2*pi,ring5,ring6),



    (0.5/24*2*pi, (ring6+ring7)/2, 0.0/24*2*pi, 1.0/24*2*pi,ring6,ring7),
    (1.5/24*2*pi, (ring6+ring7)/2, 1.0/24*2*pi, 2.0/24*2*pi,ring6,ring7),
    (2.5/24*2*pi, (ring6+ring7)/2, 2.0/24*2*pi, 3.0/24*2*pi,ring6,ring7),
    (3.5/24*2*pi, (ring6+ring7)/2, 3.0/24*2*pi, 4.0/24*2*pi,ring6,ring7),
    (4.5/24*2*pi, (ring6+ring7)/2, 4.0/24*2*pi, 5.0/24*2*pi,ring6,ring7),
    (5.5/24*2*pi, (ring6+ring7)/2, 5.0/24*2*pi, 6.0/24*2*pi,ring6,ring7),
    (6.5/24*2*pi, (ring6+ring7)/2, 6.0/24*2*pi, 7.0/24*2*pi,ring6,ring7),
    (7.5/24*2*pi, (ring6+ring7)/2, 7.0/24*2*pi, 8.0/24*2*pi,ring6,ring7),
    (8.5/24*2*pi, (ring6+ring7)/2, 8.0/24*2*pi, 9.0/24*2*pi,ring6,ring7),
    (9.5/24*2*pi, (ring6+ring7)/2, 9.0/24*2*pi, 10.0/24*2*pi,ring6,ring7),
    (10.5/24*2*pi, (ring6+ring7)/2, 10.0/24*2*pi, 11.0/24*2*pi,ring6,ring7),
    (11.5/24*2*pi, (ring6+ring7)/2, 11.0/24*2*pi, 12.0/24*2*pi,ring6,ring7),
    (12.5/24*2*pi, (ring6+ring7)/2, 12.0/24*2*pi, 13.0/24*2*pi,ring6,ring7),
    (13.5/24*2*pi, (ring6+ring7)/2, 13.0/24*2*pi, 14.0/24*2*pi,ring6,ring7),
    (14.5/24*2*pi, (ring6+ring7)/2, 14.0/24*2*pi, 15.0/24*2*pi,ring6,ring7),
    (15.5/24*2*pi, (ring6+ring7)/2, 15.0/24*2*pi, 16.0/24*2*pi,ring6,ring7),
    (16.5/24*2*pi, (ring6+ring7)/2, 16.0/24*2*pi, 17.0/24*2*pi,ring6,ring7),
    (17.5/24*2*pi, (ring6+ring7)/2, 17.0/24*2*pi, 18.0/24*2*pi,ring6,ring7),
    (18.5/24*2*pi, (ring6+ring7)/2, 18.0/24*2*pi, 19.0/24*2*pi,ring6,ring7),
    (19.5/24*2*pi, (ring6+ring7)/2, 19.0/24*2*pi, 20.0/24*2*pi,ring6,ring7),
    (20.5/24*2*pi, (ring6+ring7)/2, 20.0/24*2*pi, 21.0/24*2*pi,ring6,ring7),
    (21.5/24*2*pi, (ring6+ring7)/2, 21.0/24*2*pi, 22.0/24*2*pi,ring6,ring7),
    (22.5/24*2*pi, (ring6+ring7)/2, 22.0/24*2*pi, 23.0/24*2*pi,ring6,ring7),
    (23.5/24*2*pi, (ring6+ring7)/2, 23.0/24*2*pi, 24.0/24*2*pi,ring6,ring7),


    (0.5/28*2*pi, (ring7+ring8)/2, 0.0/28*2*pi, 1.0/28*2*pi,ring7,ring8),
    (1.5/28*2*pi, (ring7+ring8)/2, 1.0/28*2*pi, 2.0/28*2*pi,ring7,ring8),
    (2.5/28*2*pi, (ring7+ring8)/2, 2.0/28*2*pi, 3.0/28*2*pi,ring7,ring8),
    (3.5/28*2*pi, (ring7+ring8)/2, 3.0/28*2*pi, 4.0/28*2*pi,ring7,ring8),
    (4.5/28*2*pi, (ring7+ring8)/2, 4.0/28*2*pi, 5.0/28*2*pi,ring7,ring8),
    (5.5/28*2*pi, (ring7+ring8)/2, 5.0/28*2*pi, 6.0/28*2*pi,ring7,ring8),
    (6.5/28*2*pi, (ring7+ring8)/2, 6.0/28*2*pi, 7.0/28*2*pi,ring7,ring8),
    (7.5/28*2*pi, (ring7+ring8)/2, 7.0/28*2*pi, 8.0/28*2*pi,ring7,ring8),
    (8.5/28*2*pi, (ring7+ring8)/2, 8.0/28*2*pi, 9.0/28*2*pi,ring7,ring8),
    (9.5/28*2*pi, (ring7+ring8)/2, 9.0/28*2*pi, 10.0/28*2*pi,ring7,ring8),
    (10.5/28*2*pi, (ring7+ring8)/2, 10.0/28*2*pi, 11.0/28*2*pi,ring7,ring8),
    (11.5/28*2*pi, (ring7+ring8)/2, 11.0/28*2*pi, 12.0/28*2*pi,ring7,ring8),
    (12.5/28*2*pi, (ring7+ring8)/2, 12.0/28*2*pi, 13.0/28*2*pi,ring7,ring8),
    (13.5/28*2*pi, (ring7+ring8)/2, 13.0/28*2*pi, 14.0/28*2*pi,ring7,ring8),
    (14.5/28*2*pi, (ring7+ring8)/2, 14.0/28*2*pi, 15.0/28*2*pi,ring7,ring8),
    (15.5/28*2*pi, (ring7+ring8)/2, 15.0/28*2*pi, 16.0/28*2*pi,ring7,ring8),
    (16.5/28*2*pi, (ring7+ring8)/2, 16.0/28*2*pi, 17.0/28*2*pi,ring7,ring8),
    (17.5/28*2*pi, (ring7+ring8)/2, 17.0/28*2*pi, 18.0/28*2*pi,ring7,ring8),
    (18.5/28*2*pi, (ring7+ring8)/2, 18.0/28*2*pi, 19.0/28*2*pi,ring7,ring8),
    (19.5/28*2*pi, (ring7+ring8)/2, 19.0/28*2*pi, 20.0/28*2*pi,ring7,ring8),
    (20.5/28*2*pi, (ring7+ring8)/2, 20.0/28*2*pi, 21.0/28*2*pi,ring7,ring8),
    (21.5/28*2*pi, (ring7+ring8)/2, 21.0/28*2*pi, 22.0/28*2*pi,ring7,ring8),
    (22.5/28*2*pi, (ring7+ring8)/2, 22.0/28*2*pi, 23.0/28*2*pi,ring7,ring8),
    (23.5/28*2*pi, (ring7+ring8)/2, 23.0/28*2*pi, 24.0/28*2*pi,ring7,ring8),
    (24.5/28*2*pi, (ring7+ring8)/2, 24.0/28*2*pi, 25.0/28*2*pi,ring7,ring8),
    (25.5/28*2*pi, (ring7+ring8)/2, 25.0/28*2*pi, 26.0/28*2*pi,ring7,ring8),
    (26.5/28*2*pi, (ring7+ring8)/2, 26.0/28*2*pi, 27.0/28*2*pi,ring7,ring8),
    (27.5/28*2*pi, (ring7+ring8)/2, 27.0/28*2*pi, 28.0/28*2*pi,ring7,ring8),

    (0.5/32*2*pi, (ring8+ring9)/2, 0.0/32*2*pi, 1.0/32*2*pi,ring8,ring9),
    (1.5/32*2*pi, (ring8+ring9)/2, 1.0/32*2*pi, 2.0/32*2*pi,ring8,ring9),
    (2.5/32*2*pi, (ring8+ring9)/2, 2.0/32*2*pi, 3.0/32*2*pi,ring8,ring9),
    (3.5/32*2*pi, (ring8+ring9)/2, 3.0/32*2*pi, 4.0/32*2*pi,ring8,ring9),
    (4.5/32*2*pi, (ring8+ring9)/2, 4.0/32*2*pi, 5.0/32*2*pi,ring8,ring9),
    (5.5/32*2*pi, (ring8+ring9)/2, 5.0/32*2*pi, 6.0/32*2*pi,ring8,ring9),
    (6.5/32*2*pi, (ring8+ring9)/2, 6.0/32*2*pi, 7.0/32*2*pi,ring8,ring9),
    (7.5/32*2*pi, (ring8+ring9)/2, 7.0/32*2*pi, 8.0/32*2*pi,ring8,ring9),
    (8.5/32*2*pi, (ring8+ring9)/2, 8.0/32*2*pi, 9.0/32*2*pi,ring8,ring9),
    (9.5/32*2*pi, (ring8+ring9)/2, 9.0/32*2*pi, 10.0/32*2*pi,ring8,ring9),
    (10.5/32*2*pi, (ring8+ring9)/2, 10.0/32*2*pi, 11.0/32*2*pi,ring8,ring9),
    (11.5/32*2*pi, (ring8+ring9)/2, 11.0/32*2*pi, 12.0/32*2*pi,ring8,ring9),
    (12.5/32*2*pi, (ring8+ring9)/2, 12.0/32*2*pi, 13.0/32*2*pi,ring8,ring9),
    (13.5/32*2*pi, (ring8+ring9)/2, 13.0/32*2*pi, 14.0/32*2*pi,ring8,ring9),
    (14.5/32*2*pi, (ring8+ring9)/2, 14.0/32*2*pi, 15.0/32*2*pi,ring8,ring9),
    (15.5/32*2*pi, (ring8+ring9)/2, 15.0/32*2*pi, 16.0/32*2*pi,ring8,ring9),
    (16.5/32*2*pi, (ring8+ring9)/2, 16.0/32*2*pi, 17.0/32*2*pi,ring8,ring9),
    (17.5/32*2*pi, (ring8+ring9)/2, 17.0/32*2*pi, 18.0/32*2*pi,ring8,ring9),
    (18.5/32*2*pi, (ring8+ring9)/2, 18.0/32*2*pi, 19.0/32*2*pi,ring8,ring9),
    (19.5/32*2*pi, (ring8+ring9)/2, 19.0/32*2*pi, 20.0/32*2*pi,ring8,ring9),
    (20.5/32*2*pi, (ring8+ring9)/2, 20.0/32*2*pi, 21.0/32*2*pi,ring8,ring9),
    (21.5/32*2*pi, (ring8+ring9)/2, 21.0/32*2*pi, 22.0/32*2*pi,ring8,ring9),
    (22.5/32*2*pi, (ring8+ring9)/2, 22.0/32*2*pi, 23.0/32*2*pi,ring8,ring9),
    (23.5/32*2*pi, (ring8+ring9)/2, 23.0/32*2*pi, 24.0/32*2*pi,ring8,ring9),
    (24.5/32*2*pi, (ring8+ring9)/2, 24.0/32*2*pi, 25.0/32*2*pi,ring8,ring9),
    (25.5/32*2*pi, (ring8+ring9)/2, 25.0/32*2*pi, 26.0/32*2*pi,ring8,ring9),
    (26.5/32*2*pi, (ring8+ring9)/2, 26.0/32*2*pi, 27.0/32*2*pi,ring8,ring9),
    (27.5/32*2*pi, (ring8+ring9)/2, 27.0/32*2*pi, 28.0/32*2*pi,ring8,ring9),
    (28.5/32*2*pi, (ring8+ring9)/2, 28.0/32*2*pi, 29.0/32*2*pi,ring8,ring9),
    (29.5/32*2*pi, (ring8+ring9)/2, 29.0/32*2*pi, 30.0/32*2*pi,ring8,ring9),
    (30.5/32*2*pi, (ring8+ring9)/2, 30.0/32*2*pi, 31.0/32*2*pi,ring8,ring9),
    (31.5/32*2*pi, (ring8+ring9)/2, 31.0/32*2*pi, 32.0/32*2*pi,ring8,ring9),


    (0.5/32*2*pi, (ring9+ring10)/2, 0.0/32*2*pi, 1.0/32*2*pi,ring9,ring10),
    (1.5/32*2*pi, (ring9+ring10)/2, 1.0/32*2*pi, 2.0/32*2*pi,ring9,ring10),
    (2.5/32*2*pi, (ring9+ring10)/2, 2.0/32*2*pi, 3.0/32*2*pi,ring9,ring10),
    (3.5/32*2*pi, (ring9+ring10)/2, 3.0/32*2*pi, 4.0/32*2*pi,ring9,ring10),
    (4.5/32*2*pi, (ring9+ring10)/2, 4.0/32*2*pi, 5.0/32*2*pi,ring9,ring10),
    (5.5/32*2*pi, (ring9+ring10)/2, 5.0/32*2*pi, 6.0/32*2*pi,ring9,ring10),
    (6.5/32*2*pi, (ring9+ring10)/2, 6.0/32*2*pi, 7.0/32*2*pi,ring9,ring10),
    (7.5/32*2*pi, (ring9+ring10)/2, 7.0/32*2*pi, 8.0/32*2*pi,ring9,ring10),
    (8.5/32*2*pi, (ring9+ring10)/2, 8.0/32*2*pi, 9.0/32*2*pi,ring9,ring10),
    (9.5/32*2*pi, (ring9+ring10)/2, 9.0/32*2*pi, 10.0/32*2*pi,ring9,ring10),
    (10.5/32*2*pi, (ring9+ring10)/2, 10.0/32*2*pi, 11.0/32*2*pi,ring9,ring10),
    (11.5/32*2*pi, (ring9+ring10)/2, 11.0/32*2*pi, 12.0/32*2*pi,ring9,ring10),
    (12.5/32*2*pi, (ring9+ring10)/2, 12.0/32*2*pi, 13.0/32*2*pi,ring9,ring10),
    (13.5/32*2*pi, (ring9+ring10)/2, 13.0/32*2*pi, 14.0/32*2*pi,ring9,ring10),
    (14.5/32*2*pi, (ring9+ring10)/2, 14.0/32*2*pi, 15.0/32*2*pi,ring9,ring10),
    (15.5/32*2*pi, (ring9+ring10)/2, 15.0/32*2*pi, 16.0/32*2*pi,ring9,ring10),
    (16.5/32*2*pi, (ring9+ring10)/2, 16.0/32*2*pi, 17.0/32*2*pi,ring9,ring10),
    (17.5/32*2*pi, (ring9+ring10)/2, 17.0/32*2*pi, 18.0/32*2*pi,ring9,ring10),
    (18.5/32*2*pi, (ring9+ring10)/2, 18.0/32*2*pi, 19.0/32*2*pi,ring9,ring10),
    (19.5/32*2*pi, (ring9+ring10)/2, 19.0/32*2*pi, 20.0/32*2*pi,ring9,ring10),
    (20.5/32*2*pi, (ring9+ring10)/2, 20.0/32*2*pi, 21.0/32*2*pi,ring9,ring10),
    (21.5/32*2*pi, (ring9+ring10)/2, 21.0/32*2*pi, 22.0/32*2*pi,ring9,ring10),
    (22.5/32*2*pi, (ring9+ring10)/2, 22.0/32*2*pi, 23.0/32*2*pi,ring9,ring10),
    (23.5/32*2*pi, (ring9+ring10)/2, 23.0/32*2*pi, 24.0/32*2*pi,ring9,ring10),
    (24.5/32*2*pi, (ring9+ring10)/2, 24.0/32*2*pi, 25.0/32*2*pi,ring9,ring10),
    (25.5/32*2*pi, (ring9+ring10)/2, 25.0/32*2*pi, 26.0/32*2*pi,ring9,ring10),
    (26.5/32*2*pi, (ring9+ring10)/2, 26.0/32*2*pi, 27.0/32*2*pi,ring9,ring10),
    (27.5/32*2*pi, (ring9+ring10)/2, 27.0/32*2*pi, 28.0/32*2*pi,ring9,ring10),
    (28.5/32*2*pi, (ring9+ring10)/2, 28.0/32*2*pi, 29.0/32*2*pi,ring9,ring10),
    (29.5/32*2*pi, (ring9+ring10)/2, 29.0/32*2*pi, 30.0/32*2*pi,ring9,ring10),
    (30.5/32*2*pi, (ring9+ring10)/2, 30.0/32*2*pi, 31.0/32*2*pi,ring9,ring10),
    (31.5/32*2*pi, (ring9+ring10)/2, 31.0/32*2*pi, 32.0/32*2*pi,ring9,ring10),



    (0.5/28*2*pi, (ring10+ring11)/2, 0.0/28*2*pi, 1.0/28*2*pi,ring10,ring11),
    (1.5/28*2*pi, (ring10+ring11)/2, 1.0/28*2*pi, 2.0/28*2*pi,ring10,ring11),
    (2.5/28*2*pi, (ring10+ring11)/2, 2.0/28*2*pi, 3.0/28*2*pi,ring10,ring11),
    (3.5/28*2*pi, (ring10+ring11)/2, 3.0/28*2*pi, 4.0/28*2*pi,ring10,ring11),
    (4.5/28*2*pi, (ring10+ring11)/2, 4.0/28*2*pi, 5.0/28*2*pi,ring10,ring11),
    (5.5/28*2*pi, (ring10+ring11)/2, 5.0/28*2*pi, 6.0/28*2*pi,ring10,ring11),
    (6.5/28*2*pi, (ring10+ring11)/2, 6.0/28*2*pi, 7.0/28*2*pi,ring10,ring11),
    (7.5/28*2*pi, (ring10+ring11)/2, 7.0/28*2*pi, 8.0/28*2*pi,ring10,ring11),
    (8.5/28*2*pi, (ring10+ring11)/2, 8.0/28*2*pi, 9.0/28*2*pi,ring10,ring11),
    (9.5/28*2*pi, (ring10+ring11)/2, 9.0/28*2*pi, 10.0/28*2*pi,ring10,ring11),
    (10.5/28*2*pi, (ring10+ring11)/2, 10.0/28*2*pi, 11.0/28*2*pi,ring10,ring11),
    (11.5/28*2*pi, (ring10+ring11)/2, 11.0/28*2*pi, 12.0/28*2*pi,ring10,ring11),
    (12.5/28*2*pi, (ring10+ring11)/2, 12.0/28*2*pi, 13.0/28*2*pi,ring10,ring11),
    (13.5/28*2*pi, (ring10+ring11)/2, 13.0/28*2*pi, 14.0/28*2*pi,ring10,ring11),
    (14.5/28*2*pi, (ring10+ring11)/2, 14.0/28*2*pi, 15.0/28*2*pi,ring10,ring11),
    (15.5/28*2*pi, (ring10+ring11)/2, 15.0/28*2*pi, 16.0/28*2*pi,ring10,ring11),
    (16.5/28*2*pi, (ring10+ring11)/2, 16.0/28*2*pi, 17.0/28*2*pi,ring10,ring11),
    (17.5/28*2*pi, (ring10+ring11)/2, 17.0/28*2*pi, 18.0/28*2*pi,ring10,ring11),
    (18.5/28*2*pi, (ring10+ring11)/2, 18.0/28*2*pi, 19.0/28*2*pi,ring10,ring11),
    (19.5/28*2*pi, (ring10+ring11)/2, 19.0/28*2*pi, 20.0/28*2*pi,ring10,ring11),
    (20.5/28*2*pi, (ring10+ring11)/2, 20.0/28*2*pi, 21.0/28*2*pi,ring10,ring11),
    (21.5/28*2*pi, (ring10+ring11)/2, 21.0/28*2*pi, 22.0/28*2*pi,ring10,ring11),
    (22.5/28*2*pi, (ring10+ring11)/2, 22.0/28*2*pi, 23.0/28*2*pi,ring10,ring11),
    (23.5/28*2*pi, (ring10+ring11)/2, 23.0/28*2*pi, 24.0/28*2*pi,ring10,ring11),
    (24.5/28*2*pi, (ring10+ring11)/2, 24.0/28*2*pi, 25.0/28*2*pi,ring10,ring11),
    (25.5/28*2*pi, (ring10+ring11)/2, 25.0/28*2*pi, 26.0/28*2*pi,ring10,ring11),
    (26.5/28*2*pi, (ring10+ring11)/2, 26.0/28*2*pi, 27.0/28*2*pi,ring10,ring11),
    (27.5/28*2*pi, (ring10+ring11)/2, 27.0/28*2*pi, 28.0/28*2*pi,ring10,ring11),



    (0.5/24*2*pi, (ring11+ring12)/2, 0.0/24*2*pi, 1.0/24*2*pi,ring11,ring12),
    (1.5/24*2*pi, (ring11+ring12)/2, 1.0/24*2*pi, 2.0/24*2*pi,ring11,ring12),
    (2.5/24*2*pi, (ring11+ring12)/2, 2.0/24*2*pi, 3.0/24*2*pi,ring11,ring12),
    (3.5/24*2*pi, (ring11+ring12)/2, 3.0/24*2*pi, 4.0/24*2*pi,ring11,ring12),
    (4.5/24*2*pi, (ring11+ring12)/2, 4.0/24*2*pi, 5.0/24*2*pi,ring11,ring12),
    (5.5/24*2*pi, (ring11+ring12)/2, 5.0/24*2*pi, 6.0/24*2*pi,ring11,ring12),
    (6.5/24*2*pi, (ring11+ring12)/2, 6.0/24*2*pi, 7.0/24*2*pi,ring11,ring12),
    (7.5/24*2*pi, (ring11+ring12)/2, 7.0/24*2*pi, 8.0/24*2*pi,ring11,ring12),
    (8.5/24*2*pi, (ring11+ring12)/2, 8.0/24*2*pi, 9.0/24*2*pi,ring11,ring12),
    (9.5/24*2*pi, (ring11+ring12)/2, 9.0/24*2*pi, 10.0/24*2*pi,ring11,ring12),
    (10.5/24*2*pi, (ring11+ring12)/2, 10.0/24*2*pi, 11.0/24*2*pi,ring11,ring12),
    (11.5/24*2*pi, (ring11+ring12)/2, 11.0/24*2*pi, 12.0/24*2*pi,ring11,ring12),
    (12.5/24*2*pi, (ring11+ring12)/2, 12.0/24*2*pi, 13.0/24*2*pi,ring11,ring12),
    (13.5/24*2*pi, (ring11+ring12)/2, 13.0/24*2*pi, 14.0/24*2*pi,ring11,ring12),
    (14.5/24*2*pi, (ring11+ring12)/2, 14.0/24*2*pi, 15.0/24*2*pi,ring11,ring12),
    (15.5/24*2*pi, (ring11+ring12)/2, 15.0/24*2*pi, 16.0/24*2*pi,ring11,ring12),
    (16.5/24*2*pi, (ring11+ring12)/2, 16.0/24*2*pi, 17.0/24*2*pi,ring11,ring12),
    (17.5/24*2*pi, (ring11+ring12)/2, 17.0/24*2*pi, 18.0/24*2*pi,ring11,ring12),
    (18.5/24*2*pi, (ring11+ring12)/2, 18.0/24*2*pi, 19.0/24*2*pi,ring11,ring12),
    (19.5/24*2*pi, (ring11+ring12)/2, 19.0/24*2*pi, 20.0/24*2*pi,ring11,ring12),
    (20.5/24*2*pi, (ring11+ring12)/2, 20.0/24*2*pi, 21.0/24*2*pi,ring11,ring12),
    (21.5/24*2*pi, (ring11+ring12)/2, 21.0/24*2*pi, 22.0/24*2*pi,ring11,ring12),
    (22.5/24*2*pi, (ring11+ring12)/2, 22.0/24*2*pi, 23.0/24*2*pi,ring11,ring12),
    (23.5/24*2*pi, (ring11+ring12)/2, 23.0/24*2*pi, 24.0/24*2*pi,ring11,ring12),


    (0.5/20*2*pi, (ring12+ring13)/2, 0.0/20*2*pi, 1.0/20*2*pi,ring12,ring13),
    (1.5/20*2*pi, (ring12+ring13)/2, 1.0/20*2*pi, 2.0/20*2*pi,ring12,ring13),
    (2.5/20*2*pi, (ring12+ring13)/2, 2.0/20*2*pi, 3.0/20*2*pi,ring12,ring13),
    (3.5/20*2*pi, (ring12+ring13)/2, 3.0/20*2*pi, 4.0/20*2*pi,ring12,ring13),
    (4.5/20*2*pi, (ring12+ring13)/2, 4.0/20*2*pi, 5.0/20*2*pi,ring12,ring13),
    (5.5/20*2*pi, (ring12+ring13)/2, 5.0/20*2*pi, 6.0/20*2*pi,ring12,ring13),
    (6.5/20*2*pi, (ring12+ring13)/2, 6.0/20*2*pi, 7.0/20*2*pi,ring12,ring13),
    (7.5/20*2*pi, (ring12+ring13)/2, 7.0/20*2*pi, 8.0/20*2*pi,ring12,ring13),
    (8.5/20*2*pi, (ring12+ring13)/2, 8.0/20*2*pi, 9.0/20*2*pi,ring12,ring13),
    (9.5/20*2*pi, (ring12+ring13)/2, 9.0/20*2*pi, 10.0/20*2*pi,ring12,ring13),
    (10.5/20*2*pi, (ring12+ring13)/2, 10.0/20*2*pi, 11.0/20*2*pi,ring12,ring13),
    (11.5/20*2*pi, (ring12+ring13)/2, 11.0/20*2*pi, 12.0/20*2*pi,ring12,ring13),
    (12.5/20*2*pi, (ring12+ring13)/2, 12.0/20*2*pi, 13.0/20*2*pi,ring12,ring13),
    (13.5/20*2*pi, (ring12+ring13)/2, 13.0/20*2*pi, 14.0/20*2*pi,ring12,ring13),
    (14.5/20*2*pi, (ring12+ring13)/2, 14.0/20*2*pi, 15.0/20*2*pi,ring12,ring13),
    (15.5/20*2*pi, (ring12+ring13)/2, 15.0/20*2*pi, 16.0/20*2*pi,ring12,ring13),
    (16.5/20*2*pi, (ring12+ring13)/2, 16.0/20*2*pi, 17.0/20*2*pi,ring12,ring13),
    (17.5/20*2*pi, (ring12+ring13)/2, 17.0/20*2*pi, 18.0/20*2*pi,ring12,ring13),
    (18.5/20*2*pi, (ring12+ring13)/2, 18.0/20*2*pi, 19.0/20*2*pi,ring12,ring13),
    (19.5/20*2*pi, (ring12+ring13)/2, 19.0/20*2*pi, 20.0/20*2*pi,ring12,ring13),



    (0.5/16*2*pi, (ring13+ring14)/2, 0.0/16*2*pi, 1.0/16*2*pi,ring13,ring14),
    (1.5/16*2*pi, (ring13+ring14)/2, 1.0/16*2*pi, 2.0/16*2*pi,ring13,ring14),
    (2.5/16*2*pi, (ring13+ring14)/2, 2.0/16*2*pi, 3.0/16*2*pi,ring13,ring14),
    (3.5/16*2*pi, (ring13+ring14)/2, 3.0/16*2*pi, 4.0/16*2*pi,ring13,ring14),
    (4.5/16*2*pi, (ring13+ring14)/2, 4.0/16*2*pi, 5.0/16*2*pi,ring13,ring14),
    (5.5/16*2*pi, (ring13+ring14)/2, 5.0/16*2*pi, 6.0/16*2*pi,ring13,ring14),
    (6.5/16*2*pi, (ring13+ring14)/2, 6.0/16*2*pi, 7.0/16*2*pi,ring13,ring14),
    (7.5/16*2*pi, (ring13+ring14)/2, 7.0/16*2*pi, 8.0/16*2*pi,ring13,ring14),
    (8.5/16*2*pi, (ring13+ring14)/2, 8.0/16*2*pi, 9.0/16*2*pi,ring13,ring14),
    (9.5/16*2*pi, (ring13+ring14)/2, 9.0/16*2*pi, 10.0/16*2*pi,ring13,ring14),
    (10.5/16*2*pi, (ring13+ring14)/2, 10.0/16*2*pi, 11.0/16*2*pi,ring13,ring14),
    (11.5/16*2*pi, (ring13+ring14)/2, 11.0/16*2*pi, 12.0/16*2*pi,ring13,ring14),
    (12.5/16*2*pi, (ring13+ring14)/2, 12.0/16*2*pi, 13.0/16*2*pi,ring13,ring14),
    (13.5/16*2*pi, (ring13+ring14)/2, 13.0/16*2*pi, 14.0/16*2*pi,ring13,ring14),
    (14.5/16*2*pi, (ring13+ring14)/2, 14.0/16*2*pi, 15.0/16*2*pi,ring13,ring14),
    (15.5/16*2*pi, (ring13+ring14)/2, 15.0/16*2*pi, 16.0/16*2*pi,ring13,ring14),

    (0.5/12*2*pi, (ring14+ring15)/2, 0.0/12*2*pi, 1.0/12*2*pi,ring14,ring15),
    (1.5/12*2*pi, (ring14+ring15)/2, 1.0/12*2*pi, 2.0/12*2*pi,ring14,ring15),
    (2.5/12*2*pi, (ring14+ring15)/2, 2.0/12*2*pi, 3.0/12*2*pi,ring14,ring15),
    (3.5/12*2*pi, (ring14+ring15)/2, 3.0/12*2*pi, 4.0/12*2*pi,ring14,ring15),
    (4.5/12*2*pi, (ring14+ring15)/2, 4.0/12*2*pi, 5.0/12*2*pi,ring14,ring15),
    (5.5/12*2*pi, (ring14+ring15)/2, 5.0/12*2*pi, 6.0/12*2*pi,ring14,ring15),
    (6.5/12*2*pi, (ring14+ring15)/2, 6.0/12*2*pi, 7.0/12*2*pi,ring14,ring15),
    (7.5/12*2*pi, (ring14+ring15)/2, 7.0/12*2*pi, 8.0/12*2*pi,ring14,ring15),
    (8.5/12*2*pi, (ring14+ring15)/2, 8.0/12*2*pi, 9.0/12*2*pi,ring14,ring15),
    (9.5/12*2*pi, (ring14+ring15)/2, 9.0/12*2*pi, 10.0/12*2*pi,ring14,ring15),
    (10.5/12*2*pi, (ring14+ring15)/2, 10.0/12*2*pi, 11.0/12*2*pi,ring14,ring15),
    (11.5/12*2*pi, (ring14+ring15)/2, 11.0/12*2*pi, 12.0/12*2*pi,ring14,ring15),

    (0.5/8*2*pi, (ring15+ring16)/2, 0.0/8*2*pi, 1.0/8*2*pi,ring15,ring16),
    (1.5/8*2*pi, (ring15+ring16)/2, 1.0/8*2*pi, 2.0/8*2*pi,ring15,ring16),
    (2.5/8*2*pi, (ring15+ring16)/2, 2.0/8*2*pi, 3.0/8*2*pi,ring15,ring16),
    (3.5/8*2*pi, (ring15+ring16)/2, 3.0/8*2*pi, 4.0/8*2*pi,ring15,ring16),
    (4.5/8*2*pi, (ring15+ring16)/2, 4.0/8*2*pi, 5.0/8*2*pi,ring15,ring16),
    (5.5/8*2*pi, (ring15+ring16)/2, 5.0/8*2*pi, 6.0/8*2*pi,ring15,ring16),
    (6.5/8*2*pi, (ring15+ring16)/2, 6.0/8*2*pi, 7.0/8*2*pi,ring15,ring16),
    (7.5/8*2*pi, (ring15+ring16)/2, 7.0/8*2*pi, 8.0/8*2*pi,ring15,ring16),


    (0.5/4*2*pi, (ring16+ring17)/2, 0.0/4*2*pi, 1.0/4*2*pi,ring16,ring17),
    (1.5/4*2*pi, (ring16+ring17)/2, 1.0/4*2*pi, 2.0/4*2*pi,ring16,ring17),
    (2.5/4*2*pi, (ring16+ring17)/2, 2.0/4*2*pi, 3.0/4*2*pi,ring16,ring17),
    (3.5/4*2*pi, (ring16+ring17)/2, 3.0/4*2*pi, 4.0/4*2*pi,ring16,ring17),

    ( 0       ,   ring18          ,  0        ,pi         ,ring17,ring18 )); {1 segment}   {north pole }




implementation
uses  sysutils;

Const


rings290: array[0..18] of real= {based on a idea in THE DIVISION OF A CIRCLE OR SPHERICAL SURFACE INTO EQUAL-AREA CELLS OR PIXELS, Irving I. Gringorten, Penelope J. Yepez}
 (-90,-85.23224404, -75.66348756, -65.99286637, -56.14497387,-46.03163067,-35.54307745,-24.53348115,-12.79440589, 0.0 ,+12.79440589,+24.53348115,+35.54307745,+46.03163067,+56.14497387,+65.99286637,+75.66348756,+85.23224404,90);
// (arcsin(1-1/289), arcsin(1-(1+8)/289), arcsin(1-(1+8+16)/289), arcsin(1-(1+8+16+24)/289),arcsin(1-(1+8+16+24+32)/289),0.0 ......


seg_length=18;

segments290: array[1..seg_length] of integer= {combined cells to make square, THE DIVISION OF A CIRCLE OR SPHERICAL SURFACE INTO EQUAL-AREA CELLS OR PIXELS, Irving I. Gringorten, Penelope J. Yepez}
 (1,4,8,12,16,20,24,28,32,32,28,24,20,16,12,8,4, 1);
{combined from 1,8,16,24,32,40,48,56,64.....}

function name290(ra,dec:real): string; {give segment name}
var
   r,d : integer;
   found: boolean;
   dum  :string;
begin
  found:=false;
  d:=0;

  if dec>+pi/2 then dec:=PI/2;
  if dec<-pi/2 then dec:=-PI/2;
  repeat {find dec ring}
    inc(d);
    if dec*180/pi<rings290[d] then begin found:=true; str(d,result); if length(result)=1 then result:='0' +result; end;

  until ((found=true) or (d>=seg_length));

 {find ra segment}
  if ra>=2*pi then ra:=0;
  if ra<0     then ra:=0;
  str( 1+trunc(segments290[d]*ra/(2*pi)),dum);
  if length(dum)=1 then dum:='0' +dum;
  result:=result+dum+'.290';
end;

PROCEDURE ang_sep(ra1,dec1,ra2,dec2 : real;var sep: real); { By Han Kleijn}
var cos_sep:real;
{caculates angular separation. according formula 9.1 old meeus}
Begin
  cos_sep:=sin(dec1)*sin(dec2)+ cos(dec1)*cos(dec2)*cos(ra1-ra2);
  if ABS(cos_sep)<1 then begin sep:=(PI/2-ARCTAN(cos_sep/(SQRT(1-SQR(cos_sep))))) end {arccos function}
  else
  begin if cos_sep>0 then sep:=0 {note bij x=1 klapt uitkomst net om}
                     else sep:=PI;
  end; {arccos function}

end;
function  limit_radialen(z:double):double;
begin
  while z<0 do z:=z+2*pi;
  while z>=2*pi do z:=z-2*pi; {corrected 2019}
///  while z>2*pi do z:=z-2*pi;
  limit_radialen:=z;
end;


begin

end.
